const fs=require('fs'),path=require('path'),os=require('os'),{spawn}=require('child_process'),http=require('http');
const root=__dirname,tmp=fs.mkdtempSync(path.join(os.tmpdir(),'angelstore-step533-')),port=8033;
const env={...process.env,PORT:String(port),HOST:'127.0.0.1',NODE_ENV:'production',ANGELSTORE_STORAGE_DIR:tmp,ANGELSTORE_UPLOAD_DIR:path.join(tmp,'uploads','payments'),ANGELSTORE_DOCUMENT_UPLOAD_DIR:path.join(tmp,'uploads','documents'),ANGELSTORE_BACKUP_DIR:path.join(tmp,'backups'),ANGELSTORE_AUTH_SECRET:'step533-runtime-secret-12345678901234567890',ANGELSTORE_ADMIN_USER:'testadmin',ANGELSTORE_ADMIN_PASS:'TestAdmin!12345',ANGELSTORE_CORS_ORIGIN:'https://example.test'};
const child=spawn(process.execPath,[path.join(root,'server.js')],{cwd:root,env,stdio:['ignore','pipe','pipe']});let logs='';child.stdout.on('data',d=>logs+=d);child.stderr.on('data',d=>logs+=d);
function req(method,p,payload,headers={}){return new Promise((resolve,reject)=>{const body=payload===undefined?null:JSON.stringify(payload);const r=http.request({host:'127.0.0.1',port,path:p,method,headers:{'Content-Type':'application/json',...(body?{'Content-Length':Buffer.byteLength(body)}:{}),...headers}},res=>{let b='';res.on('data',d=>b+=d);res.on('end',()=>{let data;try{data=JSON.parse(b)}catch{data=b}resolve({status:res.statusCode,data,headers:res.headers})})});r.on('error',reject);if(body)r.write(body);r.end()})}
function sessionHeaders(resp,requiredCookie){const set=resp.headers['set-cookie']||[];const jar=set.map(v=>v.split(';')[0]).join('; ');const csrfMatch=jar.match(/(?:^|; )angel_csrf=([^;]+)/);if(!jar.includes(requiredCookie+'='))throw Error(`missing ${requiredCookie} cookie`);if(!csrfMatch)throw Error('missing CSRF cookie');return {Cookie:jar,'X-CSRF-Token':decodeURIComponent(csrfMatch[1])}}
function proof(label){return 'data:application/pdf;base64,'+Buffer.from('%PDF-1.4\n'+label+'\nThis is an isolated test proof fixture.\n%%EOF\n').toString('base64')}
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{try{
 let ready=false;for(let i=0;i<50&&!ready;i++){await wait(100);try{ready=(await req('GET','/api/health')).status===200}catch{}}
 if(!ready)throw Error('server not ready; '+logs.slice(-2000));
 const mobile='8'+String(Date.now()).slice(-9),name='STEP533 Concurrency Test';
 let r=await req('POST','/api/customer/register',{name,mobile,pin:'1234'});if(r.status!==201)throw Error('register '+r.status+' '+JSON.stringify(r.data));const customer=sessionHeaders(r,'angel_customer');
 r=await req('POST','/api/auth/login',{username:env.ANGELSTORE_ADMIN_USER,password:env.ANGELSTORE_ADMIN_PASS});if(r.status!==200)throw Error('admin login '+r.status);const admin=sessionHeaders(r,'angel_admin');
 const base=Date.now();
 const initial=await req('POST','/api/customer/recharge/payment',{mobile,operator:'JIO',type:'PREPAID',circle:'UP',amount:99,plan:{id:'STEP533-A',name:'STEP533 A'},utr:'S533INIT'+base,screenshot:proof('initial-'+base),idempotency_key:'s533-init-'+base},customer);if(initial.status!==200)throw Error('initial '+initial.status+' '+JSON.stringify(initial.data));
 const original=initial.data.recharge;
 r=await req('POST','/api/payments/status',{id:initial.data.payment.id,status:'Rejected',reason:'Concurrency test rejection'},admin);if(r.status!==200)throw Error('reject '+r.status+' '+JSON.stringify(r.data));
 const [a,b]=await Promise.all([
  req('POST','/api/customer/recharge/retry',{recharge_id:original.id,utr:'S533A'+base,screenshot:proof('retry-A-'+base),idempotency_key:'s533-a-'+base},customer),
  req('POST','/api/customer/recharge/retry',{recharge_id:original.id,utr:'S533B'+base,screenshot:proof('retry-B-'+base),idempotency_key:'s533-b-'+base},customer)
 ]);
 const statuses=[a.status,b.status].sort((x,y)=>x-y);if(!(statuses[0]===201&&statuses[1]===409))throw Error(`branch race expected 201+409, got ${a.status}+${b.status}; ${JSON.stringify([a.data,b.data])}`);
 const winner=a.status===201?a:b;
 if(winner.data.recharge.attempt_no!==2||Number(winner.data.recharge.retry_of_recharge_id)!==Number(original.id))throw Error('winner metadata invalid');
 console.log('PASS | server health');console.log('PASS | customer cookie + CSRF session');console.log('PASS | admin cookie + CSRF session');console.log('PASS | original recharge rejected');console.log('PASS | concurrent different retry submissions collapse to one child (201 + 409)');console.log('PASS | winning retry is Attempt #2 and linked to original');
 const [c,d]=await Promise.all([
  req('POST','/api/customer/recharge/retry',{recharge_id:original.id,utr:'S533C'+base,screenshot:proof('retry-C-'+base),idempotency_key:'s533-c-'+base},customer),
  req('POST','/api/customer/recharge/retry',{recharge_id:original.id,utr:'S533C'+base,screenshot:proof('retry-C-'+base),idempotency_key:'s533-c-'+base},customer)
 ]);
 if(!((c.status===409&&d.status===409)||(c.status===200&&d.status===200)))throw Error(`repeat retry behavior unexpected ${c.status}+${d.status}; ${JSON.stringify([c.data,d.data])}`);
 console.log('PASS | later branch attempts remain blocked by existing child retry');
 console.log('STEP533_RECHARGE_RETRY_CONCURRENCY_E2E: 7/7 PASS');
}catch(e){console.error('STEP533_RECHARGE_RETRY_CONCURRENCY_E2E: FAIL');console.error(e.stack||e);process.exitCode=1}finally{child.kill('SIGTERM');setTimeout(()=>{try{fs.rmSync(tmp,{recursive:true,force:true})}catch{}},300)}})();
