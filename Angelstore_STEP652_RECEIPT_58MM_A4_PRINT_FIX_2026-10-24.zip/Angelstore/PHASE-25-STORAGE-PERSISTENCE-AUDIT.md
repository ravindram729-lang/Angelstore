# Phase 25 — Production Storage & Data Persistence Audit

## Scope
Inspected the Phase 24 release before making changes. The existing JSON storage architecture, schema and business records were preserved.

## Findings
1. **Production durability depended on application-local paths.** `data.json`, `backups/` and payment proofs were rooted in the application directory. On an ephemeral host, redeploy/restart can lose them.
2. **Storage paths were not configurable.** A persistent-disk mount could not be selected without code changes.
3. **Writes were atomic by rename but did not fsync the file/directory.** This was improved without changing the schema.
4. **There was no authenticated storage-health view.** Admins could not see which paths were active or how many backup/proof files existed without server access.
5. **The existing backup endpoint backs up the JSON database, but it does not constitute off-site disaster recovery.** An external/off-host copy is still required.

## Changes
- Added `ANGELSTORE_STORAGE_DIR` as the production persistent-storage root.
- Added optional `ANGELSTORE_UPLOAD_DIR` and `ANGELSTORE_BACKUP_DIR` overrides.
- Payment uploads and backups default under the configured storage root.
- Added atomic + `fsync` writes for the JSON database and backup files.
- Added authenticated `GET /api/admin/storage-status`.
- Strengthened `PRODUCTION-PREFLIGHT.js` to require explicit persistent-storage configuration in production.
- Updated `.env.example` and production deployment documentation.

## Schema/data safety
No database collection, field, business record, payment workflow, token workflow, customer workflow, staff workflow or quality gate was intentionally changed.

## Verification
- `node --check storage.js` — PASS
- `node --check server.js` — PASS
- `node --check PRODUCTION-PREFLIGHT.js` — PASS
- Local server with isolated `ANGELSTORE_STORAGE_DIR` — PASS
- Database creation and backup on configured storage root — PASS
- Restarted server against same storage root and verified files remained readable — PASS
- Unauthenticated storage-status access — correctly returned 401
- Authenticated storage-status access — PASS
- Backup creation — PASS

## Important production limitation
This phase makes persistence **configurable and testable**, but it cannot create a persistent disk on the hosting provider. The actual Render/host persistent-disk mount must be configured in the hosting account. If the host is ephemeral and `ANGELSTORE_STORAGE_DIR` is not backed by persistent storage, data and uploaded payment proofs can still be lost after redeploy.

## Recommended deployment configuration
Set `ANGELSTORE_STORAGE_DIR` to the provider's persistent-disk mount, then verify `/api/admin/storage-status` after deployment. Keep an off-host backup copy for disaster recovery.
