const fs=require('fs'),path=require('path'),os=require('os'),{spawn}=require('child_process');
const root=__dirname, temp=fs.mkdtempSync(path.join(os.tmpdir(),'angelstore-step467-')), data={
  payments:[{id:99,name:'Pending',mobile:'9876543212',amount:75,method:'UPI',utr:'UTR099',status:'Pending Verification',service:'Test Service',application_id:201,created_at:new Date().toISOString()},{id:100,name:'Status',mobile:'9876543211',amount:50,method:'UPI',utr:'UTR100',status:'Verified',service:'Test Service',application_id:201,created_at:new Date().toISOString()},{id:101,name:'Test',mobile:'9876543210',amount:100,method:'UPI',utr:'UTR101',status:'Verified',service:'Test Service',application_id:999,created_at:new Date().toISOString()}],
  applications:[{id:201,application_id:'APP201',name:'Test',mobile:'9876543210',service:'Test Service',status:'Payment Pending',created_at:new Date().toISOString()}],
  recharge_transactions:[{id:303,mobile:'9876543212',operator:'VI',type:'PREPAID',circle:'UP',amount:75,status:'Success',payment_id:99,application_id:201,source:'customer-payment',created_at:new Date().toISOString(),updated_at:new Date().toISOString()},{id:302,mobile:'9876543211',operator:'AIRTEL',type:'PREPAID',circle:'UP',amount:50,status:'Success',payment_id:100,application_id:201,source:'customer-payment',created_at:new Date().toISOString(),updated_at:new Date().toISOString()},{id:301,mobile:'9876543210',operator:'JIO',type:'PREPAID',circle:'UP',amount:299,status:'Success',payment_id:101,application_id:201,source:'customer-payment',created_at:new Date().toISOString(),updated_at:new Date().toISOString()}],
  payment_idempotency:[
    {scope:'recharge-payment',key:'dup-key',fingerprint:'aaa',payment_id:101,recharge_id:301,created_at:new Date().toISOString()},
    {scope:'recharge-payment',key:'dup-key',fingerprint:'bbb',payment_id:102,recharge_id:302,created_at:new Date().toISOString()}
  ],
  audit:[]
};
fs.writeFileSync(path.join(temp,'data.json'),JSON.stringify(data,null,2));
const port=8767, env={...process.env,PORT:String(port),HOST:'127.0.0.1',ANGELSTORE_STORAGE_DIR:temp,ANGELSTORE_ADMIN_USER:'step467admin',ANGELSTORE_ADMIN_PASS:'Step467SecurePass!92',ANGELSTORE_AUTH_SECRET:'step467-auth-secret-012345678901234567890123',ANGELSTORE_CORS_ORIGIN:'http://127.0.0.1:'+port};
const child=spawn(process.execPath,[path.join(root,'server.js')],{cwd:root,env,stdio:['ignore','pipe','pipe']});
let output='';child.stdout.on('data',d=>output+=d);child.stderr.on('data',d=>output+=d);
function sessionHeaders(resp,requiredCookie){const raw=resp.headers?.get?.('set-cookie')||'';const set=raw.split(/, (?=[^;,]+=)/);const jar=set.map(v=>v.split(';')[0]).filter(Boolean).join('; ');const csrfMatch=jar.match(/(?:^|; )angel_csrf=([^;]+)/);if(!jar.includes(requiredCookie+'='))throw Error('missing '+requiredCookie+' cookie');if(!csrfMatch)throw Error('missing CSRF cookie');return {Cookie:jar,'X-CSRF-Token':decodeURIComponent(csrfMatch[1])}}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function req(url,opts={}){for(let i=0;i<30;i++){try{const r=await fetch('http://127.0.0.1:'+port+url,opts);const t=await r.text();let j={};try{j=JSON.parse(t)}catch{};return {status:r.status,data:j,headers:r.headers};}catch(e){await sleep(100)}}throw new Error('server unavailable: '+output.slice(-500));}
(async()=>{try{
  await sleep(600);
  const login=await req('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'step467admin',password:'Step467SecurePass!92'})});
  if(login.status!==200)throw new Error('admin login failed '+JSON.stringify(login.data));
  const h=sessionHeaders(login,'angel_admin');
  const scan=await req('/api/admin/payment-reconciliation',{headers:h});
  if(scan.status!==200)throw new Error('scan failed '+JSON.stringify(scan.data));
  const types=new Set((scan.data.issues||[]).map(x=>x.type));
  const expected=['PAYMENT_ORPHAN_APPLICATION','APPLICATION_STATUS_MISMATCH','RECHARGE_AMOUNT_MISMATCH','RECHARGE_TERMINAL_PAYMENT_MISMATCH','IDEMPOTENCY_DUPLICATE_CONFLICT'];
  for(const t of expected)if(!types.has(t))throw new Error('missing issue '+t);
  const review=await req('/api/admin/payment-reconciliation/review',{method:'POST',headers:{...h,'Content-Type':'application/json'},body:JSON.stringify({type:'RECHARGE_AMOUNT_MISMATCH',recharge_id:301,payment_id:101,note:'Controlled review test'})});
  if(review.status!==200)throw new Error('review failed '+JSON.stringify(review.data));
  const scan2=await req('/api/admin/payment-reconciliation',{headers:h});
  if(!scan2.data.recent_recovery_audit?.some(x=>x.action==='GLOBAL_RECONCILIATION_REVIEWED'))throw new Error('review audit missing');
  console.log(JSON.stringify({ok:true,checks:{admin_login:true,scan:true,expected_issue_types:true,review_endpoint:true,audit_persisted:true},issue_count:scan.data.issue_count,checked:scan.data.checked},null,2));
}catch(e){console.error(JSON.stringify({ok:false,error:e.message,output:output.slice(-1200)},null,2));process.exitCode=1}finally{child.kill('SIGTERM');setTimeout(()=>{fs.rmSync(temp,{recursive:true,force:true})},200)}})();
