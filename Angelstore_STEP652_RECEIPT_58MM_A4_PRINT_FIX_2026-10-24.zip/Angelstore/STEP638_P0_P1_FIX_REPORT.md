# STEP638 — P0/P1 Project Fix Report

## Scope
Targeted fixes from the full-project audit of STEP637. No unrelated workflow changes.

## Changes
1. **Admin Home wait metric**
   - Removed the hard-coded `waiting * 3` minute calculation.
   - Admin Home now calculates the average from the real `estimated_wait_minutes` values returned by the Token API for active today's tokens.

2. **Customer Live Sync regression**
   - Restored the customer live polling interval from 3 seconds to 5 seconds.
   - Existing hidden-tab and in-flight request guards remain intact.

3. **Customer service fallback source**
   - Customer category fallback now derives from `service-catalog.js` (`Object.keys(SERVICE_INFO)`) instead of maintaining a second hard-coded category list.
   - This removes the previously identified missing `स्कूल / कॉलेज कार्य` fallback category.

4. **Regression verification**
   - Added `STEP638_P0_P1_REGRESSION.js` covering current cookie-based customer authentication, payment verification, token generation, customer token readback, dashboard wait source, 5-second live sync, and catalog-driven service fallback.
   - Updated no production API contract.

## Verification
- `node --check app.js` — PASS
- `node --check customer.js` — PASS
- `node --check server.js` — PASS
- `node STEP498_TOKEN_QUEUE_PERFORMANCE_MONITOR_TEST.js` — PASS (6/6)
- `node STEP638_P0_P1_REGRESSION.js` — PASS (5/5)

## Not changed in this step
- Token generation backend rules
- Payment verification rules
- UPPCL workflow
- Mobile Recharge workflow
- Receipt workflow
- Database/storage architecture
- Admin RBAC
- SSE/WebSocket migration
- OCR worker architecture
