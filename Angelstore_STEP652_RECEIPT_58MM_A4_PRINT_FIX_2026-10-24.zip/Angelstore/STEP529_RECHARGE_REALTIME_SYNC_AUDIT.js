const fs=require('fs');
const server=fs.readFileSync('server.js','utf8');
const customer=fs.readFileSync('customer.js','utf8');
const checks=[
 ['customer recharge sync endpoint exists',server.includes("/api/customer/recharge/sync")],
 ['sync endpoint requires customer session',server.includes("if(p==='/api/customer/recharge/sync'&&req.method==='GET')")&&server.includes("const c=customerSession(req);if(!c)return json(res,401")],
 ['recharge exposes state revision',server.includes('state_revision:Number(r.state_revision||0)')],
 ['admin recharge transition increments revision',server.includes('row.state_revision=Number(row.state_revision||0)+1')],
 ['payment verification increments recharge revision',server.includes('recharge.state_revision=Number(recharge.state_revision||0)+1')],
 ['payment rejection syncs recharge to failed',server.includes("if(recharge.status==='Pending'){recharge.status='Failed'")],
 ['customer client polls recharge sync',customer.includes('/api/customer/recharge/sync?since=')],
 ['customer live sync interval is 3 seconds',customer.includes('customerLiveSyncTimer=setInterval(tick,3000)')],
 ['customer records refresh after recharge change',customer.includes("await loadRecords({silent:true})")],
 ['no cart/order dependency introduced',!server.includes("/api/customer/recharge/order")&&!customer.includes('rechargeCart')]
];
let pass=0;for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} - ${name}`);if(ok)pass++;}
console.log(`STEP529 RESULT: ${pass}/${checks.length} PASS`);process.exit(pass===checks.length?0:1);
