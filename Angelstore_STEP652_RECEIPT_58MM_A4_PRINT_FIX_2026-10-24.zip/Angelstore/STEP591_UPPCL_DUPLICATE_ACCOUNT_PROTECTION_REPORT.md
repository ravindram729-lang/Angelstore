# STEP591 — UPPCL Duplicate Account Protection

## Scope
Prevent duplicate active UPPCL manual bills for the same Account Number while allowing separate bill-month records and preserving closed/non-active history.

## Changes
- Admin manual-bill POST now reuses an existing active `Updated` bill for the same account and same bill month (or blank month when the new entry also has no month) when no explicit bill id is supplied.
- Reused bill records increment their version, preserving the existing bill identity and payment snapshot model.
- Customer manual-bill lookup now selects the most recently updated active bill when multiple active records exist, preventing an older duplicate from being selected.
- Existing explicit-id edit behavior remains unchanged.
- Existing payment/bill version linkage remains unchanged.

## Validation
- `node --check server.js` — PASS
- `npm run check` — PASS
- Existing UPPCL payment lifecycle code unchanged.
- No customer payment data or seed data changed.
