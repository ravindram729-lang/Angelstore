const fs=require('fs'),path=require('path'),http=require('http'),child=require('child_process');
const ROOT=__dirname,TMP=path.join(ROOT,'.step468-global-recovery-e2e');fs.rmSync(TMP,{recursive:true,force:true});fs.mkdirSync(TMP,{recursive:true});
const now=new Date().toISOString();
const seed={payments:[
{id:101,txn_id:'PAY-101',name:'Recovery A',mobile:'9000010101',service:'UPPCL Bill Payment',amount:500,status:'Verified',created_at:now,application_id:201,uppcl_processing_status:'Completed',completed_at:now,receipt_no:null},
{id:102,txn_id:'PAY-102',name:'Recovery B',mobile:'9000010102',service:'पैन सेवाएँ — New PAN application',amount:157,status:'Verified',created_at:now,application_id:202,receipt_no:null},
{id:103,txn_id:'PAY-103',name:'Recovery C',mobile:'9000010103',service:'Recharge',amount:199,status:'Verified',created_at:now,application_id:203,receipt_no:null}],
applications:[
{id:201,application_id:'APP-201',name:'Recovery A',mobile:'9000010101',service:'UPPCL Bill Payment',category:'UPPCL',status:'Completed',created_at:now},
{id:202,application_id:'APP-202',name:'Recovery B',mobile:'9000010102',service:'पैन सेवाएँ — New PAN application',category:'पैन सेवाएँ',status:'Payment Verification Pending',created_at:now},
{id:203,application_id:'APP-203',name:'Recovery C',mobile:'9000010103',service:'Recharge',category:'Recharge',status:'Application Submitted',created_at:now}],
recharge_transactions:[{id:301,payment_id:103,application_id:null,mobile:'9000010103',operator:'JIO',type:'PREPAID',circle:'UP',amount:199,status:'Success',created_at:now}],
uppcl_manual_bills:[],payment_idempotency:[],audit:[]};
fs.writeFileSync(path.join(TMP,'data.json'),JSON.stringify(seed,null,2));
const env={...process.env,PORT:'8037',ANGELSTORE_STORAGE_DIR:TMP,ANGELSTORE_AUTH_SECRET:'step468-global-recovery-secret-12345678901234567890',ANGELSTORE_ADMIN_USER:'testadmin',ANGELSTORE_ADMIN_PASS:'TestAdmin!12345'};
let proc=null,out='';
function start(){proc=child.spawn(process.execPath,[path.join(ROOT,'server.js')],{cwd:ROOT,env,stdio:['ignore','pipe','pipe']});proc.stdout.on('data',d=>out+=d);proc.stderr.on('data',d=>out+=d)}
function stop(){if(proc){proc.kill('SIGTERM');proc=null}}
const BASE='http://127.0.0.1:8037';
function req(method,p,body,headers={}){return new Promise((resolve,reject)=>{const u=new URL(p,BASE),b=body===undefined?null:Buffer.from(JSON.stringify(body));const r=http.request({method,hostname:u.hostname,port:u.port,path:u.pathname+u.search,headers:{...(b?{'Content-Type':'application/json','Content-Length':b.length}:{}),...headers}},res=>{let s='';res.on('data',c=>s+=c);res.on('end',()=>{let data;try{data=s?JSON.parse(s):null}catch{data=s}resolve({status:res.statusCode,data,headers:res.headers})})});r.on('error',reject);if(b)r.write(b);r.end()})}
function sessionHeaders(resp,requiredCookie){const set=resp.headers?.['set-cookie']||[];const jar=set.map(v=>v.split(';')[0]).join('; ');const csrfMatch=jar.match(/(?:^|; )angel_csrf=([^;]+)/);if(!jar.includes(requiredCookie+'='))throw Error('missing '+requiredCookie+' cookie');if(!csrfMatch)throw Error('missing CSRF cookie');return {Cookie:jar,'X-CSRF-Token':decodeURIComponent(csrfMatch[1])}}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{try{
 start();for(let i=0;i<50;i++){try{if((await req('GET','/api/health')).status===200)break}catch{}await sleep(100)}
 let r=await req('POST','/api/auth/login',{username:'testadmin',password:'TestAdmin!12345'});if(r.status!==200)throw Error('admin login');const A=sessionHeaders(r,'angel_admin');
 r=await req('GET','/api/admin/payment-reconciliation',undefined,A);if(r.status!==200)throw Error('reconciliation '+JSON.stringify(r.data));
 const initialIssues=r.data.issues;const types=new Set(initialIssues.map(x=>x.type));for(const t of ['UPPCL_COMPLETED_NO_RECEIPT','APPLICATION_STATUS_MISMATCH','RECHARGE_MISSING_APPLICATION_LINK'])if(!types.has(t))throw Error('missing issue '+t);
 const get=(t)=>initialIssues.find(x=>x.type===t);
 let x=get('UPPCL_COMPLETED_NO_RECEIPT');r=await req('POST','/api/admin/payment-reconciliation/recover',{action:x.repair_action,payment_id:x.payment_id,application_id:x.application_id},A);if(r.status!==200)throw Error('receipt repair '+JSON.stringify(r.data));const receiptAudit=r.data.audit_id;
 x=get('APPLICATION_STATUS_MISMATCH');r=await req('POST','/api/admin/payment-reconciliation/recover',{action:x.repair_action,payment_id:x.payment_id,application_id:x.application_id},A);if(r.status!==200)throw Error('application sync '+JSON.stringify(r.data));
 x=get('RECHARGE_MISSING_APPLICATION_LINK');r=await req('POST','/api/admin/payment-reconciliation/recover',{action:x.repair_action,payment_id:x.payment_id,recharge_id:x.recharge_id,application_id:x.application_id},A);if(r.status!==200)throw Error('recharge link '+JSON.stringify(r.data));
 r=await req('GET','/api/admin/payment-reconciliation',undefined,A);if(r.status!==200||r.data.issue_count!==0)throw Error('revalidation failed '+JSON.stringify(r.data));
 r=await req('POST','/api/admin/payment-reconciliation/rollback',{audit_id:receiptAudit},A);if(r.status!==200)throw Error('rollback failed '+JSON.stringify(r.data));
 r=await req('GET','/api/admin/payment-reconciliation',undefined,A);if(r.status!==200||r.data.issue_count!==1||r.data.issues[0].type!=='UPPCL_COMPLETED_NO_RECEIPT')throw Error('rollback did not restore issue '+JSON.stringify(r.data));
 const raw=JSON.parse(fs.readFileSync(path.join(TMP,'data.json'),'utf8'));
 const checks={candidate_issue_detection:true,uppcl_receipt_repair:true,application_status_sync:true,recharge_application_link_repair:true,revalidation_zero_issues:true,rollback_snapshot_restored_issue:true,repair_audit_logged:raw.audit.some(x=>x.action==='GLOBAL_RECONCILIATION_REPAIRED'),rollback_audit_logged:raw.audit.some(x=>x.action==='GLOBAL_RECONCILIATION_ROLLED_BACK')};
 console.log(JSON.stringify({ok:true,checks},null,2));
}catch(e){console.error(JSON.stringify({ok:false,error:e.message,server_output:out},null,2));process.exitCode=1}finally{stop();setTimeout(()=>{try{fs.rmSync(TMP,{recursive:true,force:true})}catch{}},250)}})();
