# STEP506 — Token Generate Layout Balance Fix

## Problem observed
The reference Token Generate UI was structurally correct but the desktop two-column layout created a large dead/empty area under the shorter left column while the payment proof/workflow cards continued down the right column. The payment method buttons could also become cramped at the available desktop width.

## Fix
- Balanced desktop Token Generate grid width.
- Used CSS grid placement so customer/service/amount remain left, payment spans the upper right, payment proof aligns below the amount, and next-workflow/generated-token cards remain on the right.
- Changed desktop payment method buttons to a 2-column layout so all four options remain visible without horizontal clipping.
- Preserved the existing `customerPaymentForm`, payment controls, token generation controls and mobile single-column fallback.
- No backend/API/payment/token state-machine changes.

## Verification
- STEP506 layout checks: 10/10 PASS
- `node --check customer.js`: PASS
- `node --check server.js`: PASS
- Existing STEP505/504/503 functionality retained by source-level regression checks.

## Visual note
The supplied browser screenshots were used to target the dead-space and clipped payment-method issue. A fresh automated browser click-through was not claimed.
