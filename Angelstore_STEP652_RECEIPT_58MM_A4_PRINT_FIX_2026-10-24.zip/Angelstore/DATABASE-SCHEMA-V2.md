# Angelstore CSC — Database Schema v2

## Purpose
A migration-safe normalized data model for Customer, Service, Token, Payment, Staff, Home Service, Delivery, Commission and Settlement workflows.

## Existing data
The current `data.json` remains the source of truth for this phase. `storage.js` initializes the v2 collections and derives canonical customer records from legacy applications/payments/tokens without deleting or rewriting those records.

## Collections

### customers
`id`, `customer_id`, `name`, `mobile`, `email`, `address`, `status`, `pin_hash`, `pin_set`, `created_at`, `updated_at`

### customer_sessions
`id`, `customer_id`, `session_hash`, `device_label`, `ip_hash`, `expires_at`, `created_at`, `revoked_at`

### customer_qr
`id`, `customer_id`, `qr_token_hash`, `active`, `created_at`, `revoked_at`

### staff
`id`, `staff_id`, `name`, `mobile`, `role_id`, `status`, `joined_at`, `base_pay_type`, `base_pay_rate`, `created_at`, `updated_at`

### staff_roles
`id`, `name`, `permissions`, `created_at`

### services
The existing `service-catalog.js` remains the catalog source in this phase. A future migration can materialize it into a database collection without changing the public API.

### service_charges
Existing collection. Recommended fields: `category`, `service`, `govt_fee`, `csc_fee`, `other_fee`, `home_fee`, `delivery_fee`, `staff_commission`, `total`, `active`, `updated_at`.

### service_orders
`id`, `order_id`, `customer_id`, `service`, `category`, `mode`, `status`, `assigned_staff_id`, `application_id`, `token_id`, `created_at`, `completed_at`

### applications
Existing collection, later linked with `customer_id`, `service_order_id`.

### documents
`id`, `customer_id`, `service_order_id`, `document_type`, `storage_key`, `mime_type`, `size`, `status`, `uploaded_at`, `verified_at`, `verified_by`

### tokens
Existing collection, later linked with `customer_id`, `service_order_id`.

### payments
Existing collection, later normalized with `customer_id`, `service_order_id`, `official_fee`, `service_fee`, `home_fee`, `delivery_fee`, `total_amount`, `payment_method`, `utr`, `status`, `proof_key`, `verified_by`, `verified_at`.

### home_services
`id`, `home_service_id`, `service_order_id`, `customer_id`, `staff_id`, `visit_fee`, `travel_cost`, `status`, `scheduled_at`, `started_at`, `completed_at`

### deliveries
`id`, `delivery_id`, `service_order_id`, `customer_id`, `agent_id`, `customer_charge`, `actual_cost`, `status`, `assigned_at`, `delivered_at`

### commissions
`id`, `service_order_id`, `staff_id`, `commission_type`, `amount`, `status`, `created_at`, `settled_at`

### settlements
`id`, `settlement_id`, `payee_type`, `payee_id`, `gross_amount`, `deductions`, `net_amount`, `status`, `period_from`, `period_to`, `paid_at`

### expenses
`id`, `category`, `description`, `amount`, `expense_date`, `payment_method`, `created_by`, `created_at`

### complaints
`id`, `complaint_id`, `customer_id`, `service_order_id`, `priority`, `subject`, `description`, `assigned_to`, `status`, `created_at`, `resolved_at`

### service_sops / service_checklists
Per-service process instructions and required pre-submit checks.

### notifications / audit / offers
Existing collections retained and expanded later with explicit actor IDs and entity references.

## Financial rule
Never store one opaque "profit" number as the only financial record. Record each charge/cost separately, then calculate contribution and net profit from auditable entries.

## Security rule
PINs, sessions and QR secrets must be stored as hashes. Raw customer documents and payment proofs must remain outside public static paths and require role-based authorization.
