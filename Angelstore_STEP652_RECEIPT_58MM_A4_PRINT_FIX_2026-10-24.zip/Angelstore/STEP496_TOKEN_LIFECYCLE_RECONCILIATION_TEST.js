const fs=require('fs'),path=require('path'),os=require('os'),child=require('child_process'),http=require('http'),assert=require('assert');
const root=__dirname;const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'angelstore-step496-'));const port=18796;const user='step496admin',pass='Step496-Strong-Password-2026!';
const iso=new Date().toISOString();
const base={meta:{schema_version:2},settings:{centre:'Angelstore CSC',operator:'STEP496'},tokens:[
{id:1,token:'PAN-001',name:'Test Customer',mobile:'9876543210',service:'पैन सेवाएँ — New PAN application',status:'पूर्ण',created_at:iso,date:iso.slice(0,10),application_id:101,payment_id:201,state_revision:5,quality_status:'passed',completed_at:iso,last_action_at:iso},
{id:2,token:'PAN-002',name:'Broken Customer',mobile:'9876543211',service:'पैन सेवाएँ — New PAN application',status:'पूर्ण',created_at:iso,date:iso.slice(0,10),application_id:102,payment_id:202,state_revision:4,quality_status:'passed',completed_at:iso,last_action_at:iso}],payments:[
{id:201,name:'Test Customer',mobile:'9876543210',service:'पैन सेवाएँ — New PAN application',amount:100,payable_amount_snapshot:100,status:'Verified',receipt_no:'RCP-201',application_id:101},
{id:202,name:'Broken Customer',mobile:'9876543211',service:'पैन सेवाएँ — New PAN application',amount:100,payable_amount_snapshot:100,status:'Verified',receipt_no:null,application_id:102}],applications:[
{id:101,application_id:'APP-0101',name:'Test Customer',mobile:'9876543210',service:'पैन सेवाएँ — New PAN application',status:'Completed'},
{id:102,application_id:'APP-0102',name:'Broken Customer',mobile:'9876543211',service:'पैन सेवाएँ — New PAN application',status:'Completed'}],audit:[
{id:301,action:'TOKEN_GENERATED',token_id:1,state_revision:0,by:'admin',at:iso},{id:302,action:'STAFF_TASK_COMPLETE',token_id:1,state_revision:5,by:'EMP-1',at:iso}],notifications:[
{id:401,type:'token',severity:'success',title:'Service Completed',message:'done',mobile:'9876543210',token_id:1,event_key:'staff-token:1:5:complete',state_revision:5,created_at:iso}],staff:[]};
fs.writeFileSync(path.join(tmp,'data.json'),JSON.stringify(base));
const childProc=child.spawn(process.execPath,['server.js'],{cwd:root,env:{...process.env,PORT:String(port),HOST:'127.0.0.1',ANGELSTORE_STORAGE_DIR:tmp,ANGELSTORE_ADMIN_USER:user,ANGELSTORE_ADMIN_PASS:pass,ANGELSTORE_AUTH_SECRET:'step496-auth-secret-abcdefghijklmnopqrstuvwxyz-123456'},stdio:['ignore','pipe','pipe']});
function req(method,p,body,token){return new Promise((resolve,reject)=>{const r=http.request({hostname:'127.0.0.1',port,path:p,method,headers:{'Content-Type':'application/json',...(token||{})}},res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{let j={};try{j=JSON.parse(d)}catch{}resolve({status:res.statusCode,body:j,headers:res.headers})})});r.on('error',reject);if(body)r.write(JSON.stringify(body));r.end()})}
function sessionHeaders(resp){const set=resp.headers?.['set-cookie']||[];const jar=set.map(v=>v.split(';')[0]).join('; ');const csrfMatch=jar.match(/(?:^|; )angel_csrf=([^;]+)/);if(!jar.includes('angel_admin=')||!csrfMatch)throw Error('admin cookie/CSRF missing');return {Cookie:jar,'X-CSRF-Token':decodeURIComponent(csrfMatch[1])}}
(async()=>{try{for(let i=0;i<40;i++){try{await req('GET','/api/health');break}catch{}await new Promise(r=>setTimeout(r,100))}
let r=await req('POST','/api/auth/login',{username:user,password:pass});assert.equal(r.status,200);const tok=sessionHeaders(r);
r=await req('GET','/api/admin/token-lifecycle-reconcile?token_id=1',null,tok);assert.equal(r.status,200);assert.equal(r.body.ok,true);assert.equal(r.body.receipt_no,'RCP-201');assert(r.body.timeline.length>=3);
r=await req('GET','/api/admin/token-lifecycle-reconcile?token_id=2',null,tok);assert.equal(r.status,409);assert.equal(r.body.ok,false);assert(r.body.issues.some(x=>String(x).includes('receipt')));
r=await req('GET','/api/admin/token-lifecycle-reconcile?token_id=999',null,tok);assert.equal(r.status,404);
r=await req('GET','/api/admin/token-lifecycle-reconcile?token_id=1');assert.equal(r.status,401);
console.log('STEP496 TOKEN LIFECYCLE RECONCILIATION TEST: PASS (5/5)');}catch(e){console.error('STEP496 FAIL:',e.stack||e);process.exitCode=1}finally{childProc.kill('SIGTERM');setTimeout(()=>{try{fs.rmSync(tmp,{recursive:true,force:true})}catch{}},200)}})();
