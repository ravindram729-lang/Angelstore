const fs=require('fs');
const assert=require('assert');
const html=fs.readFileSync('customer.html','utf8');
const js=fs.readFileSync('customer.js','utf8');
const checks=[];
function pass(name,ok,detail=''){checks.push({name,ok,detail});if(!ok)throw new Error(name+(detail?': '+detail:''));}
pass('Status page exists',html.includes('id="page-customer-status"'));
for(const id of ['statusHeroToken','statusHeroService','statusHeroBadge','statusHeroCurrent','statusHeroAhead','statusHeroWait','statusHeroPosition','statusHorizontalSteps','statusPaymentBox','statusDocsFill','statusCurrentBox','statusLatestUpdates','statusReceiptBtn','statusApplicationId']) pass('Required status element '+id,html.includes(`id="${id}"`));
pass('Reference shell controls exist',html.includes('id="statusShellSearch"')&&html.includes('id="statusShellNotifications"')&&html.includes('id="statusShellTablet"')&&html.includes('id="statusShellMobile"'));
pass('Legacy status panel remains hidden',html.includes('.status-legacy-panel{display:none}'));
pass('Status shell scoped to customer status',js.includes("classList.toggle('status-reference-shell',page==='customer-status')"));
pass('Initial hash routing enabled',js.includes("const initialPage=(location.hash||'')"));
pass('Status refresh uses existing customer dashboard/progress APIs',js.includes("api('/api/customer/dashboard')")&&js.includes("api('/api/customer/progress')"));
pass('UPPCL workflow remains present',js.includes("api('/api/customer/uppcl/payment',{method"));
console.log(JSON.stringify({verdict:'PASS',checks},null,2));
