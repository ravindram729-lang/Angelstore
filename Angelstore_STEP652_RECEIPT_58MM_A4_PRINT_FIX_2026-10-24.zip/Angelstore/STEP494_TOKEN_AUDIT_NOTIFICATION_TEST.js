const fs=require('fs');
function ok(name,v){if(!v)throw new Error('FAIL: '+name);console.log('PASS: '+name)}
const s=fs.readFileSync('server.js','utf8');
ok('Token audit snapshot helper exists',/function tokenAuditSnapshot\(t\)/.test(s));
ok('Admin token audit stores before state',/action:'ADMIN_TOKEN_'.*?before:beforeTokenState/s.test(s));
ok('Admin token audit stores after state',/action:'ADMIN_TOKEN_'.*?after:afterTokenState/s.test(s));
ok('Staff token audit stores before/after state',/action:'STAFF_TASK_'.*?before:beforeTokenState.*?after:afterTokenState/s.test(s));
ok('Call action notifies customer',/'Token Called'/.test(s));
ok('Hold/resume actions notify customer',/'Token On Hold'/.test(s)&&/'Token Resumed'/.test(s));
ok('Skip/cancel actions notify customer',/'Token Skipped'/.test(s)&&/'Token Cancelled'/.test(s));
ok('Priority changes notify customer',/Priority Token Set/.test(s)&&/Priority Token Removed/.test(s));
ok('Notifications remain deduplicated by event key',/const existing=db\.notifications\.find\(n=>n\.mobile===mobile&&n\.event_key===eventKey\)/.test(s));
console.log('STEP494 TOKEN AUDIT + NOTIFICATION TEST: PASS (9/9)');
