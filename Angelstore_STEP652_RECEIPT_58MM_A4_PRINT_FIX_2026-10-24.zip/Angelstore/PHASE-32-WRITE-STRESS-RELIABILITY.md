# Phase 32 — Write-Heavy Stress & Reliability Test

## Scope

This phase starts from the Phase 31 codebase and exercises the real write workflow against an isolated disposable JSON storage directory. No production data was used.

Workflow tested:

1. Customer application creation
2. UPI payment submission with screenshot data
3. Duplicate UTR protection
4. Admin authentication
5. Payment proof viewing
6. Manual payment verification
7. Concurrent token generation attempts for the same payment
8. Normal token generation for the remaining payments
9. Database integrity verification

## Test environment

- Node.js HTTP server
- Local base URL: `http://127.0.0.1:8092`
- Isolated `ANGELSTORE_STORAGE_DIR`
- Isolated payment-upload directory
- Isolated backup directory
- 19 concurrent customer applications (10 workers)
- 19 concurrent payment submissions
- 20 concurrent token-generation attempts against one payment
- 18 additional token generations

## Measured result

| Check | Result |
|---|---:|
| Applications created | 19/19 |
| Payment submissions | 19/19 |
| Concurrent duplicate-token attempts | 20 |
| Token race successes | 1 |
| Token race conflicts | 19 |
| Duplicate UTR first request | HTTP 200 |
| Duplicate UTR second request | HTTP 409 |
| Normal token generations | 18/18 |
| Final tokens | 19 |
| Final payments | 20 (includes duplicate-UTR test payment) |
| Duplicate token after completion | HTTP 409 |
| Database integrity | PASS |
| Broken payment→token links | 0 |
| Broken token→payment links | 0 |
| Duplicate IDs | 0 |
| Orphan customer sessions | 0 |
| Elapsed workflow test | ~127.79 ms |

## Bug discovered and fixed

The stress test exposed a real backend defect in the admin token-generation route: the route called `a.user` without defining `a` in that route scope. Under successful authenticated token issuance this produced HTTP 500 responses.

The route was corrected to obtain the authenticated admin object once and use it for the audit record. After the fix, the complete write-heavy test passed.

This was a real implementation defect, not a test-only mock failure.

## Reliability conclusion

For this isolated single-process benchmark, the tested application/payment/token workflow completed without data corruption and correctly prevented duplicate UTR and duplicate token creation, including a 20-request concurrent token race.

This does **not** prove production capacity. The current JSON/file storage architecture still requires further testing for long-duration write load, large payment-proof files, backup/restore overlap, and multi-instance deployment. Production traffic should continue to use a single persistent storage instance unless the storage architecture is deliberately migrated to a transactional database.

## Not verified

- Actual Render persistent-disk network latency
- Netlify → Render production path
- Multiple Node.js instances sharing the same JSON file
- Large real-world image uploads under load
- Long-duration soak testing
- Backup and restore while writes are actively occurring
- External off-site backup service under concurrent load

## Files changed

- `server.js` — fixed authenticated admin token route variable handling
- `PHASE-32-WRITE-STRESS-TEST.js` — repeatable isolated write-stress test
- `PHASE-32-WRITE-STRESS-RESULT.json` — measured result from the successful run
- `PHASE-32-WRITE-STRESS-RELIABILITY.md` — this report

No database schema change was required.
