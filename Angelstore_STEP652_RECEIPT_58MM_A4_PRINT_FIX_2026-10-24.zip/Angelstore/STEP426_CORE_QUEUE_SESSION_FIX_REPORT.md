# STEP426 — Core Queue + Session State Fix

## Scope
No database schema redesign. No cart/order architecture added.

## Changes
- Customer live-queue endpoint now supports service-scoped queue data and only scopes to services owned by the authenticated customer.
- Admin token endpoint now exposes `current_by_service` in addition to legacy aggregate fields.
- Customer frontend now uses the authenticated customer's active service queue instead of calculating/displaying the global queue.
- Customer frontend no longer uses the global queue to derive `Ahead of You` or wait values; backend token metadata remains authoritative.
- Logout clears application/payment/token/selected-service/guest workflow localStorage state.
- Session-expiry handling clears the same workflow namespace.
- Document UI gate now checks that the locally stored current token actually exists in the authenticated dashboard token list before enabling the document flow.

## Verification
- `node --check server.js` PASS
- `node --check customer.js` PASS
- `/api/health` PASS
- `/api/services` PASS
- unauthenticated `/api/customer/live-queue` returns 401 PASS
- unauthenticated `/api/tokens` returns 401 PASS

## Not changed in this step
- Service pricing model
- Payment verification rules
- Token-before-documents business rule
- Database schema
- Production secrets/configuration
