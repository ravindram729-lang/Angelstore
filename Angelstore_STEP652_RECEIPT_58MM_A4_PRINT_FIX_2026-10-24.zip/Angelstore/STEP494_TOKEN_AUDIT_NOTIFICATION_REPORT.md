# STEP494 — Token Queue Audit Trail + Notification Consistency

## Scope
Harden the existing Token Queue workflow so Admin/Staff token actions have a reliable before/after audit trail and customer-facing notifications remain consistent for state-changing actions. No approved UI design, cart-free workflow, payment rules, or core token controls were removed.

## Root causes addressed
1. Token action audit records previously stored the resulting state but did not consistently retain the exact before-state and after-state snapshot.
2. Several Admin token actions changed state without a customer notification (call, hold, resume, skip, cancel, priority).
3. Audit and notification behavior needed deterministic, deduplicated event keys so live customer status and notification history remain aligned.

## Fixes
- Added `tokenAuditSnapshot()` server helper.
- Admin token actions now record `before` and `after` token snapshots in the audit record, including status, state revision, staff, priority and relevant hold/skip/cancel/recall metadata.
- Staff token actions now record the same before/after snapshots.
- Added customer notifications for Admin:
  - Token Called
  - Token On Hold
  - Token Resumed
  - Token Skipped
  - Token Cancelled
  - Priority Token Set/Removed
- Existing Recall, Processing, Assignment/Transfer and Completion notifications remain in place.
- Notification event keys remain deduplicated through the existing `notifyCustomer()` mechanism.
- Existing STEP492 state-revision and request-id concurrency protection remains unchanged.

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- STEP494 targeted audit/notification test — PASS (9/9)
- STEP493 conflict UI regression — PASS (7/7)
- STEP492 concurrency regression — PASS (8/8)
- STEP491 live-refresh regression — PASS (7/7)
- STEP490 assignment/transfer regression — PASS (11/11)
- P0/P1 regression — PASS (6/6)
- Final release audit — PASS
- ZIP integrity — PASS

## Browser verification limitation
A fresh live Chromium click-by-click visual verification is not claimed because the execution environment blocks normal localhost navigation. Server-side/static tests and isolated workflow regressions were used instead.

## Production gate
This is a local code/workflow verification PASS. Production secrets, deployed host configuration, and live hosted E2E remain separate operational gates.
