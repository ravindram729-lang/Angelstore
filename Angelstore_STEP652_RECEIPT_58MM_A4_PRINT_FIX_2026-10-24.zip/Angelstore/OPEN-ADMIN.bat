@echo off
call "%~dp0START-ANGELSTORE.bat"
