# STEP509 — Token Generate Step 6 Visible/Locked Fix

## Change
- Step 6 Documents card is now always visible in the supplied reference layout.
- Before Live Token: upload action remains locked/disabled and shows the correct prerequisite note.
- After Live Token: the same card unlocks and opens Customer Documents.
- Existing document upload backend flow was not changed.
- Existing payment, verification, token generation and queue handlers were not changed.

## Layout
- Left column: Steps 1, 2, 3, 6.
- Right column: Payment methods, Step 5 payment proof, Step 7 next workflow.
- Generated Token remains full-width below.

## Verification
- STEP507 reference gap test: 12/12 PASS.
- customer.js syntax check: PASS.
