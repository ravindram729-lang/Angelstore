const fs=require('fs');
const path=require('path');
const root=__dirname;
const customer=fs.readFileSync(path.join(root,'customer.js'),'utf8');
const html=fs.readFileSync(path.join(root,'customer.html'),'utf8');
const checks=[
 ['retry function exists',/function openRechargeRetry\(r\)/.test(customer)],
 ['retry only Failed + retryable',/r\.status!=='Failed'\|\|!r\.retryable/.test(customer)],
 ['retry modal has dialog semantics',/role="dialog" aria-modal="true" aria-labelledby="rechargeRetryTitle"/.test(customer)],
 ['source attempt summary visible',/retry-source-card/.test(customer)&&/Previous attempt/.test(customer)],
 ['new UTR input constrained 6-40',/minlength="6" maxlength="40"/.test(customer)],
 ['screenshot accepts png jpeg webp',/image\/png,image\/jpeg,image\/webp/.test(customer)],
 ['screenshot max 5MB enforced',/5\*1024\*1024/.test(customer)],
 ['inline validation status accessible',/role="status" aria-live="polite"/.test(customer)],
 ['submit button locks during request',/btn\.disabled=true/.test(customer)&&/aria-busy/.test(customer)],
 ['duplicate/server errors remain visible',/setStatus\(msg,true\)/.test(customer)],
 ['success refreshes records',/loadRecords\(\{silent:true\}\)/.test(customer)],
 ['Escape closes retry modal',/const onKey=e=>\{if\(e\.key==='Escape'\)\{e\.preventDefault\(\);close\(\)/.test(customer)],
 ['mobile modal width hardening',/@media\(max-width:430px\)[\s\S]*service-detail-dialog/.test(html)],
 ['mobile table contained in horizontal scroller',/\.cr-table-wrap\{width:100%;max-width:100%;overflow-x:auto/.test(html)],
 ['mobile action buttons use compact grid',/@media\(max-width:430px\)[\s\S]*\.cr-table-actions\{display:grid/.test(html)],
 ['no cart/order dependency',!/cart|order/i.test(customer.match(/function openRechargeRetry[\s\S]*?(?=\nfunction|$)/)?.[0]||'')]
];
let pass=0; for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} — ${name}`); if(ok)pass++;}
const report={step:'STEP535',total:checks.length,passed:pass,failed:checks.length-pass,ok:pass===checks.length,checks:checks.map(([name,ok])=>({name,ok}))};
fs.writeFileSync(path.join(root,'STEP535_RECHARGE_RETRY_UX_MOBILE_AUDIT_REPORT.md'),`# STEP535 — Recharge Retry UX & Mobile Audit\n\n${pass}/${checks.length} PASS\n\n`+checks.map(([n,o],i)=>`${i+1}. **${o?'PASS':'FAIL'}** — ${n}`).join('\n')+'\n');
fs.writeFileSync(path.join(root,'STEP535_RECHARGE_RETRY_UX_MOBILE_AUDIT_REPORT.json'),JSON.stringify(report,null,2));
process.exit(report.ok?0:1);
