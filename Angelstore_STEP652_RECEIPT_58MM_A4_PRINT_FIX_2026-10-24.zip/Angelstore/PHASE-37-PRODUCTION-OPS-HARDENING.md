# Phase 37 — Production Operations & Admin Hardening

## Scope

This phase hardens the operational release process without changing the existing business workflow or database schema.

## Added

- `PRODUCTION-OPS-AUDIT.js`
- `npm run ops-audit`
- Production operator checklist for secrets, backups, off-site backup, alerts and persistent storage.
- Secret-safe configuration checks; secret values are never printed.

## Gates

The operations audit checks:

1. `NODE_ENV=production`
2. Auth secret length and basic entropy
3. Admin username/password configuration
4. Known development/default password rejection
5. Explicit HTTPS CORS origin
6. Absolute persistent storage path
7. Scheduled backup configuration
8. Off-site backup URL + token
9. Alert webhook configuration
10. `.env.example` does not contain development credentials

## Verification

Run:

```bash
npm run check
npm run preflight
npm run release-audit
npm run deployment-verify
npm run ops-audit
```

`ops-audit` is intentionally strict. It is expected to fail until the real production environment contains the required operational secrets and integrations.

## Production operator checklist

- [ ] Set a unique random `ANGELSTORE_AUTH_SECRET` (>=32 characters).
- [ ] Set a unique admin username and strong password (>=12 characters).
- [ ] Keep production secrets only in the hosting provider's environment/secret store.
- [ ] Set exact Netlify/frontend HTTPS origin in `ANGELSTORE_CORS_ORIGIN`.
- [ ] Set `ANGELSTORE_STORAGE_DIR` to the persistent disk mount.
- [ ] Enable scheduled backups.
- [ ] Configure an authenticated off-site backup destination.
- [ ] Configure an alert webhook if incident notifications are required.
- [ ] Confirm `/api/health` returns `ok:true` after deployment.
- [ ] Run `npm run deployment-verify` from an environment that can reach the live domains.
- [ ] Perform a controlled login, payment-proof upload, verification and token workflow test.

## Important limitation

This phase does not claim that Render, Netlify, an off-site backup provider, or an alert provider is live. Those require access to the actual deployed environment and provider accounts.
