# STEP438 — Architecture P0/P1 Fix Report

Date: 2026-09-27

## Scope
Implemented targeted fixes after the STEP437 full-project audit. No database migration was performed.

## Fixed
1. Customer payment verification now polls every 5 seconds while payment remains pending and stops automatically on Verified/Rejected.
2. LIVE SCREEN offers now carry an offer ID into the customer payment request.
3. Backend validates the selected offer server-side (published, active dates, matching service, valid offer price) and snapshots the actual offer price as payable amount.
4. Offer-selected amount is restored after service charge loading so the UI cannot silently replace it with the normal service charge.
5. Service configuration now respects `custom_services.appointment` as the source for custom-service appointment requirements.
6. Token generation now blocks appointment-required services until the customer's appointment is explicitly `स्वीकृत` or `पुष्टि`.
7. Customer appointment creation now prevents duplicate requests for the same customer/service/date/time while an existing request is active.
8. Added admin appointment API for listing and changing appointment status.
9. Added a minimal Admin appointment management panel with status controls.
10. Queue current-token selection now uses the same priority/ID ordering rule instead of first-array-match behavior.

## Not migrated in this step
- JSON storage to relational database migration
- Distributed OCR worker/queue
- SSE/WebSocket real-time transport
- Full frontend/backend modularization
- Complete browser E2E suite
- Full accessibility pass
- Off-site encrypted backup enforcement

Those require separate architecture changes and were intentionally not mixed into this targeted fix step.

## Verification
- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- `node --check app.js` — PASS
- `npm run check` — PASS
- `npm run release-audit` — PASS
- Runtime health endpoint — PASS
- Customer appointment creation + duplicate protection — PASS
