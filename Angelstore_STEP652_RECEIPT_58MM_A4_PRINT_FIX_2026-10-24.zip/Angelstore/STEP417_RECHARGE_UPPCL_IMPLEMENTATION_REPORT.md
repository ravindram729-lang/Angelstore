# STEP417 — Recharge + UPPCL Service Modules

## Scope
Implemented the approved Recharge + UPPCL responsive UI concept on top of STEP416 without changing the existing Token Generate workflow.

## Added
- Dedicated Customer Mobile Recharge page.
- Dedicated Customer UPPCL Bill Payment page.
- Desktop + mobile responsive layouts.
- Operator selector: Jio, Airtel, Vi, BSNL.
- Prepaid/Postpaid selector.
- Circle selector.
- Recharge plan cards with fallback catalog examples.
- Server-side live plan provider adapter.
- Recharge initiation provider adapter.
- UPPCL account/mobile bill lookup provider adapter.
- UPPCL payment provider adapter.
- Smart Meter recharge UI placeholder with provider gate.
- Status and history placeholders.
- Provider configuration through server-side environment variables only.

## Important live-integration note
The project did not contain an authorized Recharge or UPPCL provider credential/configuration. Therefore the code does NOT fake live plans, bill amounts, or successful transactions.

When configured, these server-side variables activate the live provider adapters:
- ANGELSTORE_RECHARGE_PLANS_URL
- ANGELSTORE_RECHARGE_INITIATE_URL
- ANGELSTORE_RECHARGE_PROVIDER_TOKEN
- ANGELSTORE_UPPCL_BILL_URL
- ANGELSTORE_UPPCL_PAYMENT_URL
- ANGELSTORE_UPPCL_PROVIDER_TOKEN

## Verification
- node --check customer.js: PASS
- node --check server.js: PASS
- customer.html parse: PASS
- duplicate HTML IDs: 0
- local /api/health: HTTP 200
- local /api/recharge/plans without provider: HTTP 200, explicit provider_configured=false
- Existing Token Generate page was not removed or rewritten.
