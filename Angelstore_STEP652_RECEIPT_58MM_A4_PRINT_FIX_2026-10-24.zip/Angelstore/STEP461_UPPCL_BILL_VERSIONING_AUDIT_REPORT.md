# STEP461 — UPPCL Bill Versioning / Stale-Bill Protection

## Objective
Prevent a customer from submitting payment against an older fetched UPPCL bill after Admin updates that bill.

## Changes
- Added immutable bill `id` + incrementing `version` to customer bill lookup response.
- Existing manual bill records start at version `1`; every Admin update increments the version.
- Customer payment submission now requires `bill_id` and `bill_version`.
- Backend compares the submitted bill id/version with the current Admin-approved bill before accepting payment proof.
- Stale bill submissions return HTTP `409` and require the customer to fetch the latest bill again.
- UPPCL application/payment snapshots store `uppcl_bill_id` and `uppcl_bill_version` for audit traceability.
- Customer frontend stores the bill identity/version returned by lookup and sends it with payment proof.
- Existing amount, bill-month, due-date, customer-mobile, UTR, screenshot and duplicate-payment protections remain active.

## Verification
- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- `node STEP456_UPPCL_SECURITY_E2E.js` — PASS
  - Includes stale-bill rejection after an Admin bill update, then successful submission using the latest bill version.
- `node P0-P1-REGRESSION-TEST.js` — PASS
- `npm run release-audit` — PASS
- ZIP integrity — PASS

## Browser note
No fresh live Chromium visual PASS is claimed because the execution environment previously blocked/hung localhost browser access.
