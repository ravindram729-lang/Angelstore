# PHASE 27 — Backup / Restore + Disaster Recovery Audit

## Scope
Audited the Phase 26 Render production configuration, focusing on whether database records and payment proof files can be backed up and restored safely.

## Findings and fixes

### 1. Backup previously covered only `data.json`
The existing backup endpoint created a JSON database backup, but payment proof images under the payment upload directory were not part of the backup.

**Fix:** each new backup now creates a sibling upload snapshot directory and copies payment-proof image files into it with SHA-256 checksums in `manifest.json`.

### 2. Restore could restore stale authentication sessions
A restored database could contain old admin, staff, or customer sessions.

**Fix:** restore now explicitly clears `admin_sessions`, `staff_sessions`, and `customer_sessions` after loading the backup. Users must authenticate again after a restore.

### 3. Payment proof integrity during restore
Restore now validates the upload manifest, filename format, file existence, and SHA-256 checksum before copying payment proofs back into the active payment upload directory.

### 4. Restore safety backup
Before applying a restore, the current state is backed up first. This preserves a pre-restore recovery point.

### 5. Backup visibility
Admin backup listing now reports the number of payment proof files included in each snapshot. Backup creation response also returns that count.

## Verification

- `node --check server.js` — PASS
- Production `/api/health` — PASS
- Admin backup authorization — PASS
- Backup creation — PASS
- JSON database backup created — PASS
- Payment proof snapshot created — PASS
- Payment proof SHA-256 manifest created — PASS
- Database mutation followed by restore — PASS
- Original token record restored — PASS
- Payment proof restored — PASS
- Restored payment proof content verified — PASS
- Admin sessions cleared on restore — PASS
- Staff sessions cleared on restore — PASS
- Customer sessions cleared on restore — PASS
- Pre-restore backup created — PASS

## Important production limitation
A backup snapshot stored on the same persistent disk is protection against application/database corruption and accidental changes, but it is **not** protection against loss of the entire disk or hosting account.

For true disaster recovery, backups should also be copied to an independent external storage provider on a scheduled basis. This phase does not invent or configure an external provider without credentials/access.

## Data/schema policy
No existing business collections were removed and no business schema was rewritten. The change is additive and backward-compatible for existing JSON backups that do not contain payment-proof snapshots.
