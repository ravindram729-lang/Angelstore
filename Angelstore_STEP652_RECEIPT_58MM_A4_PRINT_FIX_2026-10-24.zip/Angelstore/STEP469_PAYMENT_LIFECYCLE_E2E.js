const fs=require('fs'),path=require('path'),http=require('http'),child=require('child_process');
const ROOT=__dirname,TMP=path.join(ROOT,'.step469-payment-lifecycle-e2e');
fs.rmSync(TMP,{recursive:true,force:true});fs.mkdirSync(TMP,{recursive:true});
const env={...process.env,PORT:'8039',ANGELSTORE_STORAGE_DIR:TMP,ANGELSTORE_AUTH_SECRET:'step469-lifecycle-secret-12345678901234567890',ANGELSTORE_ADMIN_USER:'testadmin',ANGELSTORE_ADMIN_PASS:'TestAdmin!12345'};
const proc=child.spawn(process.execPath,[path.join(ROOT,'server.js')],{cwd:ROOT,env,stdio:['ignore','pipe','pipe']});let out='';proc.stdout.on('data',d=>out+=d);proc.stderr.on('data',d=>out+=d);
const BASE='http://127.0.0.1:8039';
function req(method,p,body,headers={}){return new Promise((resolve,reject)=>{const u=new URL(p,BASE),b=body===undefined?null:Buffer.from(JSON.stringify(body));const r=http.request({method,hostname:u.hostname,port:u.port,path:u.pathname+u.search,headers:{...(b?{'Content-Type':'application/json','Content-Length':b.length}:{}),...headers}},res=>{let s='';res.on('data',c=>s+=c);res.on('end',()=>{let data;try{data=s?JSON.parse(s):null}catch{data=s}resolve({status:res.statusCode,data,headers:res.headers})})});r.on('error',reject);if(b)r.write(b);r.end()})}
function sessionHeaders(resp,requiredCookie){const set=resp.headers?.['set-cookie']||[];const jar=set.map(v=>v.split(';')[0]).join('; ');const csrfMatch=jar.match(/(?:^|; )angel_csrf=([^;]+)/);if(!jar.includes(requiredCookie+'='))throw Error('missing '+requiredCookie+' cookie');if(!csrfMatch)throw Error('missing CSRF cookie');return {Cookie:jar,'X-CSRF-Token':decodeURIComponent(csrfMatch[1])}}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const png1='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC'; const png2='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGNg+M8AAAICAQB7CYF4AAAAAElFTkSuQmCC';
(async()=>{try{
 for(let i=0;i<50;i++){try{const h=await req('GET','/api/health');if(h.status===200)break}catch{}await sleep(100)}
 let r=await req('POST','/api/auth/login',{username:'testadmin',password:'TestAdmin!12345'});if(r.status!==200)throw Error('admin login '+JSON.stringify(r.data));const A=sessionHeaders(r,'angel_admin');
 r=await req('POST','/api/customer/register',{name:'Lifecycle Customer',mobile:'9000012399',pin:'2468'});if(r.status!==201)throw Error('customer register '+JSON.stringify(r.data));const C=sessionHeaders(r,'angel_customer');
 r=await req('POST','/api/admin/uppcl/manual-bill',{account:'1234567899',registered_mobile:'9000012399',consumer_name:'Lifecycle Customer',bill_number:'LIFE-469',bill_amount:1000,arrear:100,late_fee:20,total_amount:1120,bill_month:'October 2026',due_date:'20/10/2026',district:'Prayagraj',discom:'PuVVNL'},A);if(r.status!==200)throw Error('bill '+JSON.stringify(r.data));
 r=await req('GET','/api/customer/uppcl/manual-bill?mode=account&value=1234567899',undefined,C);if(r.status!==200)throw Error('bill lookup '+JSON.stringify(r.data));
 const bill=r.data.bill;
 r=await req('POST','/api/customer/uppcl/payment',{account:'1234567899',bill_id:bill.id,bill_version:bill.version,amount:1120,bill_month:bill.bill_month,due_date:bill.due_date,district:'Prayagraj',discom:'PuVVNL',utr:'LIFE-469-001',screenshot:'data:image/png;base64,'+png1,idempotency_key:'life469-001-abcdef123456'},C);if(r.status!==200)throw Error('payment '+JSON.stringify(r.data));const pid=r.data.payment.id;
 // Payment Pending Verification -> Rejected is valid; Rejected -> Verified is blocked.
 r=await req('POST','/api/payments/status',{id:pid,status:'Rejected',reason:'Lifecycle test'},A);if(r.status!==200)throw Error('reject transition '+JSON.stringify(r.data));
 r=await req('POST','/api/payments/status',{id:pid,status:'Verified'},A);if(r.status!==409)throw Error('verify after reject was not blocked '+JSON.stringify(r.data));
 // Fresh payment: Pending Verification -> Verified -> UPPCL Completed; terminal reverse transitions blocked.
 r=await req('POST','/api/admin/uppcl/manual-bill',{account:'1234567888',registered_mobile:'9000012399',consumer_name:'Lifecycle Customer',bill_number:'LIFE-469-B',bill_amount:1000,arrear:0,late_fee:0,total_amount:1000,bill_month:'October 2026-B',due_date:'21/10/2026',district:'Prayagraj',discom:'PuVVNL'},A);if(r.status!==200)throw Error('bill2 '+JSON.stringify(r.data));
 r=await req('GET','/api/customer/uppcl/manual-bill?mode=account&value=1234567888',undefined,C);const b2=r.data.bill;
 r=await req('POST','/api/customer/uppcl/payment',{account:'1234567888',bill_id:b2.id,bill_version:b2.version,amount:1000,bill_month:b2.bill_month,due_date:b2.due_date,district:'Prayagraj',discom:'PuVVNL',utr:'LIFE-469-002',screenshot:'data:image/png;base64,'+png2,idempotency_key:'life469-002-abcdef123456'},C);if(r.status!==200)throw Error('payment2 '+JSON.stringify(r.data));const pid2=r.data.payment.id;
 r=await req('POST','/api/admin/uppcl/process',{id:pid2,status:'Completed'},A);if(r.status!==409)throw Error('process before verify not blocked '+JSON.stringify(r.data));
 r=await req('GET','/api/payments/proof/'+pid2,undefined,A);if(r.status!==200)throw Error('proof view '+JSON.stringify(r.data));
 r=await req('POST','/api/payments/status',{id:pid2,status:'Verified'},A);if(r.status!==200)throw Error('verify2 '+JSON.stringify(r.data));
 r=await req('POST','/api/admin/uppcl/process',{id:pid2,status:'Completed',provider_ref:'LIFE469-PROVIDER'},A);if(r.status!==200||r.data.processing_status!=='Completed')throw Error('complete2 '+JSON.stringify(r.data));
 r=await req('POST','/api/admin/uppcl/process',{id:pid2,status:'Failed'},A);if(r.status!==409)throw Error('fail after complete not blocked '+JSON.stringify(r.data));
 // Recharge Pending -> Failed is valid; Failed -> Success is terminal and blocked.
 r=await req('POST','/api/recharge/manual',{mobile:'9000012399',operator:'JIO',type:'PREPAID',circle:'UP',amount:299,status:'Pending',plan_id:'LIFE469-R',plan_name:'Lifecycle Recharge'},A);if(r.status!==201)throw Error('recharge create '+JSON.stringify(r.data));const rid=r.data.transaction.id;
 r=await req('POST','/api/recharge/manual/'+rid,{status:'Failed',notes:'Lifecycle provider failure'},A);if(r.status!==200||r.data.transaction.status!=='Failed')throw Error('recharge fail transition '+JSON.stringify(r.data));
 r=await req('POST','/api/recharge/manual/'+rid,{status:'Success'},A);if(r.status!==409)throw Error('recharge failed->success was not blocked '+JSON.stringify(r.data));
 // Lifecycle audit endpoint should be clean for known valid states.
 r=await req('GET','/api/admin/payment-lifecycle',undefined,A);if(r.status!==200)throw Error('lifecycle audit '+JSON.stringify(r.data));
 if(r.data.issue_count!==0)throw Error('unexpected lifecycle audit issues '+JSON.stringify(r.data));
 console.log(JSON.stringify({ok:true,checks:{payment_reject_terminal:true,verify_after_reject_blocked:true,uppcl_process_before_verify_blocked:true,uppcl_completed_terminal:true,fail_after_complete_blocked:true,recharge_terminal_transition_blocked:true,lifecycle_audit_clean:true}},null,2));
}catch(e){console.error(JSON.stringify({ok:false,error:e.message,server_output:out},null,2));process.exitCode=1}finally{proc.kill('SIGTERM');setTimeout(()=>{try{fs.rmSync(TMP,{recursive:true,force:true})}catch{}},300)}})();
