const fs=require('fs'),path=require('path');
const root=__dirname, server=fs.readFileSync(path.join(root,'server.js'),'utf8'), app=fs.readFileSync(path.join(root,'app.js'),'utf8'), html=fs.readFileSync(path.join(root,'admin.html'),'utf8');
const checks=[
 ['observability endpoint remains admin protected',/\/api\/admin\/recharge-retry-observability.*admin\(req\)/s.test(server)],
 ['endpoint returns observability snapshot',/\/api\/admin\/recharge-retry-observability.*observability:rechargeRetryObservability\(\)/s.test(server)],
 ['monitoring page calls observability endpoint',/api\/admin\/recharge-retry-observability/.test(app)],
 ['monitoring request includes endpoint in Promise.all',/Promise\.all\(\[api\('\/api\/admin\/monitoring'\),api\('\/api\/admin\/incidents'\),api\('\/api\/admin\/recharge-retry-observability'\)\]\)/.test(app)],
 ['retry total metric rendered',/retryObsTotal/.test(app)&&/retryObsTotal/.test(html)],
 ['retry group metric rendered',/retryObsGroups/.test(app)&&/retryObsGroups/.test(html)],
 ['pending success failed metrics rendered',/retryObsPending/.test(app)&&/retryObsSuccess/.test(app)&&/retryObsFailed/.test(app)],
 ['payment rejection metric rendered',/retryObsRejects/.test(app)&&/Payment Rejections/.test(html)],
 ['24h submissions detail rendered',/last_24h_submissions/.test(app)&&/Last 24h submissions/.test(app)],
 ['recovery incident detail rendered',/open_recovery_incidents/.test(app)&&/Open recovery incidents/.test(app)],
 ['webhook failure detail rendered',/alert_webhook_failures/.test(app)&&/Alert webhook failures/.test(app)],
 ['no customer observability endpoint',!server.includes('/api/customer/recharge-retry-observability')],
 ['no cart/order dependency introduced',!/recharge-retry-observability[\s\S]{0,1000}(cart|order)/i.test(server+app+html)],
 ['escaped checked timestamp',/escapeHtml\(rro\.checked_at/.test(app)]
];
const passed=checks.filter(x=>x[1]).length;
const report={step:'STEP541',scope:'Recharge Retry Admin Dashboard/UI Integration',total:checks.length,passed,failed:checks.length-passed,ok:passed===checks.length,checks:checks.map(x=>({name:x[0],ok:x[1]}))};
fs.writeFileSync(path.join(root,'STEP541_RECHARGE_RETRY_ADMIN_DASHBOARD_AUDIT_REPORT.json'),JSON.stringify(report,null,2));
fs.writeFileSync(path.join(root,'STEP541_RECHARGE_RETRY_ADMIN_DASHBOARD_AUDIT_REPORT.md'),`# STEP541 — Recharge Retry Admin Dashboard/UI Integration\n\n**${passed}/${checks.length} PASS**\n\n`+checks.map((x,i)=>`${i+1}. **${x[1]?'PASS':'FAIL'}** — ${x[0]}`).join('\n')+'\n');
console.log(`${passed}/${checks.length} PASS`); if(passed!==checks.length)process.exit(1);
