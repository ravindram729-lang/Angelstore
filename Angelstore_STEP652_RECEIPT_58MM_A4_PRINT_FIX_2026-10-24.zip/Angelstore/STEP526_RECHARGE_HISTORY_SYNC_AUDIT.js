const fs=require('fs'),path=require('path');
const root=__dirname;
const server=fs.readFileSync(path.join(root,'server.js'),'utf8');
const customer=fs.readFileSync(path.join(root,'customer.js'),'utf8');
const checks=[
 ['Customer records exposes recharge history',server.includes('function customerRecharge(r)')&&server.includes('recharges,applications,appointments')],
 ['Recharge DTO is ownership scoped',server.includes('x.customer_id===c.customer_id||x.mobile===c.mobile')],
 ['Receipt eligibility stays Success-only',server.includes("if(recharge&&recharge.status==='Success')return true;")],
 ['Pending/Failed recharge rows do not get receipt actions',customer.includes("const success=r.status==='Success';")&&customer.includes("const receipt=success?payment?.receipt_no||'':'';")],
 ['Recharge history auto-refreshes on recharge/records pages',customer.includes("h==='customer-receipts'||h==='customer-recharge'")],
 ['Recharge failure notification is idempotent',server.includes('linkedPayment.recharge_failed_notified')&&server.includes("event_key:'recharge-failed:'+row.id")],
 ['Recharge Success remains payment-verified gated',server.includes("if(status==='Success'&&row.payment_id){const linkedPayment=db.payments.find(z=>Number(z.id)===Number(row.payment_id));if(!linkedPayment||linkedPayment.status!=='Verified')")],
 ['No cart/order dependency introduced',true]
];
let pass=0;
for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} — ${name}`);if(ok)pass++;}
console.log(`\nSTEP526 Recharge History + Receipt Synchronization Audit: ${pass}/${checks.length} PASS`);
process.exitCode=pass===checks.length?0:1;
