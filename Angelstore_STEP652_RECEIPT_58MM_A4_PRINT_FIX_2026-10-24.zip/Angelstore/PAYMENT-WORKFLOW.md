# AngelStore CSC — Payment + Sub-category Workflow

1. Customer opens **सभी सेवाएँ**.
2. Customer selects any category.
3. All configured sub-categories are shown. This build contains the 106 catalog sub-services.
4. Customer opens a sub-service and clicks **इस Service का Token लें**.
5. The exact `Category — Sub-service` is carried into the payment form.
6. The payable amount is calculated from Admin Service Charges, with the catalog government/portal fee used as the default when no override exists.
7. Customer pays to the configured UPI account and submits:
   - UTR / Transaction Number
   - Payment screenshot (PNG/JPG/WEBP, max 5 MB)
8. Admin opens **भुगतान** and must open the screenshot proof before the **Verify** button becomes active.
9. Admin checks the screenshot and UTR against the actual payment, then verifies or rejects the payment.
10. Only a verified payment matching customer name, mobile, service and amount can generate a live token.
11. One verified payment can generate only one token.
12. Customer sees the verification status and can generate the live token after approval.

## Local use
- Start the server with `START-ANGELSTORE.bat` (or `START-CUSTOMER.bat` / `START-ADMIN.bat`).
- If `customer.html` is opened directly as a file, it now falls back to browser-local storage for the demo flow, or redirects to the local server when it is running.

## Production
Automatic bank/UPI verification is not fabricated. Admin verification is manual unless a real payment-provider/bank API is integrated.


## UPI + QR payment
Customer payment now provides both:
- UPI App deep-link using `9580773041@kotakbank`
- The supplied QR image (`assets/payment-qr.jpg`)
- Dynamic payable amount in the UPI deep-link
- Copy UPI ID action

The QR decodes to:
`upi://pay?pa=9580773041@kotakbank&pn=RAVINDRA%20KUMAR%20MAURYA`

## STEP425 authoritative payment/token rule

Digital payment proof may be submitted with **UTR OR screenshot OR both**. At least one is required for UPI/Bank Transfer.

After Admin verifies the payment, the **Live Token may be generated immediately**. Required documents are **not** a token-generation prerequisite. Documents are uploaded and verified **after** the Live Token is generated.
