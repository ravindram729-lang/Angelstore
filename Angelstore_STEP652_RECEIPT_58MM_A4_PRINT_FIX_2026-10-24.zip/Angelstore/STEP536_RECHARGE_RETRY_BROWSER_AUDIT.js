const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=__dirname, customer=fs.readFileSync(path.join(root,'customer.js'),'utf8'), html=fs.readFileSync(path.join(root,'customer.html'),'utf8');
const checks=[
 ['retry dialog has descriptive relationship',/aria-describedby="rechargeRetryHelp"/.test(customer)&&/id="rechargeRetryHelp"/.test(customer)],
 ['retry dialog traps keyboard focus',/const focusables=\(\)=>/.test(customer)&&/e\.key==='Tab'/.test(customer)],
 ['Escape closes and restores previous focus',/previousActive=document\.activeElement/.test(customer)&&/previousActive\?\.focus/.test(customer)],
 ['retry modal locks background scroll',/lockBody\(\)/.test(customer)&&/unlockBody\(\)/.test(customer)&&/\.modal-open\{overflow:hidden\}/.test(html)],
 ['invalid fields expose aria-invalid',/setInvalid\(utrInput,true\)/.test(customer)&&/setInvalid\(fileInput,true\)/.test(customer)],
 ['error status uses alert role',/setAttribute\('role',error\?'alert':'status'\)/.test(customer)],
 ['mobile retry layout remains single column',/@media\(max-width:430px\)[\s\S]*retry-source-card\{grid-template-columns:1fr\}[\s\S]*actions\{grid-template-columns:1fr\}/.test(html)],
 ['mobile records remain horizontally contained',/cr-table-wrap\{[^}]*overflow-x:auto/.test(html)],
 ['no cart/order dependency in retry flow',!/cart|order/i.test(customer.match(/function openRechargeRetry[\s\S]*?(?=\nfunction|$)/)?.[0]||'')]
];
const pass=checks.filter(x=>x[1]).length;
fs.writeFileSync(path.join(root,'STEP536_RECHARGE_RETRY_BROWSER_AUDIT_REPORT.md'),`# STEP536 — Recharge Retry Accessibility + Mobile Interaction Audit\n\n**${pass}/${checks.length} PASS**\n\n`+checks.map((x,i)=>`${i+1}. **${x[1]?'PASS':'FAIL'}** — ${x[0]}`).join('\n')+'\n');
fs.writeFileSync(path.join(root,'STEP536_RECHARGE_RETRY_BROWSER_AUDIT_REPORT.json'),JSON.stringify({pass,total:checks.length,checks,artifacts:[]},null,2));
try{fs.unlinkSync(fixture)}catch{}
console.log(`STEP536 BROWSER + ACCESSIBILITY AUDIT: ${pass}/${checks.length} PASS`);
if(pass!==checks.length) process.exitCode=1;
