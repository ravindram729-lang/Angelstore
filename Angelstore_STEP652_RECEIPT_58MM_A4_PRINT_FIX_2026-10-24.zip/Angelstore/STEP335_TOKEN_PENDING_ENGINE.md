# STEP335 — Token Pending/Delay Engine

Implemented on the existing STEP334 baseline without changing the database schema.

## Added
- Mandatory Hold/Pending reason.
- Delay owner: customer / operator / portal / department / other.
- Expected delay in minutes (1–1440).
- Server-calculated hold deadline, remaining minutes and overdue state.
- Hold extension with mandatory reason.
- Mandatory Skip reason.
- Recall counter and last-action timestamp.
- Explicit `काम शुरू करें` transition (`बुलाया` → `प्रगति`).
- Admin queue displays hold reason/timer and skip reason.

## Workflow
Waiting → Called → In Progress → Hold/Pending → Resume/Recall → In Progress → Complete

Skip requires a reason and remains recallable.

## Verification
- `node --check server.js` PASS
- `node --check app.js` PASS
