# Angelstore CSC — Phase 13: Production Deployment & Live Verification Pack

## Scope
Phase 13 prepares the Phase 12 release for an actual hosting deployment and adds a repeatable preflight check. It does **not** claim a live deployment because hosting credentials/domain access were not provided in this workspace.

## Changes
- Production CORS validation now requires one explicit `https://` origin and rejects `*`.
- `.env.example` no longer contains a production-unsafe wildcard CORS value.
- Added `PRODUCTION-PREFLIGHT.js` for dependency-free host-side configuration/storage checks.
- Added this live deployment runbook.

## Deployment sequence
1. Create a full application backup, including `data.json`, `backups/`, and `uploads/payments/`.
2. Deploy this exact release directory/zip.
3. Configure `NODE_ENV=production`.
4. Configure `ANGELSTORE_ADMIN_USER` and a new strong `ANGELSTORE_ADMIN_PASS`.
5. Configure `ANGELSTORE_AUTH_SECRET` with a new random secret of at least 32 characters (64+ recommended).
6. Configure `ANGELSTORE_CORS_ORIGIN` as the exact HTTPS origin used by the browser, e.g. `https://angelcsc.in`.
7. Ensure `data.json`, `backups/`, and `uploads/payments/` are on persistent storage.
8. Run `node PRODUCTION-PREFLIGHT.js` on the host.
9. Start with `npm start`.
10. Verify `GET /api/health` returns HTTP 200 and `ok: true`.
11. Run `node SMOKE-TEST.js` with **test credentials only** and `ANGELSTORE_TEST_URL` pointing to the deployed URL.
12. Perform controlled end-to-end tests: customer login → service request → manual payment UTR/proof → admin verification → token → staff assignment → SOP/QC → completion → finance/report.
13. Create a backup and perform a controlled restore test before real customer traffic.

## Rollback
- Stop the application.
- Preserve the failed deployment logs.
- Restore the pre-deployment application/data backup.
- Re-run preflight and smoke tests.
- Do not delete payment proofs or audit data while investigating a failed release.

## Not verified in this workspace
- Live hosting account/domain/DNS/HTTPS
- Persistent disk behavior after redeploy/restart
- Production credentials
- Real SMS/WhatsApp provider
- Real payment/bank verification
- OCR/Tesseract installation
- Production load/concurrency

Those require access to the actual deployment environment.
