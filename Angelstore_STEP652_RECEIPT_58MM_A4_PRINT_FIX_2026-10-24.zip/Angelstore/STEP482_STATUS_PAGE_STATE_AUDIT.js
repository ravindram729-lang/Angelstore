const fs=require('fs');
const html=fs.readFileSync('customer.html','utf8');
const js=fs.readFileSync('customer.js','utf8');
const server=fs.readFileSync('server.js','utf8');
const checks=[];
function check(name,ok,detail=''){checks.push({name,ok:Boolean(ok),detail});}
check('Reference status page structure present', html.includes('id="page-customer-status"') && html.includes('statusHeroToken') && html.includes('statusLatestUpdates') && html.includes('statusReceiptBtn'));
check('Reference color/button styling preserved', html.includes('linear-gradient(135deg,#e9f7ff,#fff 72%)') && html.includes('.status-shell-mode') && html.includes('.status-empty-action'));
check('Status header overflow hardening', html.includes('.status-reference-shell .status-shell-tools{flex:1 1 520px;') && html.includes('@media(max-width:900px)') && html.includes('.status-reference-shell .crumb,.status-reference-shell .date{display:none}'));
check('No-token queue metrics use dash', js.includes("set('statusHeroAhead',mine&&Number.isFinite(Number(x?.ahead))?String(x.ahead):'—');") && js.includes("const position=(mine&&Number.isFinite(Number(x?.ahead)))?'#'+(Number(x.ahead)+1):'—';"));
check('No-document state never renders false 100%', js.includes('const docsNotRequired=hasActivity&&reqCount===0;') && js.includes("set('statusDocsPercent',docsNotRequired?'N/A'") && !js.includes("((docs?.done)?100:0)"));
check('Latest updates are scoped to active status context', js.includes('if(hasActivity){') && js.includes("if(reqCount>0 && docsItem?.done)") && js.includes("else if(p?.workflow_state)updates.push"));
check('Historical completed/cancelled apps excluded from default live status', server.includes('const activeApps=apps.filter(a=>{') && server.includes('terminalStatuses') && server.includes('const app=requested||activeApps'));
check('Historical terminal tokens excluded from default live status', server.includes("db.tokens.filter(t=>t.mobile===mobile&&['बुलाया','प्रगति','होल्ड','लंबित'].includes(String(t.status||'')))"));
check('Customer/UPPCL/payment workflow code remains present', js.includes('initUppclPage') && server.includes('/api/customer/payment') && server.includes('/api/customer/uppcl'));
const failed=checks.filter(x=>!x.ok);
const out={step:'STEP482',generated_at:new Date().toISOString(),verdict:failed.length?'NOT READY':'PASS',checks,blocking_failures:failed.map(x=>x.name)};
console.log(JSON.stringify(out,null,2));
process.exitCode=failed.length?1:0;
