# STEP430 — Security Hardening Report

## Changes

1. **Production auth secret is now explicit**
   - `ANGELSTORE_AUTH_SECRET` must be provided in production.
   - A development-only random fallback remains available outside production.
   - Production startup fails closed when the configured secret is missing or shorter than 32 characters.

2. **CORS origin handling is fail-closed**
   - Requests with an unknown `Origin` no longer receive the first configured origin as `Access-Control-Allow-Origin`.
   - Configured HTTPS origins remain supported in production.
   - Unknown origins receive no `Access-Control-Allow-Origin` header.
   - Requests without an Origin retain same-origin compatibility.

3. **Existing protections retained**
   - Customer/admin login rate limiting.
   - File MIME/signature validation.
   - Upload size limits.
   - Session cleanup on startup.
   - Sanitized release data.
   - Asynchronous OCR worker with restart recovery.

## Verification

- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- `node --check app.js` — PASS
- Release data counts — PASS (no customer/application/payment/document/session runtime records)
- Production configuration negative test — PASS (missing `ANGELSTORE_AUTH_SECRET` causes startup refusal when the other required production variables are present)

## Fresh E2E

A clean runtime execution of `E2E-TEST.js` with explicit production configuration completed successfully:

- Admin authentication — PASS
- Customer registration/session — PASS
- Payment submission and verification — PASS
- Payment verification → token generation before documents — PASS
- Token-before-document upload gate — PASS
- Document verification — PASS
- Background OCR settlement — PASS
- Service/staff queue — PASS
- Staff/RBAC/QC — PASS
- Completion/automatic receipt — PASS
- Reports/finance — PASS
- Final integrity — PASS
- Session revocation — PASS

The E2E runtime database was discarded/restored afterward; the release package remains sanitized.

## Production preflight note

`PRODUCTION-PREFLIGHT.js` intentionally fails in the build workspace because real deployment environment variables are not present there. This is a deployment configuration requirement, not a code failure.
