# STEP487 — Token Queue Metrics & Service-wise Waiting Count Hardening

Date: 2026-10-03

## Scope
Harden the Token & Queue admin metrics after STEP486 without changing the approved visual design, colors, buttons, tools, or business workflow.

## Root-cause finding
The Admin `/api/tokens` service-wise queue payload labeled `waiting` was counting four states:
- लंबित (pending)
- होल्ड (hold)
- बुलाया (called)
- प्रगति (processing)

This made the UI's `Waiting` value include customers who were already called, being processed, or on hold. The same endpoint already exposed the current token separately, so the waiting metric was semantically inconsistent with the requirement that Waiting Count represent the real queue waiting count.

## Fix
Service-wise `waiting` now counts only `status === 'लंबित'`.

The following remain separate:
- `current`: called/processing token
- `waiting`: pending queue count
- `completed`: completed tokens
- hold tokens: retained in the token list/status metadata, not counted as waiting

No token transition, payment rule, token generation rule, document rule, receipt rule, or UI design was changed.

## Verification
- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- `node --check app.js` — PASS
- STEP487 targeted queue metrics test — PASS
- P0/P1 regression — PASS
- Final release audit — PASS
- Fresh isolated full E2E with local admin credentials — PASS
- Payment → token generation → documents → staff processing → Admin QC → completion → receipt — PASS
- Final integrity — PASS

## E2E result highlights
- Admin login — PASS
- Customer payment submission — PASS
- Admin payment verification — PASS
- Customer sees verified payment — PASS
- Token generated after verified payment — PASS
- Cross-page application/payment/token linkage — PASS
- Required documents pending after token generation — PASS
- Duplicate token protection — PASS
- Document verification — PASS
- Staff assignment/start — PASS
- Admin final QC — PASS
- Completion + automatic receipt — PASS
- Reports/control center/finance — PASS
- Final integrity — PASS

## Production gates
Live deployment reachability and host-specific production secrets/configuration remain separate deployment gates and are not represented as PASS by this local verification.
