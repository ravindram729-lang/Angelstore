# STEP411 — Staff Login Connection Fix

## Problem

When `staff.html` was opened directly from Windows as a `file://` URL, the Staff login used relative requests such as `/api/staff/login`. A `file://` page cannot resolve that path to the local Angelstore backend, so the browser showed `Failed to fetch` before credentials were evaluated.

## Fix

`staff.html` now uses the same backend-resolution model as the main frontend:

- Netlify / production frontend → `https://angelstore-csc-project4.onrender.com`
- `file://` local Staff panel → `http://127.0.0.1:8000`
- `http://127.0.0.1` / `localhost` → current origin
- Optional `localStorage.angelBackendUrl` override is respected

The fix covers:

- Staff login
- Staff dashboard/API calls
- Document open
- Document download
- Existing staff session workflow

## Verification

- `node --check server.js` — PASS
- Inline `staff.html` JavaScript syntax check — PASS
- Local `/api/health` on test port — HTTP 200 PASS
- Invalid Staff login against local backend — HTTP 401 PASS
- Production backend URL remains unchanged
- No authentication/security bypass added

## Important

This fixes the connection error. A real Staff account/PIN still must be valid, and the local backend must be running when `staff.html` is opened directly from a file.
