# STEP374 — Admin Login Password Fix

## Change
Configured the local admin credential for the project owner-requested username in `data.json` using an scrypt hash + random salt.

## Security
- Plaintext password is not stored in `data.json`.
- `admin_sessions` was cleared before packaging.
- Login was verified against the bundled local backend.
- Incorrect password was verified to return HTTP 401.
- Production configuration still rejects known/default passwords; use a unique high-entropy production credential.

## Scope
Only local admin credential initialization/recovery was changed. The service, payment, token, application, and queue workflow code was not changed in STEP374.
