const fs=require('fs');
function ok(name,v){if(!v)throw new Error('FAIL: '+name);console.log('PASS: '+name)}
const s=fs.readFileSync('server.js','utf8'), a=fs.readFileSync('app.js','utf8');
ok('Admin token-history endpoint exists',s.includes("/api/admin/token-history"));
ok('Token history is admin protected',/if\(p==='\/api\/admin\/token-history'&&req\.method==='GET'\)\{\s*const a=admin\(req\);if\(!a\)return json\(res,401/.test(s));
ok('Token history returns audit events',/events,notifications,counts/.test(s));
ok('Customer notifications expose event key',/event_key:n\.event_key\|\|null/.test(s));
ok('Customer notifications expose state revision',/state_revision:n\.state_revision\?\?null/.test(s));
ok('Notification helper correlates token revision',/state_revision:extra\.state_revision\?\?\(tok\?\.state_revision\?\?null\)/.test(s));
ok('Admin timeline viewer loads endpoint',/loadTokenHistoryViewer[\s\S]*\/api\/admin\/token-history\?token_id=/.test(a));
ok('Timeline merges audit and customer events',/kind:'AUDIT'[\s\S]*kind:'CUSTOMER'/.test(a));
ok('Timeline shows state revision',/State \/ Revision/.test(a));
console.log('STEP495 TOKEN HISTORY + NOTIFICATION CONSISTENCY TEST: PASS (9/9)');
