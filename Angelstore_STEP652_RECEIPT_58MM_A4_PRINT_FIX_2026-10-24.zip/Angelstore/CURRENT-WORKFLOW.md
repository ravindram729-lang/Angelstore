# Angelstore — Current Workflow (STEP439)

## Customer service workflow

1. Select service.
2. Create application when the service uses application workflow.
3. Calculate payable amount on the backend.
4. If an active offer is selected, the backend validates service/offer/date/price and snapshots the offer amount.
5. Submit payment proof/UTR.
6. Admin verifies payment.
7. If the service requires appointment approval, token generation is blocked until appointment is `स्वीकृत` or `पुष्टि`.
8. Generate token.
9. Upload documents after token generation.
10. Staff: `लंबित → बुलाया → प्रगति`.
11. Hold/resume/quality workflow.
12. Admin final quality PASS.
13. Completion → automatic receipt.

## Appointment workflow

`अनुरोध → स्वीकृत / पुष्टि → पूर्ण`

Alternative terminal states: `अस्वीकृत`, `रद्द`, `पुनर्निर्धारित`.

Confirmed/approved appointments cannot be placed in the past and duplicate confirmed service/time slots are blocked.

## Queue rules

- Current/live queue is scoped to the current date.
- Priority tokens sort before normal tokens.
- Creation ID is the deterministic tie-breaker.
- Only one active called/processing token is allowed per service queue.
