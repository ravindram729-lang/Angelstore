# STEP455 — UPPCL Manual Admin UI Replacement & Workflow Fix

## Scope
- Replaced the old Admin UPPCL provider/bill-lookup test screen with the supplied manual-control design direction.
- UPPCL workflow is now explicitly manual in the Admin and Customer UI.
- No UPPCL bill/payment API call is made by `admin.html` or `customer.js`.

## Admin UI
- Manual Bill Details entry/update form
- Manual-only workflow control
- Recent Lookup & Update History
- Manual UPPCL Payment Queue
- Verify / Reject payment proof actions preserved
- Mark Completed / Failed processing actions preserved
- Refresh actions preserved
- Responsive layout added for the new control panel

## Backend
Added authenticated admin endpoints:
- `GET /api/admin/uppcl/manual-bill-history`
- `POST /api/admin/uppcl/manual-bill`

Manual bill records are persisted in `db.uppcl_manual_bills` and audited.

## Customer UPPCL
- Removed the customer-side UPPCL bill API call.
- Customer now manually enters the bill amount/details from the actual bill.
- Existing manual UPI payment + proof submission flow remains connected to the existing payment ledger.

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `node --check customer.js` — PASS
- All inline `admin.html` scripts extracted and syntax-checked — PASS
- Temporary isolated server login — PASS
- Manual bill create endpoint — PASS
- Manual bill history endpoint — PASS
- Manual payment queue endpoint — PASS
- Confirmed no `/api/uppcl/bill`, `/api/admin/uppcl/bill-check`, or `/api/admin/uppcl/status` calls remain in the Customer/Admin UPPCL frontend code.

## Important
No fake UPPCL bill/amount is generated. The customer/admin must enter the actual bill details manually and Admin remains responsible for verification.
