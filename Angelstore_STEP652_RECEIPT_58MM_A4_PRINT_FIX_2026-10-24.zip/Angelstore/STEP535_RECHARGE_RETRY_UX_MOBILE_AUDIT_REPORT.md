# STEP535 — Recharge Retry UX & Mobile Audit

16/16 PASS

1. **PASS** — retry function exists
2. **PASS** — retry only Failed + retryable
3. **PASS** — retry modal has dialog semantics
4. **PASS** — source attempt summary visible
5. **PASS** — new UTR input constrained 6-40
6. **PASS** — screenshot accepts png jpeg webp
7. **PASS** — screenshot max 5MB enforced
8. **PASS** — inline validation status accessible
9. **PASS** — submit button locks during request
10. **PASS** — duplicate/server errors remain visible
11. **PASS** — success refreshes records
12. **PASS** — Escape closes retry modal
13. **PASS** — mobile modal width hardening
14. **PASS** — mobile table contained in horizontal scroller
15. **PASS** — mobile action buttons use compact grid
16. **PASS** — no cart/order dependency
