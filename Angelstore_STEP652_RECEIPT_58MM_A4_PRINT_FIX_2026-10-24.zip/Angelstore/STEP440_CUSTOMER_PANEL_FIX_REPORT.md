# STEP440 — Customer Panel P0/P1 Fix Report

## Scope
Customer panel audit findings from STEP439 were addressed without changing the core cart-free CSC workflow.

## Fixes
1. Customer document list no longer exposes `ocr_text` / raw OCR fields.
2. Bank Transfer payment UI now shows configurable bank details.
3. Admin Settings now provides Bank Name, Account Name, Account Number, IFSC and Branch fields.
4. Public payment configuration exposes only the configured bank display fields needed by the customer payment screen.
5. QR payment is now retained as `QR` instead of being silently stored as `UPI`.
6. Backend customer/admin manual payment validation accepts `QR` as a distinct payment channel.
7. UPI App button becomes disabled and non-focusable when UPI configuration is unavailable.
8. Application Tracking copy now correctly states that Customer Login is required.
9. Customer SPA navigation now writes the active panel to the URL hash and can restore a valid panel deep-link.
10. Bank transfer proof guidance remains UTR or screenshot based; Cash remains proof-optional.

## Verification
- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- `node --check app.js` — PASS
- `npm run check` — PASS
- `npm run p0-p1-regression` — PASS
- `npm run release-audit` — PASS
- Modified runtime `/api/public-config` — HTTP 200; bank fields present
- Protected `/api/customer/documents` without session — HTTP 401

## Known limitations
- Actual mobile/desktop browser interaction and pixel-level responsive E2E could not be completed in this environment because Chromium execution was unavailable/timed out.
- Recharge, UPPCL and Smart Meter remain provider-dependent features; this step does not invent live provider integrations.
- SQL migration, durable OCR workers and SSE/WebSocket remain separate architecture work.
