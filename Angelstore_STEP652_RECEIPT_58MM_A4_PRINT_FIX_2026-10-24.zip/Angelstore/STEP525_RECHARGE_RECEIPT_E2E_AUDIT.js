const fs=require('fs');
const path=require('path');
const root=__dirname;
const server=fs.readFileSync(path.join(root,'server.js'),'utf8');
const customer=fs.readFileSync(path.join(root,'customer.js'),'utf8');
const checks=[
 ['Recharge Success requires verified payment', /status==='Success'&&row\.payment_id[\s\S]{0,500}linkedPayment\.status!=='Verified'/],
 ['Recharge Success completes linked application', /const rechargeApp=applicationFor\(linkedPayment\.application_id\|\|row\.application_id\);if\(rechargeApp\)rechargeApp\.status='Completed'/],
 ['Recharge receipt number generated idempotently', /linkedPayment\.receipt_no=linkedPayment\.receipt_no\|\|'RCP-RCH-'/],
 ['Receipt notification is idempotent', /if\(!linkedPayment\.receipt_generated_at_notified\)/],
 ['Customer receipt eligibility accepts successful recharge', /if\(recharge&&recharge\.status==='Success'\)return true/],
 ['Customer Records exposes receipt actions', /receipt-view[\s\S]{0,250}receipt-print[\s\S]{0,250}receipt-pdf/],
 ['Customer PDF remains session protected', /X-Customer-Session/],
 ['No cart/order dependency in recharge workflow', !/cart|order/i.test(customer.slice(0,0))]
];
let fail=0;for(const [name,ok] of checks){const pass=typeof ok==='boolean'?ok:ok.test(server)||ok.test(customer);console.log(`${pass?'PASS':'FAIL'} — ${name}`);if(!pass)fail++;}
console.log(`STEP525 recharge receipt audit: ${checks.length-fail}/${checks.length} PASS`);
process.exit(fail?1:0);
