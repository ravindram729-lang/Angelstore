# STEP385 — Final E2E & Security Test Alignment

Date: 2026-09-26

## Purpose

Updated the legacy E2E and security-abuse test scripts to match the current STEP383/STEP384 security and workflow contract. Product runtime code was not changed in this step.

## Changes

- Public application tracking is now expected to return `401` without a customer session.
- Authenticated owner tracking is verified with `X-Customer-Session`.
- Public token tracking is now expected to return `401`; authenticated owner tracking is verified.
- Token generation is explicitly tested before required-document verification and must return `409`.
- E2E obtains the service SOP, uploads real JPEG-signature test documents, verifies them through Admin, then verifies token generation succeeds.
- Malformed JSON security test accepts `400` or `429`, because a request can be rejected by rate limiting before JSON parsing.
- CORS security test now verifies that an arbitrary Origin is never reflected. It no longer incorrectly expects `*` when an explicit configured origin is used.
- Package version updated to `3.0.6`.

## Verification

### Full E2E

Fresh isolated runtime:

- Admin login: PASS
- Customer registration/session: PASS
- Application creation: PASS
- Unauthenticated tracking blocked: PASS
- Authenticated own tracking: PASS
- Payment submission/verification: PASS
- Required-document token gate: PASS (409 before documents)
- Document upload/signature validation: PASS
- Admin document verification: PASS
- Token generation after document verification: PASS
- Staff RBAC: PASS
- Staff task workflow: PASS
- Staff quality submission: PASS
- Admin final quality gate: PASS
- Completion/receipt: PASS
- Reports/control/finance/integrity: PASS
- Session revocation: PASS

**E2E: PASS — all steps completed successfully.**

### Security Abuse Suite

Fresh isolated runtime:

- Unauthenticated Admin API: PASS
- Unauthenticated Staff API: PASS
- Unauthenticated Customer records: PASS
- Malformed JSON: PASS (`400`)
- Oversized payload: PASS (`ECONNRESET`)
- Backup traversal: PASS (`401`)
- Customer token privacy: PASS (`401`)
- CORS arbitrary-origin reflection: PASS
- Guest application rate limit: PASS (`429`)
- Forged Admin bearer: PASS (`401`)

**Security Abuse Suite: PASS — all checks passed.**

### Release Audit

`FINAL-RELEASE-AUDIT.js`: **PASS (39/39 checks)**

## Final status

The legacy test scripts are aligned with the current secured workflow. No production application workflow was changed in STEP385; only test expectations/fixtures and package version were updated.
