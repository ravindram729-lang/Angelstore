const fs=require('fs'),path=require('path');
const server=fs.readFileSync(path.join(__dirname,'server.js'),'utf8');
const customer=fs.readFileSync(path.join(__dirname,'customer.js'),'utf8');
const checks=[
 ['retry requires customer session',"if(!c)return json(res,401,{error:'Customer login required'})"],
 ['retry requires Failed source',"source.status!=='Failed'"],
 ['linear retry chain prevents branching','const childRetry='],
 ['existing child retry returns conflict',"if(childRetry)return json(res,409"],
 ['concurrent-safe synchronous critical section has no await after validation','const name=String(c.name||source.customer_name||\'\').trim(),accountMobile='],
 ['idempotency key required','Retry safety के लिए idempotency key जरूरी है'],
 ['same idempotency key returns existing retry','existingIdem?.payment_id'],
 ['same key payload conflict blocked','existingIdem?.conflict'],
 ['UTR uniqueness enforced','db.payments.some(p=>String(p.utr||\'\').toLowerCase()===utr.toLowerCase())'],
 ['proof hash uniqueness enforced','duplicateProof=db.payments.some'],
 ['retry starts Pending',"status:'Pending',source:'customer-recharge-retry'"],
 ['retry attempt increments',"attemptNo=Math.max(1,Number(source.attempt_no||1)+1)"],
 ['retry parent link retained','retry_of_recharge_id:source.id'],
 ['retry group retained','retry_group_id:rootId'],
 ['success still requires verified payment',"linkedPayment.status!=='Verified'"],
 ['retry UI only offered for Failed','failed?`<button type="button" class="receipt-action recharge-retry"'],
 ['no cart/order dependency','recharge-retry']
];
let pass=0;for(const [name,needle] of checks){const ok=server.includes(needle)||customer.includes(needle);console.log(`${ok?'PASS':'FAIL'} | ${name}`);if(ok)pass++}
console.log(`STEP533 CONCURRENCY AUDIT: ${pass}/${checks.length} PASS`);process.exit(pass===checks.length?0:1);
