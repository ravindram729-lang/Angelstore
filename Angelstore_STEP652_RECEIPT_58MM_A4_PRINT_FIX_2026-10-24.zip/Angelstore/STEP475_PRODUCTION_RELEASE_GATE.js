const fs=require('fs');
const path=require('path');
const {spawnSync}=require('child_process');
const root=__dirname;
const results=[];
function run(name,cmd,args=[]){const r=spawnSync(cmd,args,{cwd:root,encoding:'utf8'});const ok=r.status===0;results.push({name,ok,exit:r.status,stdout:(r.stdout||'').slice(-5000),stderr:(r.stderr||'').slice(-3000)});return r;}
function gate(name,ok,detail=''){results.push({name,ok:Boolean(ok),detail});}
for(const f of ['server.js','app.js','customer.js','admin.html','customer.html','staff.html','index.html','package.json','render.yaml','PRODUCTION-PREFLIGHT.js','FINAL-RELEASE-AUDIT.js','PRODUCTION-OPS-AUDIT.js']) gate(`Required artifact: ${f}`,fs.existsSync(path.join(root,f)));
run('npm check','npm',['run','check']);
run('release audit','npm',['run','release-audit']);
// Ops audit is intentionally allowed to fail in an unconfigured local environment; its failures are classified separately.
const ops=run('production ops audit',process.execPath,['PRODUCTION-OPS-AUDIT.js']);
const opsObj=(()=>{try{return JSON.parse(ops.stdout)}catch{return null}})();
if(opsObj){const configFailures=(opsObj.checks||[]).filter(x=>!x.ok).map(x=>x.name);gate('Production configuration gates',opsObj.ok,'Failures: '+(configFailures.join(', ')||'none'));} else gate('Production configuration gates',false,'Ops audit did not return JSON.');
const requiredScripts=['STEP465_UPPCL_RECONCILIATION_RECOVERY_E2E.js','STEP466_GLOBAL_PAYMENT_ARCHITECTURE_E2E.js','STEP467_GLOBAL_PAYMENT_RECONCILIATION_E2E.js','STEP468_GLOBAL_RECOVERY_E2E.js','STEP470_FINANCIAL_LEDGER_E2E.js','STEP471_FINANCIAL_REPORT_E2E.js'];
for(const f of requiredScripts)gate(`Historical targeted test artifact: ${f}`,fs.existsSync(path.join(root,f)),'Presence only; not re-executed by this gate.');
const blockers=results.filter(x=>!x.ok && !/^Production configuration gates$/.test(x.name));
const config=results.find(x=>x.name==='Production configuration gates');
const verdict=blockers.length? 'BLOCKED' : (config&&!config.ok ? 'READY WITH CONFIGURATION GATES BLOCKED' : 'READY');
const out={step:'STEP475',generated_at:new Date().toISOString(),verdict,blocking_failures:blockers.map(x=>x.name),configuration_gate:config||null,results};
fs.writeFileSync(path.join(root,'STEP475_PRODUCTION_RELEASE_GATE_RESULT.json'),JSON.stringify(out,null,2));
console.log(JSON.stringify(out,null,2));
process.exit(blockers.length?1:0);
