# STEP528 — Recharge Lifecycle Timeline + Failure Reason Visibility

## Scope
Customer-facing recharge lifecycle hardening after STEP527.

## Changes
- Recharge records now persist a `status_history` timeline.
- Payment verification/rejection timestamps are synchronized into the recharge timeline.
- Recharge Success stores `completed_at`.
- Recharge Failed stores `failed_at` and a customer-visible `failure_reason`.
- Customer Records exposes lifecycle timestamps/history through the customer-safe recharge payload.
- Recharge Details opens a lifecycle timeline modal with exact timestamps.
- Receipt actions remain restricted to terminal successful recharge records with a valid receipt.
- Failed recharge notifications include the failure reason when available.
- Customer ownership/session controls remain unchanged.
- No cart/order workflow introduced.

## Verification
- STEP528 audit: 10/10 PASS
- node --check server.js: PASS
- node --check customer.js: PASS
- npm run check: PASS
- FINAL-RELEASE-AUDIT.js: PASS
