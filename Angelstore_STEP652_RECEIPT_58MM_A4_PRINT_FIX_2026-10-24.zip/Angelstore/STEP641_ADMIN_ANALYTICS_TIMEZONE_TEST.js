'use strict';
const assert=require('node:assert/strict');
function istDateKey(value){
 const raw=String(value??'').trim(); if(!raw)return '';
 if(/^\d{4}-\d{2}-\d{2}$/.test(raw))return raw;
 const d=new Date(raw); if(Number.isNaN(d.getTime()))return '';
 return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(d);
}
function calendarKeys(anchor='2026-10-08'){
 const [y,m,day]=anchor.split('-').map(Number); const out=[];
 for(let i=6;i>=0;i--)out.push(new Date(Date.UTC(y,m-1,day-i,12)).toISOString().slice(0,10));
 return out;
}
assert.equal(istDateKey('2026-10-07T18:29:59Z'),'2026-10-07');
assert.equal(istDateKey('2026-10-07T18:30:00Z'),'2026-10-08');
assert.equal(istDateKey('2026-10-08'),'2026-10-08');
assert.equal(istDateKey('not-a-date'),'');
assert.deepEqual(calendarKeys('2026-10-08'),['2026-10-02','2026-10-03','2026-10-04','2026-10-05','2026-10-06','2026-10-07','2026-10-08']);
console.log('STEP641 ADMIN ANALYTICS TIMEZONE: 5/5 PASS');
