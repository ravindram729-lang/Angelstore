const fs=require('fs'),path=require('path'),os=require('os'),{spawn}=require('child_process');
const root=__dirname,temp=fs.mkdtempSync(path.join(os.tmpdir(),'angelstore-step471-')),now=new Date().toISOString();
const data={
  payments:[
    {id:1,name:'A',mobile:'9876543210',amount:100,method:'UPI',utr:'R1',status:'Verified',service:'PAN Card',official_fee:30,staff_commission:10,payment_charge:2,staff_id:'S1',created_at:now},
    {id:2,name:'B',mobile:'9876543211',amount:200,method:'UPI',utr:'R2',status:'Verified',service:'UPPCL Bill Payment',official_fee:150,staff_commission:10,payment_charge:2,staff_id:'S2',created_at:now},
    {id:3,name:'C',mobile:'9876543212',amount:50,method:'UPI',utr:'R3',status:'Pending Verification',service:'PAN Card',created_at:now}
  ],
  staff:[{staff_id:'S1',employee_id:'E1',name:'Staff One',status:'active'},{staff_id:'S2',employee_id:'E2',name:'Staff Two',status:'active'}],
  expenses:[{id:1,type:'office',amount:20,note:'test',created_at:now}],
  commissions:[],applications:[],recharge_transactions:[],tokens:[],customers:[],audit:[]
};
fs.writeFileSync(path.join(temp,'data.json'),JSON.stringify(data,null,2));
const port=8771,env={...process.env,PORT:String(port),HOST:'127.0.0.1',ANGELSTORE_STORAGE_DIR:temp,ANGELSTORE_ADMIN_USER:'step471admin',ANGELSTORE_ADMIN_PASS:'Step471SecurePass!92',ANGELSTORE_AUTH_SECRET:'step471-auth-secret-012345678901234567890123',ANGELSTORE_CORS_ORIGIN:'http://127.0.0.1:'+port};
const child=spawn(process.execPath,[path.join(root,'server.js')],{cwd:root,env,stdio:['ignore','pipe','pipe']});let out='';child.stdout.on('data',d=>out+=d);child.stderr.on('data',d=>out+=d);function sessionHeaders(resp,requiredCookie){const raw=resp.headers?.get?.('set-cookie')||'';const set=raw.split(/, (?=[^;,]+=)/);const jar=set.map(v=>v.split(';')[0]).filter(Boolean).join('; ');const csrfMatch=jar.match(/(?:^|; )angel_csrf=([^;]+)/);if(!jar.includes(requiredCookie+'='))throw Error('missing '+requiredCookie+' cookie');if(!csrfMatch)throw Error('missing CSRF cookie');return {Cookie:jar,'X-CSRF-Token':decodeURIComponent(csrfMatch[1])}}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function req(url,opt={}){for(let i=0;i<30;i++){try{const r=await fetch('http://127.0.0.1:'+port+url,opt);const t=await r.text();let j={};try{j=JSON.parse(t)}catch{}return {status:r.status,data:j,headers:r.headers}}catch{await sleep(100)}}throw Error('server unavailable '+out.slice(-500))}
(async()=>{try{await sleep(500);const l=await req('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'step471admin',password:'Step471SecurePass!92'})});if(l.status!==200)throw Error('login failed '+JSON.stringify(l.data));const h=sessionHeaders(l,'angel_admin');const r=await req('/api/admin/financial-report?from='+now.slice(0,10)+'&to='+now.slice(0,10),{headers:h});if(r.status!==200)throw Error('report failed '+JSON.stringify(r.data));if(r.data.summary.transactions!==2)throw Error('verified transaction count wrong');if(Number(r.data.summary.verified_collection)!==300)throw Error('collection wrong '+r.data.summary.verified_collection);if(r.data.daily.length!==1||r.data.service.length!==2||r.data.staff.length!==2)throw Error('breakdowns wrong');if(Number(r.data.summary.ledger_verified_collection)!==300)throw Error('ledger total wrong');if(r.data.ok!==true)throw Error('report unexpectedly has reconciliation issues: '+JSON.stringify(r.data.issues));
console.log(JSON.stringify({ok:true,checks:{admin_login:true,verified_transactions:true,collection_total:true,daily_breakdown:true,service_breakdown:true,staff_breakdown:true,ledger_amount_match:true},summary:r.data.summary,issues:r.data.issues},null,2));
}catch(e){console.error(JSON.stringify({ok:false,error:e.message,output:out.slice(-1200)},null,2));process.exitCode=1}finally{child.kill('SIGTERM');setTimeout(()=>fs.rmSync(temp,{recursive:true,force:true}),200)}})();
