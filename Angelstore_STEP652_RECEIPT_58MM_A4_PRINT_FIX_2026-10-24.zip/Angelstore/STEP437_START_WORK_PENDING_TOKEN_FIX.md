# STEP437 — Admin Token Work Center Start Work Fix

Root cause:
- The Token Work Center modal used `action:'start'`, but `/api/tokens` accepts `processing`.
- A newly generated token is `लंबित`; the token state machine requires `लंबित -> बुलाया -> प्रगति`.

Fix:
- Changed only the Work Center `Start Work` handler.
- If the selected token is `लंबित`, it first calls the existing `next` action for that service, then calls `processing`.
- If the token is already `बुलाया`, it directly calls `processing`.
- No server state-machine changes.
- No document/payment/quality workflow changes.

Validation:
- `node --check app.js` PASS
