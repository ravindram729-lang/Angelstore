# Angelstore STEP427 — Core Workflow / Document State Fix

## Authoritative workflow
Service → Application Details → Payment → Payment Verification → Live Token → Documents → Document Verification → Processing → Completed → Receipt

## Changes
- Added explicit service workflow configuration records for all catalog services (116 services).
- Service document requirement now derives from the service's configured document list instead of defaulting every service to `true`.
- Added application workflow-state calculation: Payment Pending / Payment Verification Pending / Token Pending / Token Generated / Documents Pending / Documents Verified / Processing / Completed / Correction Required.
- Customer progress now exposes the authoritative workflow state and follows the Token-before-Documents sequence.
- Added `document_type` metadata to customer document uploads and existing document records.
- Customer Documents UI now asks for the document type when required documents are configured.
- Document matching uses explicit `document_type` with filename fallback for backward compatibility.
- Custom service delete is now archive/soft-delete; historical service records are not removed from pricing/workflow collections.
- Archived custom services are excluded from public/admin service listings.

## Validation
- `node --check server.js` PASS
- `node --check customer.js` PASS
- `node --check service-catalog.js` PASS
- Runtime `/api/health` PASS (HTTP 200)
- Runtime `/api/services` PASS (HTTP 200; 25 categories / 116 services)
- Production final-release audit PASS (exit 0)

## No cart/order architecture added.
## No Token-before-Documents rule introduced. Documents remain downstream of Token.
