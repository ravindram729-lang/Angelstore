# Angelstore P0/P1 Fix Report — Step 118

## Scope
Targeted fixes only. No redesign, no new customer login/payment method, no cart, and no schema migration.

## Fixed
1. Customer runtime: added the missing `statusClass()` helper.
2. Customer runtime: added the missing `loadCustomerUpdates()` renderer using existing live offers.
3. Customer queue: switched from the privacy-limited `/api/customer/tokens` response to a dedicated sanitized `/api/customer/live-queue` endpoint.
4. Customer queue: removed incorrect matching against `r.mobile` because public token records intentionally do not expose mobile numbers.
5. Customer services: normalized service-charge data so displayed CSC/Government amounts use the configured `/api/service-charges` values instead of a conflicting second source.
6. Admin payment proof: frontend now checks `proof_available` rather than a nonexistent `screenshot` field.
7. Admin payment proof: Verify/Reject buttons remain enabled after a proof has already been viewed, using `proof_viewed_at`.
8. CORS: production configuration supports multiple explicit HTTPS frontend origins and returns the matching allowed origin.
9. Static exposure: known internal audit/test/reset JavaScript files are blocked from public static serving.

## Intentionally not changed
- Database schema/storage architecture
- Authentication model/session lifetime
- Token workflow
- Manual UTR + screenshot payment workflow
- Admin/Staff UI design
- Cart/token model
- Existing service catalog definitions

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- All inline `customer.html` scripts — PASS
- Final release audit — PASS
- Production configuration gate — PASS
- Runtime health/static-service/protected-route checks in release audit — PASS

## E2E note
The bundled E2E script was attempted in an isolated temporary storage environment. It stopped at Admin Login because the temporary fixture did not contain a matching admin credential. No production data was modified by that test run.
