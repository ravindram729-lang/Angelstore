'use strict';
const { execFileSync } = require('node:child_process');
const checks = [
  ['STEP639', 'STEP639_CURRENT_COOKIE_AUTH_REGRESSION_TEST.js'],
  ['STEP641', 'STEP641_ADMIN_ANALYTICS_TIMEZONE_TEST.js'],
  ['STEP642', 'STEP642_CUSTOMER_ADMIN_STATE_RECONCILIATION_TEST.js'],
  ['STEP643', 'STEP643_PAYMENT_RECEIPT_TOKEN_CROSS_WORKFLOW_TEST.js'],
  ['STEP498', 'STEP498_TOKEN_QUEUE_PERFORMANCE_MONITOR_TEST.js'],
  ['STEP521', 'STEP521_RECEIPT_PDF_PRINT_TEST.js'],
];
for (const [name, file] of checks) {
  execFileSync(process.execPath, [file], { stdio: 'inherit' });
  console.log(`${name}: PASS`);
}
console.log('STEP644 PRODUCTION REGRESSION AUDIT: PASS');
