# STEP556 — Customer Home Hero Overlap Fix

## Problem observed
The STEP555 Customer Home hero used an art asset containing baked-in left-side text/button fragments. Because the asset was positioned over the hero copy, the baked text overlapped the live HTML hero text at desktop widths.

## Fix
- Created `assets/customer-home-reference-visual-crop.png`, removing the baked-in left fragments while retaining the people, laptop, checklist and right-side branding.
- Customer Home hero now uses a two-zone layout: HTML copy occupies the left zone and the reference art is confined to the right zone.
- Added explicit stacking (`copy` above, art behind) and bounded widths so the art cannot cover the copy.
- Preserved the mobile stacked layout.
- No customer navigation, IDs, data bindings, token/payment/application flows or cart/order logic were changed.

## Validation
- Customer Home HTML structure preserved.
- Hero image reference updated only for the Customer Home hero.
- Original reference asset retained for other uses.
- ZIP rebuilt from STEP555 working tree.
