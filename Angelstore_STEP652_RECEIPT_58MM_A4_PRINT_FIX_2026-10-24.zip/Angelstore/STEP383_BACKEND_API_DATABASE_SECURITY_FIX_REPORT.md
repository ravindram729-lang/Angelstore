# STEP383 — Backend / API / Database / Security Priority Fix Report

## Scope
Backend/API/database/security findings from the STEP382 audit were fixed without changing the cart-free CSC workflow.

## P0 fixes
1. Required-document gate is now enforced server-side before token generation for both customer and admin token issuance.
2. Admin manual payment amount must exactly match the configured payable service charge.

## P1 fixes
3. `/api/customer/live-queue` now requires an authenticated customer session; guest users cannot obtain global queue counts directly from the API.
4. `/api/customer/track` now requires a customer session or a valid signed customer tracking token and only returns records belonging to that customer/mobile.
5. Guest-created customer records cannot be claimed by registration using only a mobile number. Registration requires the signed Guest Application claim token.
6. Custom service names are now immutable after creation. Fee/workflow fields can still be edited; renaming is rejected to prevent orphaned pricing/workflow records.

## Customer UX compatibility
- Customer registration automatically sends the stored Guest Application token when available.
- Public live-token button no longer calls a protected queue API anonymously; it asks the user to log in.
- Customer JS cache version updated to STEP383.

## Verification
- `node --check server.js` PASS
- `node --check app.js` PASS
- `node --check customer.js` PASS
- `npm run check` PASS
- `FINAL-RELEASE-AUDIT.js` PASS
- Fresh isolated runtime `/api/health` HTTP 200
- Unauthenticated live queue: 401 PASS
- Unauthenticated application tracking: 401 PASS
- Guest registration without claim token: 403 PASS
- Guest registration with valid claim token: 201 PASS
- Wrong manual payment amount: 400 PASS
- Correct manual payment amount: 200 PASS
- Admin token without required documents: 409 PASS
- Customer token without required documents: 409 PASS
- Authenticated live queue: 200 PASS
- Authenticated own application tracking: 200 PASS

## Important remaining architecture items
- JSON storage remains the current database architecture; a transactional DB migration is still a future scale improvement.
- Off-site backup encryption/configuration remains deployment-dependent.
- Granular multi-admin RBAC remains a separate security phase.
- OCR concurrency controls remain a future performance hardening task.

## Release verdict
**STEP383 backend/API/database/security P0/P1 fixes: PASS.**
The release should still undergo full project regression after merging this step.
