# STEP495 — Token History / Audit Viewer + Customer Notification Consistency

## Scope
Harden the Token Queue audit/history workflow after STEP494 without changing the approved cart-free business workflow or existing core token controls.

## Changes
- Added admin-protected `GET /api/admin/token-history?token_id=...` endpoint.
- Endpoint returns the server-authoritative token plus correlated token audit events and customer notifications.
- Audit timeline includes actor, before/after state, status, state revision, request ID and reason where available.
- Customer notification history now exposes `event_key` and `state_revision` for event correlation.
- Notification creation automatically associates the current token state revision when a token notification is created.
- Added a Security & Audit page Token Timeline viewer that combines Admin/Staff audit events and Customer notifications chronologically.
- Existing UI/design and core buttons remain unchanged; the viewer is added inside the existing Security & Audit area.

## Verification
- `npm run check` — PASS
- STEP487 queue metrics — PASS
- STEP488 token controls — PASS
- STEP489 Staff ↔ Customer sync — PASS (8/8)
- STEP490 assignment/transfer — PASS (11/11)
- STEP491 live auto-refresh — PASS (7/7)
- STEP492 concurrency — PASS (8/8)
- STEP493 conflict UI — PASS (7/7)
- STEP494 audit/notification — PASS (9/9)
- STEP495 targeted test — PASS (9/9)
- Final release audit — PASS

## Browser verification limitation
Fresh live Chromium click-by-click verification is not claimed because the execution environment blocks normal localhost navigation. Static UI logic, syntax validation, isolated workflow tests and release audit were used.

## Production gate
This is a local code/workflow verification PASS. Live deployment configuration, production host behavior and hosted browser verification remain separate operational gates.
