const http = require('http');
const fs = require('fs');
const path = require('path');

const BASE = process.env.E2E_BASE || 'http://127.0.0.1:8015';
const ROOT = __dirname;
const report = { started_at:new Date().toISOString(), steps:[], ok:false };
const cookieSessionMap = new Map();
let adminCookieHeaders = null;
let sessionSequence = 0;
function extractCookieSession(resp, cookieName){
  const set=resp.headers?.['set-cookie']||[];
  const jar=set.map(v=>v.split(';')[0]).join('; ');
  const csrfMatch=jar.match(/(?:^|; )angel_csrf=([^;]+)/);
  if(!jar.includes(cookieName+'=')||!csrfMatch)throw new Error('Missing '+cookieName+' or CSRF cookie in test response');
  return {Cookie:jar,'X-CSRF-Token':decodeURIComponent(csrfMatch[1])};
}
function registerCustomerSession(resp){const h=extractCookieSession(resp,'angel_customer'),marker='__CUSTOMER_COOKIE_'+(++sessionSequence)+'__';cookieSessionMap.set(marker,h);return marker;}
function registerStaffSession(resp){const h=extractCookieSession(resp,'angel_staff'),marker='__STAFF_COOKIE_'+(++sessionSequence)+'__';cookieSessionMap.set(marker,h);return marker;}
function normalizeHeaders(headers){
  const out={...headers};
  if(out.Authorization==='__ADMIN_COOKIE__'){delete out.Authorization;Object.assign(out,adminCookieHeaders||{});}
  for(const key of ['X-Customer-Session','X-Staff-Session']){
    const val=out[key];
    if(typeof val==='string'&&cookieSessionMap.has(val)){delete out[key];Object.assign(out,cookieSessionMap.get(val));}
  }
  return Object.fromEntries(Object.entries(out).filter(([,v])=>v!==undefined&&v!==null));
}

function assert(ok, name, detail){ report.steps.push({name,ok:Boolean(ok),detail:detail??''}); if(!ok) throw new Error(name + (detail?': '+detail:'')); }
function req(method, pathname, body, headers={}){
  return new Promise((resolve,reject)=>{
    const u=new URL(pathname,BASE); const b=body===undefined?null:Buffer.from(JSON.stringify(body));
    const h={...(b?{'Content-Type':'application/json','Content-Length':b.length}:{}),...normalizeHeaders(headers)};
    const r=http.request({method,hostname:u.hostname,port:u.port,path:u.pathname+u.search,headers:h},res=>{let s='';res.on('data',c=>s+=c);res.on('end',()=>{let data;try{data=s?JSON.parse(s):null}catch{data=s}resolve({status:res.statusCode,data,headers:res.headers})})});r.on('error',reject);if(b)r.write(b);r.end();
  });
}
async function main(){
  let r=await req('GET','/api/health'); assert(r.status===200&&r.data?.ok,'Health check',JSON.stringify(r.data));

  r=await req('POST','/api/auth/login',{username:process.env.ANGELSTORE_ADMIN_USER||'',password:process.env.ANGELSTORE_ADMIN_PASS||''}); assert(r.status===200&&r.headers['set-cookie']?.some(x=>x.startsWith('angel_admin=')),'Admin login'); adminCookieHeaders=extractCookieSession(r,'angel_admin'); const admin='__ADMIN_COOKIE__';
  r=await req('GET','/api/system/integrity',undefined,{Authorization:admin}); assert(r.status===200&&r.data.ok,'Initial integrity',JSON.stringify(r.data));

  r=await req('GET','/api/services'); assert(r.status===200&&r.data.services?.length,'Service catalog'); const serviceCatalog=r.data;
  r=await req('GET','/api/recharge/plans?operator=JIO&type=PREPAID&circle=UP'); assert(r.status===200&&r.data.admin_managed===true&&Array.isArray(r.data.plans)&&r.data.live===false,'Recharge catalog is Admin-managed only',JSON.stringify(r.data));
  const testPlanId='E2E-JIO-'+Date.now();
  r=await req('POST','/api/admin/recharge/plans',{id:testPlanId,operator:'JIO',type:'PREPAID',circle:'UP',amount:123,validity:'28 days',data:'1 GB/day',calls:'Unlimited',sms:'100/day',category:'popular',active:true},{Authorization:admin}); assert(r.status===200&&r.data.ok&&r.data.plan?.id===testPlanId,'Admin can create recharge plan',JSON.stringify(r.data));
  r=await req('GET','/api/recharge/plans?operator=JIO&type=PREPAID&circle=UP'); assert(r.status===200&&r.data.admin_managed===true&&r.data.plans?.some(x=>x.id===testPlanId),'Customer plan catalog reads Admin-managed plan');
  r=await req('GET','/api/recharge/operator-detect?mobile=9876543210'); assert(r.status===200&&r.data.detected===false&&r.data.source==='manual-selection','Recharge operator remains manual selection',JSON.stringify(r.data));
  r=await req('POST','/api/recharge/initiate',{mobile:'9876543210',operator:'JIO',plan:{id:testPlanId}},{Authorization:admin}); assert(r.status===410&&r.data.manual_only===true,'Recharge processing is Admin-managed/manual only',JSON.stringify(r.data));
  const category=serviceCatalog.services.find(x=>x.services?.length); const sub=category.services[0]; const service=category.category+' — '+sub.name;
  r=await req('GET','/api/service-charges?category='+encodeURIComponent(category.category)+'&service='+encodeURIComponent(sub.name)); assert(r.status===200&&r.data.charge,'Service charge');
  const amount=Number(r.data.charge.total); assert(amount>0,'Payable amount',String(amount));
  r=await req('POST','/api/payments',{name:'Manual UPI Proof Test',mobile:'92222'+String(Math.floor(10000+Math.random()*89999)),service,amount,method:'UPI',utr:'MANUAL-NO-PROOF-'+Date.now()},{Authorization:admin}); assert(r.status===200&&r.data.status==='Pending Verification','Admin UPI manual payment accepts UTR without screenshot');

  const mobile='90000'+String(Math.floor(10000+Math.random()*89999));
  r=await req('POST','/api/customer/register',{name:'E2E Test Customer',mobile,pin:'2468'}); assert(r.status===201&&r.headers['set-cookie']?.some(x=>x.startsWith('angel_customer=')),'Customer registration'); const customer=registerCustomerSession(r);
  r=await req('GET','/api/customer/me',undefined,{'X-Customer-Session':customer}); assert(r.status===200&&r.data.customer?.mobile===mobile,'Customer session');
  r=await req('POST','/api/customer/home-services',{service:'आधार सेवाएँ — Aadhaar Address Update',address:'E2E Test Address',preferred_date:new Date(Date.now()+24*60*60*1000).toISOString().slice(0,10),preferred_time:'10:00'},{'X-Customer-Session':customer}); assert(r.status===201&&r.data.home_service_id,'Home service request');
  r=await req('GET','/api/customer/home-services',undefined,{'X-Customer-Session':customer}); assert(r.status===200&&r.data.home_services?.length===1,'Home service list');

  r=await req('POST','/api/customer/application',{name:'E2E Test Customer',mobile,service,address:'Test Address'}); assert(r.status===200&&r.data.application_id,'Application creation'); const app=r.data;
  r=await req('GET','/api/customer/track?ref='+encodeURIComponent(app.application_id)); assert(r.status===401,'Unauthenticated application tracking blocked');
  r=await req('GET','/api/customer/track?ref='+encodeURIComponent(app.application_id),undefined,{'X-Customer-Session':customer}); assert(r.status===200&&r.data.result?.reference===app.application_id,'Authenticated own application tracking');
  const png='iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFklEQVR4nGMMr3VgYGBgYmBgYGBgAAANMQEYtRtmTwAAAABJRU5ErkJggg==';
  const screenshot='data:image/png;base64,'+png;
  r=await req('POST','/api/customer/payment',{name:'E2E Test Customer',mobile,service,amount,utr:'E2E-'+Date.now(),application_id:app.id,screenshot},{'X-Customer-Session':customer}); assert(r.status===200&&r.data.status==='Pending Verification','Customer payment submission',JSON.stringify(r.data)); const paymentId=r.data.id;
  r=await req('GET','/api/customer/payment/status?id='+paymentId,undefined,{'X-Customer-Session':customer}); assert(r.status===200&&r.data.payment.status==='Pending Verification','Payment pending status');

  r=await req('GET','/api/payments/proof/'+paymentId,undefined,{Authorization:admin}); assert(r.status===200&&String(r.headers['content-type']).startsWith('image/'),'Admin proof review');
  r=await req('POST','/api/payments/status',{id:paymentId,status:'Verified'},{Authorization:admin}); assert(r.status===200&&r.data.status==='Verified','Admin payment verification',JSON.stringify(r.data));
  r=await req('GET','/api/customer/payment/status?id='+paymentId,undefined,{'X-Customer-Session':customer}); assert(r.status===200&&r.data.payment.status==='Verified','Customer sees verified payment');
  r=await req('POST','/api/customer/application',{name:'UTR Only Test',mobile:'90000'+String(Math.floor(10000+Math.random()*89999)),service,address:'UTR Test Address'}); assert(r.status===200&&r.data.application_id,'UTR-only application'); const utrApp=r.data;
  r=await req('POST','/api/customer/payment',{name:'UTR Only Test',mobile:utrApp.mobile,service,amount,utr:'UTR-ONLY-'+Date.now(),application_id:utrApp.id},{'X-Customer-Session':utrApp.customer_token}); assert(r.status===200&&r.data.status==='Pending Verification','UTR-only payment accepted without screenshot');

  r=await req('POST','/api/customer/tokens',{payment_id:paymentId,name:'E2E Test Customer',mobile,service},{'X-Customer-Session':customer}); assert(r.status===200&&r.data.token,'Token generated after payment verification, before documents',JSON.stringify(r.data)); const tokenId=r.data.id, tokenRef=r.data.token;
  r=await req('GET','/api/customer/dashboard',undefined,{'X-Customer-Session':customer}); assert(r.status===200&&r.data.payments?.some(x=>Number(x.id)===Number(paymentId)&&x.status==='Verified'&&Number(x.token_id)===Number(tokenId)),'Customer dashboard keeps verified payment linked to generated token',JSON.stringify(r.data));
  r=await req('GET','/api/customer/progress?application_id='+app.id,undefined,{'X-Customer-Session':customer}); const progressAfterToken=r.data?.progress; assert(r.status===200&&progressAfterToken?.items?.find(x=>x.id==='token')?.done===true&&progressAfterToken?.items?.find(x=>x.id==='documents')?.done===false&&progressAfterToken?.items?.find(x=>x.id==='processing')?.done===false,'Cross-page workflow state after token generation is consistent',JSON.stringify(progressAfterToken));
  r=await req('GET','/api/tokens',undefined,{Authorization:admin}); assert(r.status===200&&r.data.tokens?.some(x=>Number(x.id)===Number(tokenId)&&Number(x.application_id)===Number(app.id)&&Number(x.payment_id)===Number(paymentId)),'Admin token management sees the same application/payment token',JSON.stringify(r.data));
  r=await req('GET','/api/sops?service='+encodeURIComponent(service),undefined,{Authorization:admin}); assert(r.status===200&&r.data.sop,'Service SOP');
  const requiredDocs=r.data.sop.documents||[]; assert(requiredDocs.length>0,'Required documents configured');
  const jpeg='/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAABAAEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8jK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3+iiigD//2Q==';
  const files=requiredDocs.map((name,i)=>({name:String(name||('required-'+i))+'.png',document_type:String(name||('required-'+i)),mime_type:'image/png',data:png}));
  r=await req('POST','/api/customer/documents',{application_id:app.id,files},{'X-Customer-Session':customer}); assert(r.status===201&&r.data.documents?.length>=requiredDocs.length,'Customer uploads required documents',JSON.stringify(r.data));
  assert(r.data.documents.every(d=>d.ocr_status==='queued'||d.ocr_status==='processing'||d.ocr_status==='completed'),'Image OCR is queued asynchronously',JSON.stringify(r.data.documents));
  for(const d of r.data.documents){r=await req('POST','/api/documents/'+d.id+'/status',{status:'verified',note:'E2E Admin document verification'},{Authorization:admin});assert(r.status===200&&r.data.document?.status==='verified','Admin verifies document',JSON.stringify(r.data));}
  let ocrReady=false;
  for(let i=0;i<20&&!ocrReady;i++){await new Promise(resolve=>setTimeout(resolve,100));r=await req('GET','/api/customer/documents?application_id='+app.id,undefined,{'X-Customer-Session':customer});ocrReady=r.status===200&&r.data.documents?.every(d=>['completed','failed'].includes(String(d.ocr_status)));}
  assert(ocrReady,'Background OCR jobs settle without blocking the request flow');
  r=await req('POST','/api/customer/tokens',{payment_id:paymentId,name:'E2E Test Customer',mobile,service},{'X-Customer-Session':customer}); assert(r.status===409,'Duplicate token blocked after token generation',JSON.stringify(r.data));
  r=await req('GET','/api/customer/track?ref='+encodeURIComponent(tokenRef)); assert(r.status===401,'Unauthenticated token tracking blocked');
  r=await req('GET','/api/customer/track?ref='+encodeURIComponent(tokenRef),undefined,{'X-Customer-Session':customer}); assert(r.status===200&&r.data.result?.reference===tokenRef,'Authenticated own token tracking');
  r=await req('GET','/api/customer/records',undefined,{'X-Customer-Session':customer}); assert(r.status===200&&r.data.tokens?.some(x=>Number(x.id)===Number(tokenId)),'Customer token history');

  r=await req('POST','/api/staff',{name:'E2E Viewer Staff',mobile:'92222'+String(Math.floor(10000+Math.random()*89999)),pin:'1358',role:'viewer',daily_rate:250},{Authorization:admin}); assert(r.status===200&&r.data?.role==='viewer'&&r.data?.permissions?.includes('quality_view')&&!r.data?.permissions?.includes('task_update'),'Viewer role creation/RBAC'); const viewerEmployee=r.data.employee_id;
  r=await req('POST','/api/staff',{name:'E2E Invalid Role',mobile:'93333'+String(Math.floor(10000+Math.random()*89999)),pin:'1359',role:'not_a_role',daily_rate:250},{Authorization:admin}); assert(r.status===400,'Invalid staff role rejected');
  r=await req('POST','/api/staff/login',{identifier:viewerEmployee,pin:'1358'}); assert(r.status===200&&r.headers['set-cookie']?.some(x=>x.startsWith('angel_staff=')),'Viewer staff login'); const viewer=registerStaffSession(r);
  r=await req('POST','/api/staff/tasks',{id:tokenId,action:'start'},{'X-Staff-Session':viewer}); assert(r.status===403,'Viewer cannot update staff task');
  r=await req('GET','/api/staff/dashboard',undefined,{'X-Staff-Session':viewer}); assert(r.status===200,'Viewer dashboard access');
  r=await req('POST','/api/staff/logout',undefined,{'X-Staff-Session':viewer}); assert(r.status===200,'Viewer logout');
  r=await req('POST','/api/staff',{name:'E2E Test Staff',mobile:'91111'+String(Math.floor(10000+Math.random()*89999)),pin:'1357',role:'staff',daily_rate:300},{Authorization:admin}); assert(r.status===200&&r.data?.staff_id,'Staff creation',JSON.stringify(r.data)); const staffId=r.data.staff_id, staffEmployee=r.data.employee_id, staffMobile=r.data.mobile;
  r=await req('POST','/api/staff/'+encodeURIComponent(staffId),{action:'assign',token_id:tokenId},{Authorization:admin}); assert(r.status===200,'Token assignment');
  // The queue state machine requires Admin to call a pending token before assigned staff can start it.
  r=await req('POST','/api/tokens',{id:tokenId,action:'next'},{Authorization:admin}); assert(r.status===200&&r.data?.status==='बुलाया','Token called');
  r=await req('POST','/api/staff/login',{identifier:staffEmployee,pin:'1357'}); assert(r.status===200&&r.headers['set-cookie']?.some(x=>x.startsWith('angel_staff=')),'Staff login'); const staff=registerStaffSession(r);
  r=await req('POST','/api/staff/tasks',{id:tokenId,action:'start'},{'X-Staff-Session':staff}); assert(r.status===200&&r.data.status==='प्रगति','Staff starts task');
  r=await req('GET','/api/service-quality?token_id='+tokenId,undefined,{'X-Staff-Session':staff}); assert(r.status===200&&r.data.sop?.checks?.length,'Staff gets SOP');
  const sop=r.data.sop;
  const checks=sop.checks.map(x=>({id:x.id,checked:true}));
  r=await req('POST','/api/service-quality',{token_id:tokenId,checks,notes:'E2E staff checklist submission'},{'X-Staff-Session':staff}); assert(r.status===200&&r.data.quality?.status==='submitted','Staff submits quality review',JSON.stringify(r.data));
  r=await req('POST','/api/staff/tasks',{id:tokenId,action:'complete'},{'X-Staff-Session':staff}); assert(r.status===400,'Staff cannot complete before Admin QC');
  r=await req('POST','/api/service-quality',{token_id:tokenId,checks,action:'pass',notes:'E2E admin final quality review'},{Authorization:admin}); assert(r.status===200&&r.data.quality?.status==='passed'&&r.data.quality?.review_stage==='admin','Admin final quality review pass',JSON.stringify(r.data));
  r=await req('POST','/api/staff/tasks',{id:tokenId,action:'complete'},{'X-Staff-Session':staff}); assert(r.status===200&&r.data.status==='पूर्ण','Staff completes task');
  r=await req('GET','/api/customer/dashboard',undefined,{'X-Customer-Session':customer}); assert(r.status===200&&r.data.receipts?.some(x=>x.receipt_no),'Automatic completion receipt');
  r=await req('GET','/api/customer/records',undefined,{'X-Customer-Session':customer}); assert(r.status===200&&r.data.receipts?.length,'Completed receipt appears in Customer Receipt & Records'); const completedReceipt=r.data.receipts.find(x=>x.receipt_no);
  r=await req('GET','/api/customer/receipts/'+completedReceipt.id+'.pdf',undefined,{'X-Customer-Session':customer}); const ownPdf=Buffer.isBuffer(r.data)?r.data:null; assert(r.status===200&&String(r.headers['content-type']).startsWith('application/pdf'),'Customer can download own completed receipt PDF',String(r.headers['content-type']||''));
  r=await req('GET','/api/admin/receipts/'+completedReceipt.id+'.pdf',undefined,{Authorization:admin}); assert(r.status===200&&String(r.headers['content-type']).startsWith('application/pdf'),'Admin can download completed receipt PDF');
  const secondMobile='98888'+String(Math.floor(10000+Math.random()*89999)); r=await req('POST','/api/customer/register',{name:'Receipt Isolation Test',mobile:secondMobile,pin:'2469'}); assert(r.status===201&&r.headers['set-cookie']?.some(x=>x.startsWith('angel_customer=')),'Second customer registration for receipt ownership test'); const secondCustomer=registerCustomerSession(r);
  r=await req('GET','/api/customer/receipts/'+completedReceipt.id+'.pdf',undefined,{'X-Customer-Session':secondCustomer}); assert(r.status===404,'Customer cannot download another customer receipt PDF');
  r=await req('GET','/api/customer/records',undefined,{'X-Customer-Session':secondCustomer}); assert(r.status===200&&!r.data.receipts?.some(x=>Number(x.id)===Number(completedReceipt.id)),'Customer Receipt & Records excludes another customer receipt');

  r=await req('GET','/api/customer/dashboard',undefined,{'X-Customer-Session':customer}); assert(r.status===200,'Customer dashboard');
  r=await req('GET','/api/customer-history?mobile='+mobile,undefined,{Authorization:admin}); assert(r.status===200&&r.data.summary?.tokens>=1&&r.data.summary?.payments>=1,'Admin customer history');
  r=await req('GET','/api/reports',undefined,{Authorization:admin}); assert(r.status===200&&r.data.summary,'Reports',JSON.stringify(r.data));
  r=await req('GET','/api/control-center',undefined,{Authorization:admin}); assert(r.status===200&&r.data.kpis,'Control center');
  r=await req('GET','/api/finance/summary',undefined,{Authorization:admin}); assert(r.status===200&&r.data.summary,'Finance summary');
  r=await req('GET','/api/system/integrity',undefined,{Authorization:admin}); assert(r.status===200&&r.data.ok,'Final integrity',JSON.stringify(r.data));

  r=await req('POST','/api/staff/logout',undefined,{'X-Staff-Session':staff}); assert(r.status===200,'Staff logout');
  r=await req('GET','/api/staff/me',undefined,{'X-Staff-Session':staff}); assert(r.status===401,'Revoked staff session');
  r=await req('POST','/api/customer/logout',undefined,{'X-Customer-Session':customer}); assert(r.status===200,'Customer logout');
  r=await req('GET','/api/customer/me',undefined,{'X-Customer-Session':customer}); assert(r.status===401,'Revoked customer session');
  r=await req('POST','/api/auth/logout',undefined,{Authorization:admin}); assert(r.status===200,'Admin logout');
  r=await req('GET','/api/control-center',undefined,{Authorization:admin}); assert(r.status===401,'Revoked admin session');

  report.ok=true; report.finished_at=new Date().toISOString();
  console.log(JSON.stringify(report,null,2));
}
main().catch(e=>{report.ok=false;report.error=e.message;report.finished_at=new Date().toISOString();console.error(JSON.stringify(report,null,2));process.exitCode=1});
