# Angelstore CSC — STEP126 Business Workflow Fix Report

Date: 2026-09-23

## Scope
Application → Payment → Verification → Token → Staff → QC → Completion → Home Service → Delivery → Commission → Settlement.

## Implemented fixes

1. Token state machine is now explicit.
   - Pending → Called/Skipped
   - Called → In Progress/Hold/Skipped
   - In Progress → Hold/Completed (Completed requires QC passed)
   - Hold → Called/Skipped
   - Skipped/Completed/Cancelled are terminal.
2. Admin `next` now acts on the selected pending token instead of silently selecting the first pending token.
3. Only one queue token may be in Called/In Progress state at a time.
4. Admin token `complete` now requires In Progress + passed final quality review.
5. Admin recall/hold/skip actions now validate the current state.
6. Staff token start/hold/complete actions now validate state transitions.
7. Token assignment is blocked for closed/skipped tokens and reassignment to a different staff member is blocked.
8. Home-service assignment/start/complete/cancel transitions are validated.
9. Delivery assignment/pickup/out-for-delivery/deliver/cancel transitions are validated.
10. Duplicate commission creation for the same staff/source_type/source_id is blocked when a source ID is supplied.
11. Duplicate pending/paid settlement creation for the same staff and period is blocked.

## Validation performed

- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `npm run check` — PASS
- Existing E2E test could not be completed because the test harness expects an admin credential/session state that was not available in the extracted test environment. No claim of full E2E verification is made.

## Files changed

- `server.js`
- `STEP126_BUSINESS_WORKFLOW_FIX_REPORT.md`

No frontend files were intentionally changed.
