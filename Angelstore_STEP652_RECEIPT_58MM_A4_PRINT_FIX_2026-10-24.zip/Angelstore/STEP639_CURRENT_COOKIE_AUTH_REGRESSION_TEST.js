const {spawn}=require('child_process'),fs=require('fs'),path=require('path'),os=require('os'),http=require('http'),assert=require('assert');
const root=__dirname,tmp=fs.mkdtempSync(path.join(os.tmpdir(),'angelstore-step639-')),port=18939;
for(const d of ['uploads/payments','uploads/documents','backups'])fs.mkdirSync(path.join(tmp,d),{recursive:true});fs.writeFileSync(path.join(tmp,'data.json'),'{}');
const env={...process.env,PORT:String(port),HOST:'127.0.0.1',NODE_ENV:'development',ANGELSTORE_STORAGE_DIR:tmp,ANGELSTORE_AUTH_SECRET:'step639-auth-secret-abcdefghijklmnopqrstuvwxyz-123456',ANGELSTORE_ADMIN_USER:'step639admin',ANGELSTORE_ADMIN_PASS:'Step639-Strong-Password-2026!'};
const cp=spawn(process.execPath,['server.js'],{cwd:root,env,stdio:['ignore','pipe','pipe']});
function req(method,p,body=null,headers={}){return new Promise((resolve,reject)=>{const r=http.request({hostname:'127.0.0.1',port,path:p,method,headers:{'Content-Type':'application/json',...headers}},res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{let j={};try{j=JSON.parse(d)}catch{};resolve({status:res.statusCode,body:j,headers:res.headers})})});r.on('error',reject);if(body)r.write(JSON.stringify(body));r.end()})}
function auth(resp){const cookies=resp.headers['set-cookie']||[];const jar=cookies.map(x=>x.split(';')[0]).join('; ');const csrf=(jar.match(/(?:^|; )angel_csrf=([^;]+)/)||[])[1];return {Cookie:jar,...(csrf?{'X-CSRF-Token':decodeURIComponent(csrf)}:{})}}
async function ready(){for(let i=0;i<80;i++){try{if((await req('GET','/api/health')).status===200)return}catch{}await new Promise(r=>setTimeout(r,50))}throw Error('server not ready')}
(async()=>{try{await ready();
let r=await req('POST','/api/auth/login',{username:env.ANGELSTORE_ADMIN_USER,password:env.ANGELSTORE_ADMIN_PASS});assert.equal(r.status,200);const ah=auth(r);assert(ah.Cookie.includes('angel_admin='));
const mobile='98'+String(Date.now()).slice(-8),service='आधार सेवाएँ — Aadhaar Address Update';
r=await req('POST','/api/customer/register',{name:'STEP639 Customer',mobile,pin:'2468'});assert.equal(r.status,201);const ch=auth(r);assert(ch.Cookie.includes('angel_customer='));assert(ch['X-CSRF-Token']);
r=await req('GET','/api/customer/me',null,ch);assert.equal(r.status,200);assert.equal(r.body.customer.mobile,mobile);console.log('PASS 1/6 customer HttpOnly cookie session');
r=await req('POST','/api/customer/application',{name:'STEP639 Customer',mobile,service,category:'आधार सेवाएँ'},ch);assert([200,201].includes(r.status));const app=r.body;
r=await req('POST','/api/payments',{name:'STEP639 Customer',mobile,service,amount:75,method:'UPI',utr:'S639'+Date.now(),application_id:app.id},ah);assert([200,201].includes(r.status));const pay=r.body;
r=await req('POST','/api/payments/status',{id:pay.id,status:'Verified'},ah);assert.equal(r.status,200);console.log('PASS 2/6 payment verification under cookie-authenticated admin');
r=await req('POST','/api/customer/tokens',{payment_id:pay.id,name:'STEP639 Customer',mobile,service},ch);assert.equal(r.status,200);const tid=r.body.id;assert(tid);console.log('PASS 3/6 token generation under customer cookie session');
r=await req('GET','/api/customer/tokens',null,ch);assert.equal(r.status,200);assert(r.body.tokens.some(x=>x.id===tid));console.log('PASS 4/6 customer token readback');
r=await req('GET','/api/tokens',null,ah);assert.equal(r.status,200);assert(r.body.tokens.some(x=>x.id===tid));console.log('PASS 5/6 admin queue readback');
r=await req('GET','/api/customer/tokens');assert.equal(r.status,401);console.log('PASS 6/6 unauthenticated customer access rejected');
console.log('STEP639 CURRENT COOKIE AUTH REGRESSION TEST: 6/6 PASS');
}catch(e){console.error('STEP639 FAIL:',e.stack||e);process.exitCode=1}finally{cp.kill('SIGTERM');setTimeout(()=>{try{fs.rmSync(tmp,{recursive:true,force:true})}catch{}},300)}})();
