'use strict';
// Starts Angelstore on isolated temporary storage, runs E2E-TEST.js, then stops and cleans up.
// This runner never reads or writes the project's normal data.json or production storage.
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const net = require('net');
const { spawn, spawnSync } = require('child_process');

const ROOT = __dirname;
const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'angelstore-e2e-'));
const adminUser = 'angelstore_e2e_admin';
const adminPass = 'E2E-Only-Admin-Password-2026!';
const authSecret = require('crypto').randomBytes(48).toString('hex');
let server = null;
let serverOutput = '';
let finished = false;

function getFreePort() {
  return new Promise((resolve, reject) => {
    const probe = net.createServer();
    probe.once('error', reject);
    probe.listen(0, '127.0.0.1', () => {
      const port = probe.address().port;
      probe.close(err => err ? reject(err) : resolve(port));
    });
  });
}
function health(port, timeout = 700) {
  return new Promise(resolve => {
    const req = http.get({ hostname: '127.0.0.1', port, path: '/api/health', timeout }, res => {
      res.resume(); resolve(res.statusCode === 200);
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
  });
}
function stopServer() {
  if (!server || server.killed) return Promise.resolve();
  return new Promise(resolve => {
    const timer = setTimeout(() => { try { server.kill('SIGKILL'); } catch {} resolve(); }, 2500);
    server.once('exit', () => { clearTimeout(timer); resolve(); });
    try { server.kill('SIGTERM'); } catch { clearTimeout(timer); resolve(); }
  });
}
async function cleanup() {
  if (finished) return;
  finished = true;
  await stopServer();
  try { fs.rmSync(tempRoot, { recursive: true, force: true }); } catch {}
}
async function main() {
  const port = await getFreePort();
  const env = {
    ...process.env,
    NODE_ENV: 'test',
    PORT: String(port),
    HOST: '127.0.0.1',
    ANGELSTORE_STORAGE_DIR: tempRoot,
    ANGELSTORE_AUTH_SECRET: authSecret,
    ANGELSTORE_ADMIN_USER: adminUser,
    ANGELSTORE_ADMIN_PASS: adminPass,
    ANGELSTORE_CORS_ORIGIN: 'https://angelstore-e2e.invalid',
    ANGELSTORE_SCHEDULED_BACKUP: 'false'
  };
  server = spawn(process.execPath, ['server.js'], { cwd: ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] });
  server.stdout.on('data', chunk => { serverOutput += chunk.toString(); });
  server.stderr.on('data', chunk => { serverOutput += chunk.toString(); });
  server.on('error', err => { serverOutput += String(err); });

  let ready = false;
  const deadline = Date.now() + 12000;
  while (Date.now() < deadline && !ready) {
    if (server.exitCode !== null) break;
    ready = await health(port);
    if (!ready) await new Promise(r => setTimeout(r, 120));
  }
  if (!ready) throw new Error('Isolated server did not become healthy. ' + serverOutput.slice(-1200));

  const run = spawnSync(process.execPath, ['E2E-TEST.js'], {
    cwd: ROOT,
    env: { ...env, E2E_BASE: `http://127.0.0.1:${port}` },
    encoding: 'utf8',
    timeout: 90000,
    maxBuffer: 8 * 1024 * 1024
  });
  if (run.stdout) process.stdout.write(run.stdout);
  if (run.stderr) process.stderr.write(run.stderr);
  if (run.error) throw run.error;
  if (run.status !== 0) throw new Error(`E2E test exited with status ${run.status}.`);
}
main().catch(err => {
  console.error(JSON.stringify({ ok: false, runner: 'RUN-ISOLATED-E2E', error: String(err.message || err) }, null, 2));
  process.exitCode = 1;
}).finally(cleanup);
