const fs=require('fs'),path=require('path'),os=require('os'),child=require('child_process'),http=require('http'),assert=require('assert');
const root=__dirname,tmp=fs.mkdtempSync(path.join(os.tmpdir(),'angelstore-step499-')),port=18899,user='step499admin',pass='Step499-Strong-Password-2026!',iso=new Date().toISOString(),today=iso.slice(0,10);
const services=['LOAD-A','LOAD-B','LOAD-C','LOAD-D','LOAD-E'];
const tokens=[];
for(let i=1;i<=3000;i++){
  const service=services[(i-1)%services.length];
  let status='लंबित';
  if(i===1) status='प्रगति'; else if(i%17===0) status='पूर्ण'; else if(i%29===0) status='होल्ड'; else if(i%31===0) status='स्किप';
  const t={id:i,token:`T-${String(i).padStart(4,'0')}`,name:`Load ${i}`,mobile:`98${String(10000000+i).slice(-8)}`,service,status,created_at:iso,date:today,priority:i%11===0?1:0,state_revision:status==='पूर्ण'?3:0,last_action_at:iso};
  if(status==='प्रगति'||status==='पूर्ण'){t.started_at=iso}
  if(status==='पूर्ण'){t.completed_at=new Date(Date.now()+15*60000).toISOString();t.quality_status='passed';t.payment_id=null}
  if(status==='होल्ड'){t.hold_reason='Load test hold';t.hold_owner='operator';t.hold_delay_minutes=10;t.hold_started_at=iso}
  tokens.push(t);
}
// Ensure exactly one active token per service for deterministic current_by_service assertions.
for(const service of services){
  const rows=tokens.filter(t=>t.service===service);
  rows.forEach((t,idx)=>{if(t.status==='प्रगति'&&idx>0)t.status='लंबित'});
  rows[0].status='प्रगति';rows[0].started_at=iso;
}
const base={meta:{schema_version:2},settings:{centre:'Angelstore CSC',operator:'STEP499'},tokens,payments:[],applications:[],audit:[],notifications:[],staff:[],customers:[],documents:[],appointments:[]};
fs.writeFileSync(path.join(tmp,'data.json'),JSON.stringify(base));
const cp=child.spawn(process.execPath,['server.js'],{cwd:root,env:{...process.env,PORT:String(port),HOST:'127.0.0.1',ANGELSTORE_STORAGE_DIR:tmp,ANGELSTORE_ADMIN_USER:user,ANGELSTORE_ADMIN_PASS:pass,ANGELSTORE_AUTH_SECRET:'step499-auth-secret-abcdefghijklmnopqrstuvwxyz-123456'},stdio:['ignore','pipe','pipe']});
function req(method,p,body,token){return new Promise((resolve,reject)=>{const r=http.request({hostname:'127.0.0.1',port,path:p,method,headers:{'Content-Type':'application/json',...(token||{})}},res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{let j={};try{j=JSON.parse(d)}catch{}resolve({status:res.statusCode,body:j,headers:res.headers})})});r.on('error',reject);if(body)r.write(JSON.stringify(body));r.end()})}
async function waitReady(){for(let i=0;i<80;i++){try{const r=await req('GET','/api/health');if(r.status===200)return}catch{}await new Promise(r=>setTimeout(r,50))}throw new Error('server did not become ready')}
function sessionHeaders(resp){const set=resp.headers?.['set-cookie']||[];const jar=set.map(v=>v.split(';')[0]).join('; ');const csrfMatch=jar.match(/(?:^|; )angel_csrf=([^;]+)/);if(!jar.includes('angel_admin=')||!csrfMatch)throw Error('admin cookie/CSRF missing');return {Cookie:jar,'X-CSRF-Token':decodeURIComponent(csrfMatch[1])}}
(async()=>{try{
  await waitReady();
  let r=await req('POST','/api/auth/login',{username:user,password:pass});assert.equal(r.status,200);const tok=sessionHeaders(r);
  const started=Date.now();r=await req('GET','/api/tokens',null,tok);const elapsed=Date.now()-started;assert.equal(r.status,200);assert.equal(r.body.tokens.length,3000);assert.equal(r.body.service_queues.length,5);assert(elapsed<8000,`single queue scan took ${elapsed}ms`);console.log(`PASS single 3000-token queue scan: ${elapsed}ms`);
  const byService=new Map();for(const t of r.body.tokens){byService.set(t.service,(byService.get(t.service)||0)+1)}for(const s of services)assert.equal(byService.get(s),600);console.log('PASS token distribution/data integrity: 3000/3000 preserved');
  for(const q of r.body.service_queues){assert.equal(q.tokens.length,600);assert(Number.isInteger(q.waiting)&&q.waiting>=0&&q.waiting<=600);assert(Number.isInteger(q.completed)&&q.completed>=0&&q.completed<=600);assert.equal(q.current,q.tokens.find(x=>['बुलाया','प्रगति'].includes(x.status))?.token||null)}console.log('PASS service queue counts/current-token consistency');
  const sample=r.body.tokens.find(x=>x.token==='T-0001');assert(sample&&sample.status==='प्रगति'&&sample.queue_position>=1&&sample.waiting_count>=0&&sample.ahead_count>=0);console.log('PASS public queue metadata remains internally valid');
  const t0=Date.now();const concurrent=await Promise.all([1,2,3,4].map(()=>req('GET','/api/tokens',null,tok)));const concurrentElapsed=Date.now()-t0;assert(concurrent.every(x=>x.status===200));assert(concurrent.every(x=>x.body.tokens.length===3000));assert(concurrent.every(x=>x.body.service_queues.length===5));assert(concurrentElapsed<15000,`4 concurrent scans took ${concurrentElapsed}ms`);console.log(`PASS 4 concurrent queue scans: ${concurrentElapsed}ms`);
  const active=r.body.tokens.find(x=>x.status==='प्रगति');assert(active);const hold=await req('POST','/api/tokens',{id:active.id,action:'hold',reason:'STEP499 stress integrity',owner:'operator',delay_minutes:5,request_id:'step499-hold-1',expected_state_revision:active.state_revision},tok);assert.equal(hold.status,200);assert.equal(hold.body.status,'होल्ड');assert(Number(hold.body.state_revision)>Number(active.state_revision));
  const saved=JSON.parse(fs.readFileSync(path.join(tmp,'data.json'),'utf8'));const stored=saved.tokens.find(x=>x.id===active.id);assert.equal(stored.status,'होल्ड');assert.equal(stored.last_action_request_id,'step499-hold-1');console.log('PASS write/read consistency after token mutation');
  const resume=await req('POST','/api/tokens',{id:active.id,action:'resume',request_id:'step499-resume-1',expected_state_revision:hold.body.state_revision},tok);assert.equal(resume.status,200);assert(['बुलाया','प्रगति'].includes(resume.body.status));
  const saved2=JSON.parse(fs.readFileSync(path.join(tmp,'data.json'),'utf8'));const stored2=saved2.tokens.find(x=>x.id===active.id);assert(['बुलाया','प्रगति'].includes(stored2.status));assert(Array.isArray(stored2.hold_history)&&stored2.hold_history.length>=1);console.log('PASS hold/resume persisted without corrupting token history');
  console.log('STEP499 TOKEN QUEUE LOAD/STRESS TEST: 7/7 PASS');
}catch(e){console.error('STEP499 FAIL:',e.stack||e);process.exitCode=1}finally{cp.kill('SIGTERM');setTimeout(()=>{try{fs.rmSync(tmp,{recursive:true,force:true})}catch{}},300)}})();
