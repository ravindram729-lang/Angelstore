# Phase 6 — Home Service, Delivery & Finance

Implemented:
- Customer-authenticated Home Service request API.
- Admin Home Service management and staff assignment.
- Staff start/complete workflow for assigned Home Services.
- Customer Delivery listing API.
- Admin Delivery creation and staff assignment.
- Staff pickup → out-for-delivery → delivered workflow.
- Configurable default Home Service Fee, Delivery Fee, Home Staff Allowance and Delivery Staff Allowance.
- Finance summary separating customer collection, official fees, staff commission, home/delivery costs, payment charges and Angelstore contribution.
- Admin dashboard pages for Home/Delivery and Finance.
- Staff dashboard actions for assigned Home Services and Deliveries.
- Audit events for creation, assignment and status changes.

Default values (editable in Admin Finance):
- Home Service Fee: ₹50
- Delivery Fee: ₹40
- Home Staff Allowance: ₹20
- Delivery Staff Allowance: ₹15

No automatic bank verification was added. Existing manual UTR/payment verification remains unchanged.
