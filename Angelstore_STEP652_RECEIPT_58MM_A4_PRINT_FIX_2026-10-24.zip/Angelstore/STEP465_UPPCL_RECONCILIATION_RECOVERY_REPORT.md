# STEP465 — UPPCL Reconciliation & Recovery Hardening

## Objective
Implement a controlled Admin recovery workflow for UPPCL reconciliation issues without destructive automatic repair.

## Changes
- Added `POST /api/admin/uppcl/reconciliation/recover`.
- Added controlled `repair_payment_application` action.
- Added audit-only `mark_reviewed` action.
- Reconciliation now surfaces safe candidate applications for eligible payment/application link issues.
- Repair is allowed only when:
  - UPPCL payment is `Pending Verification` or `Verified`.
  - UPPCL processing state is still `Awaiting Payment Verification`.
  - Target application is UPPCL.
  - Customer mobile, account, bill ID and bill version all match.
  - Target application is not already linked to another payment.
- Completed/Rejected or already-processed payments cannot be relinked.
- Every repair creates `UPPCL_RECONCILIATION_LINK_REPAIRED` audit event.
- Every review-only action creates `UPPCL_RECONCILIATION_ISSUE_REVIEWED` audit event.
- Admin UI now presents `Review → Repair Link → Revalidate → Audit Log` workflow.
- Repair requires explicit confirmation.

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- STEP465 controlled recovery E2E — PASS
  - candidate detection
  - controlled link repair
  - revalidation to healthy state
  - persistence verification
  - review action is audit-only
  - repair/review audit logs
- STEP463 payment/application consistency E2E — PASS
- STEP462 payment idempotency E2E — PASS
- P0/P1 regression — PASS
- Final release audit — PASS
- Admin HTML recovery/static handler audit — PASS (17 inline script blocks inspected)

## Note
A legacy STEP460 state-machine E2E fixture still expects the older payment request shape and fails on the newer required bill-version field. This was not treated as a product regression; current STEP462/463/465 targeted UPPCL tests and release audits pass.

## Safety model
No automatic data deletion, payment creation, or blind relinking is performed. Recovery requires an explicit Admin action and server-side identity/snapshot validation.
