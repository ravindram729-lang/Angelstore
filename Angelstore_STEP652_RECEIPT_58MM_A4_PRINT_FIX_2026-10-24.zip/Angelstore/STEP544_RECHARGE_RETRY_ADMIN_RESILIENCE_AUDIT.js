const fs=require('fs');
const app=fs.readFileSync('app.js','utf8');
const html=fs.readFileSync('admin.html','utf8');
const server=fs.readFileSync('server.js','utf8');
const checks=[];
function pass(name,ok,detail){checks.push({name,ok:!!ok,detail});}
pass('monitoring uses independent allSettled requests',app.includes('Promise.allSettled([') && app.includes("monitoringRequest('/api/admin/monitoring')") && app.includes("monitoringRequest('/api/admin/incidents')") && app.includes("monitoringRequest('/api/admin/recharge-retry-observability')"));
pass('monitoring requests have timeout protection',app.includes('function monitoringRequest(path,timeoutMs=10000)') && app.includes('MONITOR_TIMEOUT'));
pass('Check Now disables during refresh',app.includes("btn.disabled=true") && app.includes("btn.textContent='⏳ Checking…'") && app.includes("btn.disabled=false"));
pass('timeout/error restores Check Now state',app.includes('finally{') && app.includes("btn.textContent='↻ Check Now'"));
pass('system monitoring failure has visible state',app.includes("setMonitoringPanelState('#monitorChecks','System monitoring unavailable','error')"));
pass('recharge observability failure has visible state',app.includes("setMonitoringPanelState('#retryObsDetails','Recharge observability unavailable','error')"));
pass('incident history failure has table-safe state',app.includes("Incident history unavailable") && app.includes("<tr><td colspan=\"6\">"));
pass('partial success does not discard healthy sections',app.includes('if(m){') && app.includes('if(rro){') && app.includes('if(i){'));
pass('partial load gives user notification',app.includes("Monitoring partially loaded: ${failures.length} section(s) unavailable"));
pass('admin endpoint remains protected',server.includes("p==='/api/admin/recharge-retry-observability'&&req.method==='GET'") && server.includes("if(!a)return json(res,401"));
pass('canonical observability fields still rendered',app.includes('retries_total') && app.includes('retry_groups') && app.includes('attempts_submitted_24h') && app.includes('retry_receipts_24h'));
pass('no cart/order dependency introduced',!app.includes('rechargeRetryCart') && !app.includes('rechargeRetryOrder'));
const failed=checks.filter(x=>!x.ok);
const out={step:'STEP544',title:'Recharge Retry Admin Monitoring API Failure/Timeout & Partial-Data Resilience Audit',passed:checks.length-failed.length,total:checks.length,checks,verdict:failed.length?'FAIL':'PASS'};
fs.writeFileSync('STEP544_RECHARGE_RETRY_ADMIN_RESILIENCE_AUDIT_REPORT.json',JSON.stringify(out,null,2));
console.log(`${out.verdict}: ${out.passed}/${out.total}`);if(failed.length){for(const x of failed)console.log('FAIL',x.name,x.detail||'');process.exit(1)}
