# Phase D — Backend/API Audit & Hardening

## Scope
Audited `server.js` from Phase 21 for authentication, authorization, customer/guest isolation, validation, error handling, payment/token controls, staff ownership checks, finance/admin permissions, and public API exposure.

## Findings and fixes

### 1. Critical — Customer token data exposure
`GET /api/customer/tokens` previously returned the full token list when called without authentication. This exposed customer-linked token records through a public endpoint.

**Fix:**
- Unauthenticated requests now receive only the current public queue token (if any).
- Authenticated customers receive only their own token records.
- Guest application sessions receive only records scoped to their application.
- `?mobile=` requires a matching authenticated/guest session.

### 2. High — Guest application abuse protection
Guest application creation had no request-rate control.

**Fix:**
- Added per-IP rate limit: 20 application requests per 15 minutes.
- Name/address/note inputs are length-limited.
- Submitted category is no longer trusted; category is derived from the validated service.

### 3. Medium — Invalid JSON response
Malformed JSON previously fell through the generic exception handler and returned HTTP 500.

**Fix:**
- Invalid JSON now returns HTTP 400.
- Oversized payload errors return HTTP 413.
- Generic unexpected errors no longer expose the raw exception message to clients.

### 4. Medium — Admin token issuance consistency
Admin token issuance created the token but did not update the linked application status or audit trail consistently with the customer token-generation path.

**Fix:**
- Linked application status becomes `Token Generated`.
- `TOKEN_GENERATED` audit event is recorded with admin actor.

## Authorization checks verified

- Admin-only reports/control/finance/settings/backup/payment verification endpoints require an active admin session.
- Staff endpoints require an active staff session.
- Staff home-service/delivery mutations are restricted to the assigned staff member.
- Customer dashboard/history/appointments require a customer session.
- Guest payment/token operations require a valid application-scoped customer token.
- Payment proof is admin-only.
- Token generation requires verified payment and matching customer/service/amount.
- Duplicate UTR and duplicate token generation are rejected.

## Verification

- `node --check server.js` — PASS
- Local `/api/health` — PASS
- Public token endpoint no longer exposes full token list — PASS
- Guest token endpoint is application-scoped — PASS
- Mobile token query without authentication — 401 PASS
- Malformed JSON — 400 PASS
- Guest application creation — PASS
- Category is derived from validated service — PASS
- Admin unauthenticated token API — 401 PASS

## Not verified in this phase

- Live Netlify/production backend connectivity
- External SMS/WhatsApp providers
- Real bank/UPI verification
- Persistent production database/storage behavior
- Production concurrency/load testing
