# STEP464 — UPPCL Reconciliation & Recovery Audit

## Scope
Read-only Admin reconciliation for UPPCL Payment ↔ Application ↔ Manual Bill consistency.

## Changes
- Added `GET /api/admin/uppcl/reconciliation` (Admin auth required).
- Cross-checks every UPPCL payment against its application and referenced manual bill.
- Detects:
  - `MISSING_APPLICATION`
  - `MISSING_PAYMENT`
  - `APPLICATION_LINK_MISMATCH`
  - `BILL_SNAPSHOT_MISMATCH`
  - `MISSING_BILL`
  - `COMPLETED_APPLICATION_MISMATCH`
  - `REJECTED_PAYMENT_COMPLETED`
- Returns counts, severity, checked record totals and `healthy` / `attention_required` status.
- Added an Admin UPPCL Control Panel reconciliation section with a manual Check button.
- Reconciliation is read-only: it does not silently mutate or delete records.

## Verification
- `node --check server.js` — PASS
- `npm run check` — PASS
- `npm run release-audit` — PASS
- Empty-data reconciliation endpoint — PASS (`healthy`, 0 issues)
- Synthetic mismatch detection — PASS (missing application + missing payment detected)

## Test limitation
The release archive does not contain a `data.json` fixture, so the existing legacy E2E scripts that directly read `data.json` were not rerun from this extracted archive. This is a test-fixture limitation, not a product failure. Targeted runtime checks used isolated temporary storage.

## Safety
No automatic reconciliation mutation was introduced. Admin must inspect and correct any flagged record through existing controlled workflows.
