# STEP476 — UPPCL Step 2 Side-by-Side UI Fix

## Request
Keep **Step 2 — बिल विवरण** visible beside **Step 1 — उपभोक्ता विवरण** on desktop/tablet, matching the supplied reference screenshot.

## Implementation
- Step 2 bill card is no longer hidden before lookup.
- Step 1 and Step 2 occupy the two-column workflow from the initial page state.
- Before a valid bill is found, Step 2 shows a locked/placeholder state instead of misleading bill data.
- After a valid Admin-approved bill lookup, Step 2 becomes active and displays the real Admin-sourced bill values.
- On lookup failure, Step 2 remains visible in its locked state while payment/proof cards remain hidden.
- Mobile/tablet responsive stacking is preserved.
- No payment/business workflow changes.
- No cart/order flow introduced.

## Verification
- `node --check customer.js` — PASS
- `node --check server.js` — PASS
- Reference layout inspected against supplied UPPCL screenshot — PASS (code/layout comparison)
- Fresh live browser visual verification — NOT CLAIMED
