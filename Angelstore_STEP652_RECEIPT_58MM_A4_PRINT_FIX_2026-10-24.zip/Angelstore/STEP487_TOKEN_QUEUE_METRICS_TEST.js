const fs = require('fs');
const path = require('path');
const root = __dirname;
const server = fs.readFileSync(path.join(root,'server.js'),'utf8');
const app = fs.readFileSync(path.join(root,'app.js'),'utf8');
const results=[];
function check(ok,name,detail=''){results.push({name,ok:Boolean(ok),detail});if(!ok)throw new Error(name+(detail?': '+detail:''));}
check(/q\.waiting=q\.tokens\.filter\(t=>t\.status==='लंबित'\)\.length/.test(server),'Service queue waiting count uses pending tokens only');
check(!/q\.waiting=q\.tokens\.filter\(t=>\['लंबित','होल्ड','बुलाया','प्रगति'\]\.includes\(t\.status\)\)\.length/.test(server),'Active/in-service tokens are not counted as waiting');
check(server.includes("q.current=q.tokens.find(t=>['बुलाया','प्रगति'].includes(t.status))?.token||null"),'Current token remains distinct from waiting count');
check(server.includes('waiting_count:qm.waiting_count'),'Public token exposes waiting count from queue metadata');
check(app.includes("$('#tokenWaitingCount'))$('#tokenWaitingCount').textContent=waiting"),'Admin KPI still renders waiting count');
console.log(JSON.stringify({ok:true,checks:results},null,2));
