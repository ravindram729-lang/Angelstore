# STEP463 — UPPCL Payment/Application Consistency Hardening

## Objective
Ensure a UPPCL payment submission cannot leave an orphan application, orphan payment, audit entry, or uploaded proof when persistence fails during the combined payment/application creation flow.

## Change
The customer UPPCL payment endpoint now treats application + payment + audit persistence as one logical transaction:

1. Capture collection lengths before mutation.
2. Create the application and payment records in memory.
3. Add the submission audit entry.
4. Persist with the existing atomic storage layer.
5. If persistence fails, roll back application/payment/audit collection mutations and delete the newly uploaded proof file.
6. Return a retryable `503` response instead of pretending the payment was created.

Existing protections remain intact:
- bill ID/version stale protection
- customer-to-bill mobile ownership check
- amount/month/due-date validation
- idempotency key protection
- duplicate UTR protection
- duplicate screenshot protection
- state-machine processing restrictions

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- STEP463 consistency static/E2E audit — PASS
- STEP462 idempotency E2E — PASS
- STEP456 UPPCL security E2E — PASS
- P0/P1 regression — PASS
- final release audit — PASS
- ZIP integrity — PASS

## Browser note
No fresh live Chromium visual PASS is claimed because the execution environment previously blocked/hung localhost browser access.
