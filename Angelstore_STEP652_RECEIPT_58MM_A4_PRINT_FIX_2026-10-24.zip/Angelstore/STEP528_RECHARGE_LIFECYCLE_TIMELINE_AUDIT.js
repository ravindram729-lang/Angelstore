const fs=require('fs');const s=fs.readFileSync('server.js','utf8');const c=fs.readFileSync('customer.js','utf8');
const tests=[
['customerRecharge exposes payment verified timestamp',/payment_verified_at:pay\?\.verified_at/],
['recharge status history is persisted',/status_history:\[\{status:'Pending'/],
['success stores completed_at',/if\(status==='Success'\)row\.completed_at=row\.completed_at\|\|transitionAt/],
['failure stores failure reason',/row\.failure_reason=transitionReason\|\|row\.failure_reason/],
['payment verification syncs recharge history',/recharge\.status_history\.push\(\{status:'Payment Verified'/],
['payment rejection syncs recharge history',/recharge\.status_history\.push\(\{status:'Payment Rejected'/],
['customer lifecycle modal exists',/function showRechargeTimeline\(r,pay\)/],
['detail button opens lifecycle modal',/showRechargeTimeline\(r,pay\)/],
['receipt remains terminal success only',/const receipt=success\?payment\?\.receipt_no\|\|''/],
['failure notification includes reason',/row\.failure_reason\?' कारण: '/]
];let pass=0;for(const [n,re] of tests){if(re.test(s)||re.test(c)){console.log('PASS',n);pass++}else console.log('FAIL',n)}console.log(`STEP528 ${pass}/${tests.length} PASS`);if(pass!==tests.length)process.exit(1);