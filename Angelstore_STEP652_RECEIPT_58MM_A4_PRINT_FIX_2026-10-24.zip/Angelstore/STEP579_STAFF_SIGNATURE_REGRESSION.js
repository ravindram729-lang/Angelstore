const fs=require('fs'),path=require('path'),root=__dirname;
const server=fs.readFileSync(path.join(root,'server.js'),'utf8');
const staff=fs.readFileSync(path.join(root,'staff.html'),'utf8');
const checks=[
 ['signature upload endpoint exists',server.includes("p==='/api/staff/signature'&&req.method==='POST'"),],
 ['signature uses secure image validation/storage',server.includes('safeImageToDir(x.signature_data,STAFF_PROOF_UPLOAD_DIR)'),],
 ['signature audit event exists',server.includes("action:'STAFF_SIGNATURE_UPLOADED'"),],
 ['delivery stores signature reference',server.includes('d.signature_reference=signature||null'),],
 ['signature reference length validation',server.includes('signature.length>200'),],
 ['signature canvas UI exists',staff.includes('id="sigCanvas"')&&staff.includes('toDataURL(\'image/png\')'),],
 ['touch/pointer signature drawing exists',staff.includes("pointerdown")&&staff.includes("pointermove")&&staff.includes("touch-action:none"),],
 ['delivery action sends signature reference',staff.includes('body.signature_reference=signature'),],
 ['delivery OTP is not implemented',!staff.includes('otp')&&!server.includes('delivery_otp')],
];
console.log(JSON.stringify({ok:checks.every(x=>x[1]),checks},null,2));
process.exit(checks.every(x=>x[1])?0:1);
