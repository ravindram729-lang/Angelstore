const fs=require('fs');
const src=fs.readFileSync('server.js','utf8');
const checks=[
 ['receipt before verified guard',src.includes('RECEIPT_BEFORE_PAYMENT_VERIFIED')],
 ['receipt before workflow completion guard',src.includes('RECEIPT_BEFORE_WORKFLOW_COMPLETION')],
 ['token orphan payment guard',src.includes('TOKEN_ORPHAN_PAYMENT')],
 ['token before verified payment guard',src.includes('TOKEN_BEFORE_PAYMENT_VERIFIED')],
 ['token/payment/application consistency guard',src.includes('TOKEN_PAYMENT_APPLICATION_MISMATCH')],
 ['UPPCL completed requires receipt',src.includes('UPPCL_COMPLETED_NO_RECEIPT')],
 ['recharge success requires verified payment',src.includes('RECHARGE_TERMINAL_PAYMENT_MISMATCH')],
 ['customer receipt endpoint requires eligibility',src.includes('findCompletedReceipt(id)')],
];
let failed=0;for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`);if(!ok)failed++;}
console.log(`STEP643 ${checks.length-failed}/${checks.length} PASS`);process.exitCode=failed?1:0;
