# STEP423 — Documents After Payment & Live Token Fix

- Documents are explicitly positioned after Payment Verification and Live Token in the Token Generate workflow.
- The pre-token sidebar no longer lists required documents; it only explains that documents unlock after verification/token.
- A Documents section appears only after a Live Token exists.
- Customer document upload is blocked until a Live Token exists.
- No backend/schema changes were made.

Workflow: Service → Application Details → Payment → Payment Verification → Live Token → Documents → Service Processing.
