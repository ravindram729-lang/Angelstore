const fs=require('fs');
const html=fs.readFileSync('admin.html','utf8');
const checks=[
 ['monitor status has live semantics', /id="monitorStatus"[^>]*role="status"[^>]*aria-live="polite"/],
 ['backup status has live semantics', /id="monitorBackup"[^>]*role="status"[^>]*aria-live="polite"/],
 ['alert webhook status has live semantics', /id="monitorAlert"[^>]*role="status"[^>]*aria-live="polite"/],
 ['retry metrics have accessible group', /id="retryObsCards"[^>]*role="group"[^>]*aria-label="Recharge retry summary metrics"/],
 ['status legend explains meanings', /id="retryStatusKey"[^>]*aria-label="Status meaning"/],
 ['status legend includes success', /class="ok"[^>]*>.*Success \/ OK/s],
 ['status legend includes warning', /class="check"[^>]*>.*Check \/ Warning/s],
 ['status legend includes critical', /class="critical"[^>]*>.*Error \/ Critical/s],
 ['green tag has non-color border', /\.tag\.green,#page-monitoring \.tag\.red\{border:1px solid currentColor\}/],
 ['high contrast media rule exists', /prefers-contrast: more/],
 ['forced colors rule exists', /forced-colors: active/],
 ['focus indicator remains explicit', /button:focus-visible[^}]*outline:3px solid/],
];
let pass=0; for(const [n,re] of checks){const ok=re.test(html); console.log(`${ok?'PASS':'FAIL'} | ${n}`); if(ok)pass++;}
console.log(`RESULT ${pass}/${checks.length} PASS`); if(pass!==checks.length)process.exit(1);
