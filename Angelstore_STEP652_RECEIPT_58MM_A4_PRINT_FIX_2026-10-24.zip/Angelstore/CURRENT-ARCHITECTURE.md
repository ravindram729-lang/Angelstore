# Angelstore — Current Architecture (STEP439)

## Authoritative layers

- **Service catalog / workflow:** `service-catalog.js` + persisted `service_configs` overrides.
- **Customer price calculation:** backend `payableAmountFor()` is authoritative; frontend values are display/input only.
- **Payment:** manual verification; customer payment records snapshot the payable amount and optional offer.
- **Token:** payment verification → appointment gate when configured → token generation.
- **Documents:** token required for upload; staff access is assignment-scoped; customer access is application/customer-scoped.
- **Queue:** today-scoped, service-scoped ordering with priority then creation ID.
- **OCR:** asynchronous in-process queue with persisted document status and restart recovery.
- **Persistence:** current production store remains the migration-safe JSON repository in `storage.js`; no risky DB migration was introduced in this step.

## Deliberately deferred architecture migrations

1. JSON → relational database migration.
2. OCR → dedicated durable worker/queue service.
3. Polling → SSE/WebSocket for live queue/payment updates.
4. Large `server.js` / `customer.js` / `app.js` modularization.

These are structural migrations, not safe small fixes. They should be isolated into separate migration steps with data-backup and regression plans.
