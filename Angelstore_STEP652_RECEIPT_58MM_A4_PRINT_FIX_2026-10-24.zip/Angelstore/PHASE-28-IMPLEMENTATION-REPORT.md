# Phase 28 — Off-site Backup + Scheduled Backup + Monitoring

## Audit-first result
Phase 27 was inspected before changes. Existing local backup/restore behavior was preserved.

## Changes
1. Managed backup path for manual and scheduled backups.
2. Optional off-site HTTPS POST target using `ANGELSTORE_OFFSITE_BACKUP_URL`.
3. Optional bearer authentication using `ANGELSTORE_OFFSITE_BACKUP_TOKEN`.
4. Off-site payload contains the database snapshot and payment-proof files with SHA-256 checksums.
5. Configurable scheduled backup: `ANGELSTORE_SCHEDULED_BACKUP=true` and `ANGELSTORE_BACKUP_INTERVAL_HOURS`.
6. Configurable local retention via `ANGELSTORE_BACKUP_RETENTION` (default 14).
7. Local old backup snapshots are pruned only after a managed backup succeeds.
8. Admin `/api/admin/backup-status` endpoint.
9. Admin Settings page now displays schedule, retention, off-site configuration and last backup.
10. Manual backup UI reports whether off-site upload succeeded.

## Verification
- `node --check server.js` PASS
- `node --check app.js` PASS
- Local backend health PASS (HTTP 200)
- Admin login PASS
- Manual managed backup PASS (HTTP 201)
- Off-site test receiver accepted backup PASS (HTTP 200)
- Off-site payload parsed and contained database snapshot PASS
- Backup status endpoint PASS
- No production provider credentials added

## Not verified
- Real Render production environment
- Real external storage provider durability
- Scheduled 24-hour wall-clock execution (not waited for in test environment)
- Alert delivery from a real monitoring service

## Off-site endpoint responsibility
The destination must durably store the received JSON, authenticate requests, validate SHA-256 checksums, and return 2xx only after successful durable storage.
