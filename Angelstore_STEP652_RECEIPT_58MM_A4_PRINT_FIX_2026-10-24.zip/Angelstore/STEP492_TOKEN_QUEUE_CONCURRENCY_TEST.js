const fs=require('fs');const assert=require('assert');const server=fs.readFileSync('server.js','utf8');const admin=fs.readFileSync('app.js','utf8');
function ok(n,f){try{f();console.log('PASS',n)}catch(e){console.error('FAIL',n,e.message);process.exitCode=1}}
ok('token state revision exposed',()=>assert(server.includes('state_revision:Number(t.state_revision||0)')));
ok('stale state rejected',()=>assert(server.includes('expected_state_revision')&&server.includes('Token state बदल चुका है')));
ok('duplicate request deduped',()=>assert(server.includes('last_action_request_id===tokenRequestId')));
ok('request id reuse blocked',()=>assert(server.includes('reused=db.tokens.find')));
ok('client sends request id',()=>assert(admin.includes('request_id:requestId')));
ok('client sends expected revision',()=>assert(admin.includes('expected_state_revision:Number(selected?.state_revision||0)')));
ok('client action lock',()=>assert(admin.includes('let tokenActionBusy=false')&&admin.includes('setTokenActionBusy(true)')&&admin.includes('finally{setTokenActionBusy(false)')));
ok('controls disabled during action',()=>assert(admin.includes('tokenActionBusy||!control')));
console.log('STEP492 targeted verification: PASS');
