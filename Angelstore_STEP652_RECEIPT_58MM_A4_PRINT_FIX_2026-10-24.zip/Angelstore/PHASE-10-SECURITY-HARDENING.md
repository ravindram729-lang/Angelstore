# Angelstore CSC — Phase 10 Security & Production Hardening

## Audit-first scope
Phase 9 was inspected before changes. Existing Node HTTP backend, JSON storage, admin/staff/customer sessions, payment proof controls, SOP/QC workflow, reports and role checks were preserved.

## Implemented
1. **Revocable admin sessions**
   - Admin login now creates a server-side `admin_sessions` record.
   - Bearer token carries a session id and is checked against active server-side session state.
   - Admin logout revokes the session.
   - Expired/revoked sessions are cleaned up.

2. **Staff login rate limiting**
   - Staff login attempts are limited per source IP.
   - Successful login clears the failed-attempt counter.

3. **Authenticated database backups**
   - Admin can create a timestamped JSON backup.
   - Admin can list and download backups.
   - Backup names are constrained to safe filenames.

4. **Safer restore workflow**
   - Restore is admin-only.
   - Backup is validated as JSON before restore.
   - A safety backup is automatically created immediately before restore.
   - Existing storage migration is reused so missing collections are recreated without changing business records unexpectedly.

5. **Admin UI**
   - Settings → Security now shows the real backend controls rather than misleading non-functional checkboxes.
   - Create / list / download / restore backup controls added.

6. **Logout integration**
   - Admin UI calls the server logout endpoint before clearing the browser token.

## Files changed
- `storage.js`
- `server.js`
- `app.js`
- `admin.html`

## Data compatibility
A new migration-safe `admin_sessions` collection was added. Existing records are preserved. No existing customer/payment/token/service data was intentionally deleted or rewritten.

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `node --check storage.js` — PASS
- Backend `/api/health` — PASS
- Admin login — PASS
- Authenticated settings request — PASS
- Backup creation/listing — PASS
- Admin logout — PASS
- Revoked admin token rejected with HTTP 401 — PASS

## Still requiring production deployment configuration
- Set a long random `ANGELSTORE_AUTH_SECRET` (32+ bytes recommended).
- Set strong `ANGELSTORE_ADMIN_USER` / `ANGELSTORE_ADMIN_PASS` environment variables.
- Set `ANGELSTORE_CORS_ORIGIN` to the exact trusted frontend origin instead of `*` for a public deployment.
- Use HTTPS/TLS at the public edge.
- Keep `data.json`, `uploads/`, and `backups/` outside public/static serving.
- Use a managed database/object storage and scheduled off-site backups for a multi-user production deployment.
