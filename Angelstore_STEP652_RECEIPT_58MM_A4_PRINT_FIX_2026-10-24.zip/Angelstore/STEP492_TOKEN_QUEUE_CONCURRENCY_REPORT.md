# STEP492 — Token Queue Concurrency & Stale Action Protection

## Scope
Harden Admin and Staff token actions against rapid double-clicks, stale queue state, duplicate/retried requests, and race-prone actions without changing the approved UI/design, cart-free workflow, or core token controls.

## Root causes addressed
1. Admin token controls could send overlapping requests from rapid clicks.
2. A previously loaded token state could become stale before an Admin action reached the server.
3. Retrying the same action request could repeat a mutation such as Recall.
4. Staff task actions did not carry a server-visible state revision, so stale Staff screens had no explicit optimistic-concurrency check.

## Fixes
- Added server-side `state_revision` to public/admin/customer/staff token projections.
- Token mutations increment `state_revision` and record an optional `request_id` in the audit trail.
- Repeated identical `request_id` for the same token returns the current token instead of applying the mutation twice.
- Reusing an action request ID on a different token is rejected.
- Admin non-`next` token actions send `expected_state_revision`; stale actions receive HTTP 409 and must refresh first.
- Admin Token Queue controls receive an in-flight action lock to block rapid double-click submissions.
- Staff task actions now send `request_id` + `expected_state_revision` and use the same server-side stale-state protection.
- Staff task response exposes `state_revision`.
- Existing transition/state/assignment/quality gates remain authoritative.

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `npm run step487` — PASS
- `npm run step488` — PASS
- `npm run step489` — PASS
- `npm run step490` — PASS
- `npm run step491` — PASS
- `npm run step492` — PASS
- `npm run p0-p1-regression` — PASS
- `npm run release-audit` — PASS
- STEP492 targeted concurrency/stale-state checks — PASS (8/8)

## Browser verification limitation
Fresh click-by-click Chromium visual verification is not claimed because the execution environment previously blocked normal localhost navigation. Static client logic plus isolated API/workflow regression tests were used.

## Production gate
This is a local code/workflow verification PASS. Production environment configuration and live hosted verification remain separate operational gates.
