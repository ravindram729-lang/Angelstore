'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=__dirname;
const service=fs.readFileSync(path.join(root,'partner-services.js'),'utf8');
const server=fs.readFileSync(path.join(root,'server.js'),'utf8');
const adminHtml=fs.readFileSync(path.join(root,'admin.html'),'utf8');
const customerHtml=fs.readFileSync(path.join(root,'customer.html'),'utf8');

// Customer nav is injected after customer.js has attached its initial click handlers.
// It must therefore have its own working delegated navigation handler.
assert.match(service,/const nav=e\.target\.closest\?\.\('\[data-page="customer-bank-account"\],\[data-page="customer-demat-account"\]'\);\s*if\(nav\)\{e\.preventDefault\(\);if\(typeof window\.go==='function'\)window\.go\(nav\.dataset\.page\);\}/,
  'Injected customer sidebar links must navigate to the dynamically-created pages');

// Links must be absolute HTTPS URLs with a hostname and no embedded credentials.
assert.match(server,/function validHttpsUrl\(value\).*u\.protocol==='https:'&&!!u\.hostname&&!u\.username&&!u\.password/s,
  'Backend must strictly validate referral URLs');
assert.match(server,/if\(link && !validHttpsUrl\(link\)\)/,
  'Partner CRUD must enforce referral URL validation');

// Safe local logo paths must not allow protocol-relative URLs or backslashes.
assert.match(server,/function validLogoValue\(value\).*raw\.startsWith\('\/'\)&&!raw\.startsWith\('\/\/'\)&&!raw\.includes\('\\\\'\)/s,
  'Backend must reject unsafe local logo paths');
assert.match(service,/const safeLogo=v=>.*raw\.startsWith\('\/'\)&&!raw\.startsWith\('\/\/'\)/s,
  'Frontend must render only safe HTTPS or local logo paths');

// Cache-bust fixed script so deployed clients don't keep using the stale handler.
assert.match(adminHtml,/partner-services\.js\?v=step645-partner-referral-fix1/);
assert.match(customerHtml,/partner-services\.js\?v=step645-partner-referral-fix1/);

console.log('STEP645 partner referral regression: PASS (5 assertions)');
