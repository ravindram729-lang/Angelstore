# AngelStore STEP433 — Stale Application / Payment Submission Fix

## Problem observed
Customer Payment submission could reuse `angelApplicationId` from browser localStorage without verifying that the application still existed on the current server/database. After a database reset, clean release, or test reset, the browser could retain an old application ID. The payment API then returned:

`इस service के लिए valid application नहीं मिला। पहले application create करें।`

## Fix
For logged-in customers, `customer.js` now validates the cached application through `/api/customer/application?id=...` before reusing it. If the application is missing or does not match the current customer/service, the client clears dependent payment/token state and creates a fresh application before submitting payment.

## Regression protection
- Stale `angelApplicationId` is no longer trusted blindly for logged-in customers.
- Stale `angelPaymentId` and `angelCurrentTokenId` are cleared when a fresh application is created.
- Existing payment → verification → token → documents workflow is unchanged.
- Token generation still does not require document verification.

## Verification
- `node --check customer.js` — PASS
- `node --check server.js` — PASS
- `FINAL-RELEASE-AUDIT.js` — PASS
- Production preflight remains environment-dependent and is expected to fail on a local non-production shell without real production environment variables.
