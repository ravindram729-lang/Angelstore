# STEP324 — Admin Panel Button & Service Fix

## Root cause found

`app.js` is shared by the public/customer/admin pages. It executed several unguarded DOM assignments such as `$('#browseServicesBtn').onclick = ...` and `$('#customerLoginTab').onclick = ...` even when those elements do not exist on `admin.html`.

The first missing element threw a JavaScript `TypeError` during script initialization. Because execution stopped there, the later Admin Login handler, navigation binding, token actions, payment actions and other handlers were never registered.

## Fixes

- Guarded optional public/customer event bindings in `app.js`.
- Added `window.angelApi` as the canonical backend API client.
- Updated Admin inline modules to use the canonical API client instead of relative `fetch('/api/...')` calls. This keeps Admin working on Netlify/static hosting with the configured Render backend.
- Kept payment verification, token workflow, database schema and business rules unchanged.
- Preserved mobile/menu/UI work from STEP323.

## Verification

- `node --check app.js` — PASS
- `node --check server.js` — PASS
- All inline admin scripts — PASS
- Local Admin login — PASS
- Full backend E2E — PASS
- Final integrity — PASS

Full E2E verified: admin login, service catalog/charges, customer registration/session, home service, application, tracking, payment submission, payment proof review, payment verification, token generation/tracking/history, staff assignment/call/start/SOP/quality/complete, customer dashboard, reports, control center, finance, logout/session revocation.
