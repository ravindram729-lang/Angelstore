const fs=require('fs'),path=require('path'),http=require('http'),child=require('child_process');
const ROOT=__dirname,TMP=path.join(ROOT,'.step466-global-payment-e2e');fs.rmSync(TMP,{recursive:true,force:true});fs.mkdirSync(TMP,{recursive:true});
fs.writeFileSync(path.join(TMP,'data.json'),'{}');
const env={...process.env,PORT:'8036',ANGELSTORE_STORAGE_DIR:TMP,ANGELSTORE_AUTH_SECRET:'step466-global-payment-secret-12345678901234567890',ANGELSTORE_ADMIN_USER:'testadmin',ANGELSTORE_ADMIN_PASS:'TestAdmin!12345'};
let proc=null,out='';
function start(){proc=child.spawn(process.execPath,[path.join(ROOT,'server.js')],{cwd:ROOT,env,stdio:['ignore','pipe','pipe']});proc.stdout.on('data',d=>out+=d);proc.stderr.on('data',d=>out+=d)}
function stop(){if(proc){proc.kill('SIGTERM');proc=null}}
const BASE='http://127.0.0.1:8036';
function req(method,p,body,headers={}){return new Promise((resolve,reject)=>{const u=new URL(p,BASE),b=body===undefined?null:Buffer.from(JSON.stringify(body));const r=http.request({method,hostname:u.hostname,port:u.port,path:u.pathname+u.search,headers:{...(b?{'Content-Type':'application/json','Content-Length':b.length}:{}),...headers}},res=>{let s='';res.on('data',c=>s+=c);res.on('end',()=>{let data;try{data=s?JSON.parse(s):null}catch{data=s}resolve({status:res.statusCode,data,headers:res.headers})})});r.on('error',reject);if(b)r.write(b);r.end()})}
function sessionHeaders(resp,requiredCookie){const set=resp.headers?.['set-cookie']||[];const jar=set.map(v=>v.split(';')[0]).join('; ');const csrfMatch=jar.match(/(?:^|; )angel_csrf=([^;]+)/);if(!jar.includes(requiredCookie+'='))throw Error('missing '+requiredCookie+' cookie');if(!csrfMatch)throw Error('missing CSRF cookie');return {Cookie:jar,'X-CSRF-Token':decodeURIComponent(csrfMatch[1])}}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{try{
 start();for(let i=0;i<40;i++){try{if((await req('GET','/api/health')).status===200)break}catch{}await sleep(100)}
 let r=await req('POST','/api/auth/login',{username:'testadmin',password:'TestAdmin!12345'});if(r.status!==200)throw Error('admin login');const A=sessionHeaders(r,'angel_admin');
 r=await req('POST','/api/customer/register',{name:'Global Payment Customer',mobile:'9000066666',pin:'2468'});if(r.status!==201)throw Error('register');const C=sessionHeaders(r,'angel_customer');
 // Create an application eligible for a manual payment.
 r=await req('POST','/api/applications',{name:'Global Payment Customer',mobile:'9000066666',service:'पैन सेवाएँ — New PAN application',category:'पैन सेवाएँ'},A);if(r.status!==200)throw Error('application create '+JSON.stringify(r.data));
 const app=r.data;
 const payment={name:'Global Payment Customer',mobile:'9000066666',service:'पैन सेवाएँ — New PAN application',amount:157,method:'Cash',utr:'GLOBAL-UTR-001',application_id:app.id,idempotency_key:'global-manual-key-001'};
 const first=await req('POST','/api/payments',payment,A);if(first.status!==200)throw Error('manual payment first '+JSON.stringify(first.data));
 const second=await req('POST','/api/payments',payment,A);if(second.status!==200||Number(second.data.id)!==Number(first.data.id))throw Error('manual payment retry not idempotent '+JSON.stringify(second.data));
 const conflict=await req('POST','/api/payments',{...payment,amount:51},A);if(conflict.status!==409)throw Error('manual payment key collision accepted');
 // Recharge customer payment: same idempotency key returns same payment/recharge pair.
 const recharge={mobile:'9000066666',operator:'JIO',type:'PREPAID',circle:'UP',plan:{id:'JIO-199',name:'₹199 Plan'},amount:199,utr:'RECHARGE-UTR-001',screenshot:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',idempotency_key:'recharge-key-001'};
 const rf=await req('POST','/api/customer/recharge/payment',recharge,C);if(rf.status!==200)throw Error('recharge first '+JSON.stringify(rf.data));
 const rr=await req('POST','/api/customer/recharge/payment',recharge,C);if(rr.status!==200||Number(rr.data.payment.id)!==Number(rf.data.payment.id)||Number(rr.data.recharge.id)!==Number(rf.data.recharge.id))throw Error('recharge retry not idempotent');
 const rc=await req('POST','/api/customer/recharge/payment',{...recharge,amount:200},C);if(rc.status!==409)throw Error('recharge key collision accepted');
 // Recharge state machine: Pending -> Success only after payment verification; terminal states cannot reverse.
 const rid=rf.data.recharge.id,pid=rf.data.payment.id;
 let sr=await req('POST',`/api/recharge/manual/${rid}`,{status:'Success'},A);if(sr.status!==409)throw Error('unverified recharge marked success');
 sr=await req('GET',`/api/payments/proof/${pid}`,undefined,A);if(sr.status!==200)throw Error('proof view '+JSON.stringify(sr.data));
 sr=await req('POST','/api/payments/status',{id:pid,status:'Verified'},A);if(sr.status!==200)throw Error('payment verify '+JSON.stringify(sr.data));
 sr=await req('POST',`/api/recharge/manual/${rid}`,{status:'Success',provider_ref:'PROVIDER-001'},A);if(sr.status!==200)throw Error('verified recharge success '+JSON.stringify(sr.data));
 sr=await req('POST',`/api/recharge/manual/${rid}`,{status:'Failed'},A);if(sr.status!==409)throw Error('success->failed allowed');
 // Separate pending recharge -> Failed -> Success must remain terminal at Failed.
 const r2body={...recharge,utr:'RECHARGE-UTR-002',screenshot:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGNgYGAAAAAEAAH2FzhVAAAAAElFTkSuQmCC',idempotency_key:'recharge-key-002'};const r2=await req('POST','/api/customer/recharge/payment',r2body,C);if(r2.status!==200)throw Error('second recharge '+JSON.stringify(r2.data));
 sr=await req('POST',`/api/recharge/manual/${r2.data.recharge.id}`,{status:'Failed',notes:'provider unavailable'},A);if(sr.status!==200)throw Error('pending->failed '+JSON.stringify(sr.data));
 sr=await req('POST',`/api/recharge/manual/${r2.data.recharge.id}`,{status:'Success'},A);if(sr.status!==409)throw Error('failed->success allowed');
 const raw=JSON.parse(fs.readFileSync(path.join(TMP,'data.json'),'utf8'));if(raw.payment_idempotency.length<3)throw Error('idempotency records missing');
 console.log(JSON.stringify({ok:true,checks:{manual_payment_same_key_returns_same_payment:true,manual_payment_payload_conflict_blocked:true,recharge_same_key_returns_same_pair:true,recharge_payload_conflict_blocked:true,recharge_requires_verified_payment_for_success:true,recharge_success_terminal:true,recharge_failed_terminal:true,idempotency_records_persisted:true}},null,2));
}catch(e){console.error(JSON.stringify({ok:false,error:e.message,server_output:out},null,2));process.exitCode=1}finally{stop();setTimeout(()=>{try{fs.rmSync(TMP,{recursive:true,force:true})}catch{}},250)}})();
