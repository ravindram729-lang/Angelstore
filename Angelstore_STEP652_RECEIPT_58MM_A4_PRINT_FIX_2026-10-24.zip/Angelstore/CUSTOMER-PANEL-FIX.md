# Customer Panel Fix

## Root cause found
`customer.html` had duplicate JavaScript declarations:
- `SAVED_BACKEND` was declared twice.
- `backendUrl` was declared as both `let` and `const`.

Because of this, the browser stopped parsing the entire customer script with a JavaScript `SyntaxError`. The customer panel could therefore appear blank, partially initialized, or behave as if backend features were broken.

## Fixed
- Removed duplicate `SAVED_BACKEND` declaration.
- Kept a single `backendUrl` selection with local-server preference.
- Removed duplicate `const backendUrl` declaration.
- Re-ran JavaScript syntax check successfully.
- Re-ran backend syntax check successfully.
- Verified `GET /api/health` and `GET /customer.html` from the local server.

## Payment flow retained
UPI App + QR, UTR, screenshot upload, admin verification, and verified-payment-only token generation remain enabled.
