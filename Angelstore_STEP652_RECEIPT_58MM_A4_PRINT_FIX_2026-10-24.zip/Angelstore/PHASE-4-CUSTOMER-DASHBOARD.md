# Angelstore CSC — Phase 4 Customer Dashboard

## Implemented
- Authenticated customer dashboard now reads customer data from `/api/customer/dashboard`.
- Customer identity is shown by Customer ID, name and mobile.
- Token history, payments, verified receipts, applications and appointments are scoped to the authenticated customer session.
- Removed mobile-number lookup as the authorization mechanism from the customer dashboard UI.
- Added authenticated appointment GET/POST API.
- Added dashboard summary counts.
- Added session-based refresh and customer account refresh.

## Security
- Customer data access requires the signed `X-Customer-Session` session.
- The server filters records by the authenticated customer's mobile/customer ID.
- Customer dashboard does not accept an arbitrary mobile number to retrieve another customer's records.

## Not yet implemented
- Staff dashboard, home-service workflow, delivery workflow, commission/settlement engine, and multi-CSC operator network remain later phases.
