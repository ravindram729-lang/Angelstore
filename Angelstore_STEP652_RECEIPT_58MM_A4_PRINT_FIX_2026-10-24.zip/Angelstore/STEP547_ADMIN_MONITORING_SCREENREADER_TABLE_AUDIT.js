const fs=require('fs');
const a=fs.readFileSync('admin.html','utf8');
const j=fs.readFileSync('app.js','utf8');
const tests=[
 ['incident table has accessible name',/table aria-label="Production monitoring incident history"/.test(a)],
 ['incident table has caption',/<caption class="sr-only">Last 100 production monitoring incidents/.test(a)],
 ['incident headers use scope col',(a.match(/<th scope="col">/g)||[]).length===6],
 ['incident body has live semantics',/<tbody id="incidentRows" aria-live="polite" aria-atomic="false">/.test(a)],
 ['retry metrics group is labelled',/id="retryObsCards" role="group" aria-label="Recharge retry summary metrics"/.test(a)],
 ['resolve action is explicit button',/button type="button" class="primary resolve-incident"/.test(j)],
 ['resolve action has accessible label',/aria-label="Resolve incident/.test(j)],
 ['closed incident exposes no-action text',/<span class="muted">No action<\/span>/.test(j)],
 ['opened timestamp uses time element',/<time datetime=/.test(j)],
 ['screen reader hidden caption CSS exists',/\.sr-only\{[^}]*position:absolute!important/.test(fs.readFileSync('style.css','utf8'))]
];
let pass=0; for(const [n,ok] of tests){console.log(`${ok?'PASS':'FAIL'} ${n}`); if(ok)pass++;}
console.log(`RESULT ${pass}/${tests.length} PASS`);
if(pass!==tests.length)process.exit(1);
