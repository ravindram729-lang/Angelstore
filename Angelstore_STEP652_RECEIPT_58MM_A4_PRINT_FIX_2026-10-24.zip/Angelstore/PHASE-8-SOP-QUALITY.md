# Angelstore CSC — Phase 8: SOP + Quality Control

## Implemented
- Service SOP retrieval for all catalog services.
- Admin can maintain required documents, process steps, notes and custom required checklist items.
- Staff can open Final Review for an assigned token.
- Required checklist items must be passed before a staff token can be completed.
- Quality review records are stored per token in `service_quality`.
- Quality actions are written to the audit log.
- Existing services, payments, tokens and finance data are preserved.

## API
- GET /api/sops
- GET /api/sops?service=Category%20%E2%80%94%20Sub-service
- POST /api/sops (admin)
- GET /api/service-quality?token_id=...
- POST /api/service-quality

## Completion rule
Staff `complete` is rejected unless a quality review exists with status `passed`.

## Default checklist
1. Customer identity/details verified
2. All required documents received and readable
3. Entered data cross-checked with documents
4. Applicable fee/charges confirmed
5. Submission/acknowledgement/reference captured

## Verification
- Node syntax checks passed for server.js, storage.js and app.js.
- Backend health endpoint passed.
- Admin SOP list endpoint returned catalog SOPs successfully.
