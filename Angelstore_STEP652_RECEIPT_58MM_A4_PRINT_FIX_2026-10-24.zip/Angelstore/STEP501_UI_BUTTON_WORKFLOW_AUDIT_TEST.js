const fs=require('fs');
const cp=require('child_process');
const files=['customer.html','admin.html','staff.html','customer.js','app.js','server.js'];
for(const f of files) if(!fs.existsSync(f)) throw new Error(`Missing ${f}`);
const htmls=['customer.html','admin.html','staff.html'].map(f=>fs.readFileSync(f,'utf8'));
const jsCustomer=fs.readFileSync('customer.js','utf8'), jsApp=fs.readFileSync('app.js','utf8');
function ids(html){return [...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m=>m[1]).filter(x=>!x.includes('${'))}
function buttons(html){return [...html.matchAll(/<button\b([^>]*)>/gi)].map(m=>{const id=m[1].match(/\bid=["']([^"']+)["']/i)?.[1]; return {id,raw:m[1]}}).filter(x=>x.id&&!x.id.includes('${'))}
function forms(html){return [...html.matchAll(/<form\b([^>]*)>/gi)].map(m=>m[1].match(/\bid=["']([^"']+)["']/i)?.[1]).filter(Boolean)}
function refs(id,js,html){return new RegExp(`(?:getElementById\\(["']${id}["']\\)|querySelector\\(["']#${id}["']\\)|querySelectorAll\\(["']#${id}["']\\)|["']#${id}["']|["']${id}["'])`).test(js)||new RegExp(`(?:onclick|onsubmit|onchange|oninput|onchange|onkeyup|onkeydown)\\s*=.*${id}`).test(html)}
function uniq(a){return [...new Set(a)]}
const [customer,admin,staff]=htmls;
const all=[['customer',customer,jsCustomer+customer],['admin',admin,jsApp+admin],['staff',staff,jsApp+staff]];
let n=0,pass=0; function check(name,ok,detail){n++; if(ok){pass++;console.log(`PASS ${n} ${name}${detail?' — '+detail:''}`)}else{console.error(`FAIL ${n} ${name}${detail?' — '+detail:''}`);process.exitCode=1}}
for(const [name,h,js] of all){
 const dup=uniq(ids(h).filter(x=>!x.includes('service-control-nav-label')).filter((x,i,a)=>a.indexOf(x)!==i));
 check(`${name} duplicate static IDs`,dup.length===0,dup.join(', ')||'none');
 const b=buttons(h); const miss=b.filter(x=>!refs(x.id,js,h));
 check(`${name} button handler/reference audit`,miss.length===0,miss.map(x=>x.id).join(', ')||`${b.length} button IDs checked`);
 const f=forms(h); const fm=f.filter(x=>!refs(x,js,h));
 check(`${name} form handler/reference audit`,fm.length===0,fm.join(', ')||`${f.length} forms checked`);
}
check('JavaScript syntax — customer.js',cp.spawnSync(process.execPath,['--check','customer.js']).status===0);
check('JavaScript syntax — app.js',cp.spawnSync(process.execPath,['--check','app.js']).status===0);
check('JavaScript syntax — server.js',cp.spawnSync(process.execPath,['--check','server.js']).status===0);
const customerRequired=['uppclConsumerForm','uppclFetchBill','uppclBillCard','uppclManualPaymentBox','uppclProofForm','uppclSubmitPayment','customerPaymentForm','generateToken','refreshMyToken','goLive'];
check('Customer critical workflow controls present',customerRequired.every(x=>customer.includes(`id="${x}"`)||customer.includes(`id='${x}'`)),customerRequired.join(', '));
const adminRequired=['nextCounter','recall','startWork','hold','extendHold','skip','cancelToken','complete','assignToken','priorityToken','transferToken','notifyToken'];
check('Admin token controls present',adminRequired.every(x=>admin.includes(`id="${x}"`)||admin.includes(`id='${x}'`)),adminRequired.join(', '));
const staffRequired=['refreshBtn','refreshRecharge','saveStaffRecharge','closeDocs','saveReview','cancelReview'];
check('Staff workflow controls present',staffRequired.every(x=>staff.includes(`id="${x}"`)||staff.includes(`id='${x}'`)),staffRequired.join(', '));
check('STEP500 regression',cp.spawnSync(process.execPath,['STEP500_TOKEN_QUEUE_END_TO_END_FINAL_AUDIT_TEST.js'],{encoding:'utf8'}).status===0);
console.log(`STEP501 UI BUTTON + WORKFLOW AUDIT: ${pass}/${n} PASS`);
process.exit(pass===n?0:1);
