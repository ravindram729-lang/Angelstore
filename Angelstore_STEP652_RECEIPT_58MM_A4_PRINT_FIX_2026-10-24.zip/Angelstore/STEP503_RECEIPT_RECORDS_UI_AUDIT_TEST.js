const fs=require('fs');
const path=require('path');
const root=__dirname;
const html=fs.readFileSync(path.join(root,'customer.html'),'utf8');
const js=fs.readFileSync(path.join(root,'customer.js'),'utf8');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const checks=[];
function pass(name,ok){checks.push([name,!!ok]);console.log(`${ok?'PASS':'FAIL'} ${checks.length}/10 ${name}`);if(!ok)process.exitCode=1;}
pass('reference receipt page shell exists',html.includes('customer-receipts-page')&&html.includes('रसीद और रिकॉर्ड'));
pass('account/stat cards exist',html.includes('recordsCustomerName')&&html.includes('recordsTotalTokens')&&html.includes('recordsVerifiedPayments')&&html.includes('recordsReceiptCount')&&html.includes('recordsCompletedServices'));
pass('filter controls exist',html.includes('recordsTokenFilter')&&html.includes('recordsMobileFilter')&&html.includes('recordsServiceFilter')&&html.includes('recordsDateFrom')&&html.includes('recordsDateTo')&&html.includes('recordsStatusFilter'));
pass('records table preserves required runtime IDs',html.includes('id="recordsTable"')&&html.includes('id="receiptList"')&&html.includes('id="refreshRecords"'));
pass('recent token timeline exists',html.includes('receiptHistoryTimeline')&&html.includes('recordsViewAllHistory'));
pass('receipt PDF action remains wired',js.includes('receipt-pdf')&&js.includes('downloadReceiptPdf'));
pass('client-side record filtering implemented',js.includes('applyFilters')&&js.includes('recordsStatusFilter'));
pass('customer data remains session-scoped',js.includes("/api/customer/records")&&js.includes('hasCustomerLogin()'));
pass('responsive receipt layout CSS exists',html.includes('@media(max-width:1100px)')&&html.includes('@media(max-width:720px)')&&html.includes('cr-main-grid'));
pass('package baseline and ETA regression script remain available',pkg.scripts?.step502==='node STEP502_CUSTOMER_SERVICE_ETA_TEST.js');
console.log(`STEP503 RECEIPT & RECORDS UI AUDIT: ${checks.filter(x=>x[1]).length}/${checks.length} PASS`);
