const fs=require('fs'),path=require('path'),os=require('os'),child=require('child_process'),http=require('http'),assert=require('assert');
const root=__dirname,tmp=fs.mkdtempSync(path.join(os.tmpdir(),'angelstore-step638-')),port=18838;
for(const d of ['uploads/payments','uploads/documents','backups'])fs.mkdirSync(path.join(tmp,d),{recursive:true});
fs.writeFileSync(path.join(tmp,'data.json'),'{}');
const env={...process.env,PORT:String(port),HOST:'127.0.0.1',NODE_ENV:'development',ANGELSTORE_STORAGE_DIR:tmp,ANGELSTORE_AUTH_SECRET:'step638-auth-secret-abcdefghijklmnopqrstuvwxyz-1234567890',ANGELSTORE_ADMIN_USER:'step638admin',ANGELSTORE_ADMIN_PASS:'Step638-Strong-Password-2026!'};
const proc=child.spawn(process.execPath,['server.js'],{cwd:root,env,stdio:['ignore','pipe','pipe']});
function req(method,p,headers={},body){return new Promise((resolve,reject)=>{const r=http.request({hostname:'127.0.0.1',port,path:p,method,headers:{'Content-Type':'application/json',...headers}},res=>{let b='';res.on('data',x=>b+=x);res.on('end',()=>{let data={};try{data=JSON.parse(b)}catch{data={raw:b}};resolve({status:res.statusCode,data,headers:res.headers})})});r.on('error',reject);if(body)r.write(JSON.stringify(body));r.end()})}
function cookieState(res){const cookies=res.headers['set-cookie']||[];const pairs=cookies.map(x=>String(x).split(';')[0]);const cookie=pairs.join('; ');const csrf=(pairs.find(x=>x.startsWith('angel_csrf='))||'').slice('angel_csrf='.length);return {cookie,csrf:decodeURIComponent(csrf)}}
function customerHeaders(state){return {'Cookie':state.cookie,'X-CSRF-Token':state.csrf}}
(async()=>{try{
  let ready=false;for(let i=0;i<100;i++){try{const r=await req('GET','/api/health');if(r.status===200){ready=true;break}}catch{}await new Promise(r=>setTimeout(r,50))}assert(ready,'server health');
  let r=await req('POST','/api/auth/login',{}, {username:'step638admin',password:'Step638-Strong-Password-2026!'});assert.equal(r.status,200);const adminState=cookieState(r);const admin={'Cookie':adminState.cookie,'X-CSRF-Token':adminState.csrf};
  const mobile='98'+String(Date.now()).slice(-8);r=await req('POST','/api/customer/register',{}, {name:'STEP638 Customer',mobile,pin:'2468'});assert.equal(r.status,201);const customer=cookieState(r);assert(customer.cookie.includes('angel_customer='),'customer cookie missing');assert(customer.csrf,'customer csrf missing');
  const service='आधार सेवाएँ — Aadhaar Address Update';r=await req('POST','/api/customer/application',customerHeaders(customer),{name:'STEP638 Customer',mobile,service,category:'आधार सेवाएँ'});if(r.status!==200) throw new Error('application '+r.status+' '+JSON.stringify(r.data)+' '+JSON.stringify(customer));const applicationId=r.data.id;
  r=await req('POST','/api/payments',admin,{name:'STEP638 Customer',mobile,service,amount:75,method:'UPI',utr:'S638'+Date.now(),application_id:applicationId});assert([200,201].includes(r.status));const paymentId=r.data.id;
  r=await req('POST','/api/payments/status',admin,{id:paymentId,status:'Verified'});assert.equal(r.status,200);
  r=await req('POST','/api/customer/tokens',customerHeaders(customer),{payment_id:paymentId,name:'STEP638 Customer',mobile,service});assert.equal(r.status,200);assert(r.data.token,'token not generated');const tokenId=r.data.id;
  r=await req('GET','/api/customer/tokens',customerHeaders(customer));assert.equal(r.status,200);assert(r.data.tokens.some(x=>Number(x.id)===Number(tokenId)),'customer token readback missing');
  const app=fs.readFileSync(path.join(root,'app.js'),'utf8'),cust=fs.readFileSync(path.join(root,'customer.js'),'utf8');
  assert(!app.includes("waiting*3"),'hard-coded 3-minute dashboard wait remains');assert(cust.includes('setInterval(tick,5000);'),'customer live sync is not 5 seconds');assert(cust.includes('let services=Object.keys(SERVICE_INFO||{});'),'customer service fallback is not catalog-driven');
  console.log(JSON.stringify({ok:true,checks:['dashboard wait uses token estimates','customer live sync 5s','customer service list derives from service catalog','cookie-auth customer token generation','customer token readback']},null,2));
}catch(e){console.error('STEP638 FAIL:',e.stack||e);process.exitCode=1}finally{proc.kill('SIGTERM');setTimeout(()=>{try{fs.rmSync(tmp,{recursive:true,force:true})}catch{}},250)}})();
