# STEP372 — Service Workflow Integration Fix

## Scope
Fixed the remaining architecture gaps identified in the STEP368 package without redesigning unrelated modules.

## Implemented
1. Customer identity consistency
   - Customer token-history GET no longer accepts a mobile-number lookup.
   - It now requires a valid customer session and scopes results to that session.
   - Guest application/payment flow remains available only for the initial application workflow; account/history areas require login.

2. Service-level workflow configuration
   - Added `service_configs` persistence collection.
   - Every catalog sub-service now exposes a `workflow` object with:
     - paymentRequired
     - manualVerification
     - tokenRequired
     - appointmentRequired
     - documentsRequired
     - qualityReview
     - receiptRequired
     - notifications
     - applicationTracking
     - staffAssignment
   - Added public `/api/service-configs` and admin `/api/admin/service-configs` APIs.
   - Admin UI now has a Service Workflow Configuration page.
   - Changes are written to Security & Audit as `SERVICE_WORKFLOW_CONFIG_CHANGED`.

3. Token applicability
   - Customer token generation is rejected server-side when `tokenRequired` is false.
   - Customer service detail cards show Token applicability per sub-service.
   - Generic category-level “Token Available” display was removed in favor of configuration-aware wording.
   - Customer token button is hidden when the selected service is not token-enabled.

4. Payment applicability
   - Customer payment submission is rejected when the selected service has `paymentRequired=false`.
   - New applications use `Application Submitted` instead of `Payment Pending` when payment is not required.

5. Receipt applicability
   - Automatic receipt generation now checks `receiptRequired` before creating a receipt.
   - Existing duplicate-receipt protection remains intact.

6. Application Tracking
   - Tracking steps are built from the service configuration.
   - Payment and document steps are omitted when not applicable.
   - Processing is omitted when application tracking is disabled.
   - Completed remains the final state.

7. Notification deduplication
   - Notifications now receive an event key and duplicate events are suppressed.
   - Quality-review rejection now creates a Correction Required notification.

## Verification
- `npm run check` — PASS
- Backend health on isolated runtime — HTTP 200
- Public `/api/service-configs` — HTTP 200
- Fresh package contains 116 catalog service configurations through defaults
- Unauthenticated `/api/customer/tokens` — HTTP 401
- Admin `/api/admin/service-configs` — HTTP 200 after login
- Admin workflow update — PASS
- Updated configuration is returned by `/api/services` — PASS

## Important
No automatic bank/payment verification was introduced. Manual payment verification remains the rule.
