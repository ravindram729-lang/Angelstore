# STEP459 — UPPCL Customer Lookup & Payment UX Hardening

## Scope
Hardened the UPPCL customer bill lookup and payment-proof interaction without changing the backend payment workflow.

## Fixes
- Fixed a latent lookup-lock bug: invalid account/mobile validation could return after setting `uppclLookupInFlight`, permanently blocking later lookups.
- Lookup guard is now acquired only after input validation and is always released by `finally` after the API attempt.
- Added `aria-busy` state to the UPPCL consumer form and bill lookup status during server lookup.
- Added `aria-invalid` feedback for invalid account/mobile input and clear it when the user edits the field.
- Added payment-proof `aria-busy` state during screenshot encoding/API submission.
- Added `aria-invalid` feedback for invalid/missing UTR and screenshot input.
- Kept the existing single-submit and in-flight duplicate protection.
- No backend endpoint or payment amount authority was changed.

## Verification
- `node --check customer.js` — PASS
- `npm run check` — PASS
- `node STEP456_UPPCL_SECURITY_E2E.js` — PASS
- `node P0-P1-REGRESSION-TEST.js` — PASS
- `npm run release-audit` — PASS
- Dedicated STEP459 static UX/handler audit — PASS
- ZIP integrity — PASS

## Browser limitation
A fresh live Chromium visual verification was not claimed because this environment previously blocked/hung localhost browser access. Static DOM/handler verification and the existing backend/security regression suite were used instead.
