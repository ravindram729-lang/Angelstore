const fs=require('fs');
function ok(name,v){if(!v)throw new Error('FAIL: '+name);console.log('PASS: '+name)}
const app=fs.readFileSync('app.js','utf8');
const staff=fs.readFileSync('staff.html','utf8');
const server=fs.readFileSync('server.js','utf8');
ok('Admin token action has 409 conflict refresh handling',/Number\(e\.status\)===409/.test(app)&&/Queue refresh कर दी गई है/.test(app));
ok('Admin token action still has busy guard',/if\(tokenActionBusy\)return/.test(app)&&/setTokenActionBusy\(true\)/.test(app));
ok('Staff API preserves HTTP status on errors',/e\.status=r\.status/.test(staff));
ok('Staff task conflict refreshes task list',/Number\(e\.status\)===409/.test(staff)&&/await load\(\)\.catch/.test(staff));
ok('Server exposes state revision conflict gate',/expected_state_revision/.test(server)&&/return json\(res,409/.test(server));
ok('Server supports request-id idempotency for token actions',/last_action_request_id/.test(server)&&/request_id/.test(server));
ok('No new UI button introduced by STEP493',!/<button[^>]+id=["']step493/i.test(app+staff));
console.log('STEP493 TARGETED UI/CONFLICT TEST: PASS (7/7)');
