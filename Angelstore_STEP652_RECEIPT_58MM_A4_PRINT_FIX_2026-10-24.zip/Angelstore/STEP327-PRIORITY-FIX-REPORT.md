# STEP327 Priority Fix Report

Date: 2026-09-24

## Completed

1. Replaced the unsafe numeric ID generator with a safe-integer, collision-checked generator while preserving numeric ID compatibility.
2. Added collision-safe business code generation for applications, staff IDs, home-service IDs and delivery IDs.
3. Made daily token generation check the actual token value before allocation instead of relying on array length.
4. Removed the static development AUTH_SECRET fallback; local development now gets an ephemeral random secret unless an environment secret is supplied.
5. Production CORS now requires exactly one explicit HTTPS origin.
6. Removed the admin app's legacy customer business-state localStorage rendering and local token fallback.
7. Removed the unused legacy `script2.js` and `admin_script1.js` through `admin_script5.js` files.
8. Added real admin-authenticated document upload API with type, size, count and total-size validation, SHA-256 integrity records and server-side storage.
9. Replaced the admin request-page fake document localStorage success path with real server upload.
10. Extended integrity checks to validate stored documents and checksums.
11. Extended managed backup/restore to include document files as well as payment proofs.
12. Fixed UUID filename validation. Previous regexes incorrectly expected 36 hexadecimal characters without UUID hyphens, which could reject valid payment proof files.
13. Removed the public-token localStorage fallback; backend is authoritative.

## Verification performed after fixes

- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `npm run check` — PASS
- `npm run release-audit` — PASS
- Production configuration boot/health test — PASS
- Explicit CORS behavior test — PASS
- Safe numeric ID uniqueness test — PASS
- Application-code uniqueness test — PASS
- Real document upload API test — PASS
- Document checksum/integrity test — PASS
- Backup manifest includes uploaded documents — PASS

## Remaining architectural work

These are intentionally not claimed as fixed in STEP327:

- JSON file storage still needs migration to a real transactional database.
- Multi-process/distributed transaction locking is still not equivalent to database transactions.
- Finance still needs a proper accounting ledger/reconciliation model.
- Customer-facing document upload/OCR workflow is not yet complete.
- Aadhaar/PAN/marksheet OCR and automatic form filling are still pending.
- Full production browser E2E testing requires the actual deployment environment and credentials.
- Scheduled/off-site backup and alert webhook still require production environment configuration.
- Large monolithic `server.js`, `app.js` and inline `customer.html` architecture still needs modularization.
- Service/pricing authority should ultimately be consolidated into a single database-backed source.
