# STEP418 — Admin + Staff Manual Recharge

## Scope
Added a controlled manual recharge workflow without removing the existing API adapter.

## Customer/API behavior preserved
- Existing `/api/recharge/plans` remains available for authorized provider plan loading.
- Existing `/api/recharge/initiate` remains provider/API based.
- No fake live provider success was added.

## Admin
- New Admin `Recharge` page.
- Admin can create manual recharge records.
- Operator: Jio / Airtel / Vi / BSNL.
- Prepaid / Postpaid.
- Circle.
- Plan/description and amount.
- Pending / Success / Failed status.
- Provider reference and notes.
- Recent manual recharge history.
- Status update buttons.
- API credentials are not exposed in the page.

## Staff
- Staff dashboard includes Manual Recharge section.
- Staff roles with `recharge_process` permission can create/update manual recharge records.
- Viewer role does not receive the permission.
- Staff cannot access provider/API credentials.

## Backend
- Added migration-safe `db.recharge_transactions` collection initialization.
- Added authenticated:
  - GET `/api/recharge/manual`
  - POST `/api/recharge/manual`
  - POST `/api/recharge/manual/:id`
- Admin authentication uses existing Bearer admin session.
- Staff authentication uses existing X-Staff-Session and role permission.
- Manual recharge create/update actions are audit logged.
- Mobile numbers are masked in history UI.

## Verification
- `node --check server.js` PASS
- `node --check app.js` PASS
- `node --check customer.js` PASS
- `/api/health` HTTP 200 PASS
- Unauthenticated manual recharge endpoint returns 401 PASS
- Admin login PASS
- Admin manual recharge create PASS
- Admin manual recharge list PASS
- Admin status update Pending -> Success PASS
- Provider reference update PASS
- Existing customer Recharge/UPPCL UI retained

## Important limitation
No real recharge provider credentials were available in this package. Therefore no claim of real operator recharge execution or live current-plan certification is made.
