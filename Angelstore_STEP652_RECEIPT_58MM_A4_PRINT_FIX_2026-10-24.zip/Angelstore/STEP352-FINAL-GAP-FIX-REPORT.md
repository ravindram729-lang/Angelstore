# AngelStore STEP352 — Final Gap Fix Report

Date: 25-09-2026

## Implemented

1. **Guest Customer privacy**
   - Guest can still see the live/current token.
   - Guest no longer sees the global "आज के कुल टोकन" count.
   - Guest account statistics show `—` instead of another customer's/global totals.
   - Logged-in customer statistics remain customer-specific.

2. **Receipt & Records**
   - Removed the duplicate **Live Queue Status** block from Receipt & Records.
   - Token/queue tracking remains available in the dedicated Live Token Status section.

3. **Payment proof rule**
   - Customer can submit:
     - UTR only, OR
     - Screenshot only, OR
     - UTR + Screenshot together.
   - At least one proof is mandatory.
   - Duplicate UTRs remain blocked.
   - Duplicate screenshots remain blocked.
   - If a screenshot exists, Admin must view it before verification.
   - UTR-only payments can be verified without a screenshot.
   - Admin manual UPI/Bank entry follows the same UTR-or-proof rule.

4. **SOP Check Pattern**
   - Added a working **Check Pattern** button.
   - It checks service selection, required documents, SOP steps, checklist labels, required items, and duplicate checklist labels.
   - It reports valid/invalid pattern before Save SOP.
   - Existing server-side Quality Review gate remains unchanged.

5. **Cache busting**
   - Customer/Admin JS query versions updated to STEP352.

## Validation

- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `node --check customer.js` — PASS
- Local `/api/health` endpoint — PASS (HTTP 200)
- Customer payment proof variants — PASS:
  - UTR only
  - Screenshot only
  - UTR + Screenshot
- Test data restored after payment-variant testing.

## Not claimed as verified

A real browser click-through of every Admin/Staff/SOP control still requires running the updated package in the browser. This report does not claim live-production certification.
