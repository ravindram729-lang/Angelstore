# STEP504 — Customer Token Generate Reference Replacement

## Scope
Replaced the Customer **Token Generate** page presentation with the supplied AngelStore CSC Token Portal reference design while preserving the existing customer token/payment workflow IDs and JavaScript handlers.

## UI changes
- Added supplied reference hero/banner asset.
- Added 7-step visual workflow: Service → Details → Payment → Verification → Live Token → Documents → Processing.
- Reworked customer information, service selection and payable amount cards.
- Reworked payment method area with UPI / QR / Bank Transfer / CSC Wallet choices.
- Reworked payment proof area with UTR and screenshot controls.
- Added reference-style post-token workflow card.
- Preserved Live Token generation/status controls.
- Preserved Documents-after-token gate.
- Added responsive tablet/mobile layouts.

## Compatibility
Existing runtime IDs were preserved, including:
`cName`, `cMobile`, `cService`, `cAmount`, `cPaymentMethod`, `selectedPaymentMethodLabel`, `cUpiId`, `upiPayButton`, `copyUpiButton`, `paymentQrImage`, `bankPaymentDetails`, `paymentAmountDisplay`, `cUtr`, `cPaymentScreenshot`, `paymentPreview`, `submitPayment`, `paymentStatus`, `generatedToken`, `generatedService`, `generatedStatus`, `generateToken`, `clearCustomer`, `refreshMyToken`, `goLive`, `tokenDocumentsAfterToken`, `openCustomerDocumentsAfterToken`.

## Verification
- STEP504 reference replacement: **10/10 PASS**
- STEP503 Receipt & Records regression: **10/10 PASS**
- STEP502 Customer ETA regression: **7/7 PASS**
- STEP500 Token Queue E2E regression: **10/10 PASS**
- `node --check server.js`: **PASS**
- `node --check app.js`: **PASS**
- `node --check customer.js`: **PASS**
- ZIP integrity: **verified after packaging**

## Note
Fresh browser click-by-click verification was not claimed. This release verifies the reference structure, preserved runtime hooks, responsive CSS, and regression tests. Production deployment remains a separate operational gate.
