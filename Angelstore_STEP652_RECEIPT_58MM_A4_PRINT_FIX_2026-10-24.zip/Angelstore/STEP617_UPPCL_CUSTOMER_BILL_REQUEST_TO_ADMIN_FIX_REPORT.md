# STEP617 — UPPCL Customer Bill Request → Admin Fix

## Problem
Customer could enter an Account Number and click **Bill देखें**, but if no Admin-approved bill existed the Admin panel only showed an empty bill history. The Admin therefore had no customer/account context to know whose bill needed to be entered.

## Root cause
The customer lookup failure was not persisted as a request. `db.uppcl_manual_bills` only contained Admin-created bills, so a missing bill produced no actionable Admin queue item.

## Fix
- Added `db.uppcl_bill_requests` storage.
- When an authenticated customer requests a missing UPPCL bill by Account Number, the lookup creates/updates a pending request containing:
  - Customer name
  - Customer mobile
  - Account Number
  - District
  - DISCOM
  - Request time / request count
- Added Admin endpoint `/api/admin/uppcl/bill-requests`.
- Added **Customer Bill Requests** section to UPPCL Control Panel.
- Admin can click **Update Bill**; customer name, mobile, account, district and DISCOM are prefilled in the Manual Bill form.
- When Admin saves the matching bill, the request becomes **Bill Updated** and stores bill ID/version.
- Existing payment/bill logic was not replaced.
- Existing customer-to-bill mobile ownership validation remains active.
- Updated the remaining Admin wording to use the Angelstore/Admin-approved process wording rather than an “Official channel” reference.

## Validation
- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- All inline `admin.html` scripts — PASS
- Source references for request create/list/update — PASS

## Expected flow
Customer → Bill देखें → no bill found → Customer request saved → Admin sees customer details → Update Bill → Customer Bill देखें again → Bill Details available.
