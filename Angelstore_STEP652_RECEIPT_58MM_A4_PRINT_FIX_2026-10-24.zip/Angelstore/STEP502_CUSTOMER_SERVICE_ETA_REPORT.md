# STEP502 — Customer Service Start & Completion ETA

## Objective
Add a per-customer time estimate so each customer can see:
- काम शुरू होने में कितना समय है
- लगभग काम कब पूरा होगा
- estimated start clock time
- estimated completion clock time
- live countdown on the Customer Status page

## Root cause / gap
The existing queue exposed `estimated_wait_minutes`, but it did not expose a separate customer-specific start ETA and completion ETA. A customer could see queue waiting time, but not a clear "काम कब शुरू होगा" and "लगभग कब पूरा होगा" view.

## Implementation
### Backend
- Extended `tokenQueueMeta()` with:
  - `start_wait_minutes`
  - `completion_wait_minutes`
  - `estimated_start_at`
  - `estimated_completion_at`
- Existing `estimated_wait_minutes` remains backward compatible and maps to start wait.
- Pending tokens account for:
  - customers ahead in the queue
  - currently active token remaining work
  - service average duration
- Active/processing/hold tokens calculate completion ETA from their own elapsed/hold time instead of resetting to the full average duration.
- Customer `/api/customer/tokens` exposes the new fields.
- Customer `/api/customer/live-queue` exposes the new fields.
- No token state is mutated by ETA calculation.

### Customer UI
Added a dedicated **SERVICE TIME ESTIMATE / आपके काम का समय** section:
- काम शुरू होने में
- लगभग काम पूरा होने में
- estimated start clock time
- estimated completion clock time
- LIVE countdown, refreshed every second from server-provided timestamps
- state-aware messaging for Waiting, Called, In Progress, Hold, Completed, Skip and Cancel

## Verification
- STEP502 ETA targeted test: **7/7 PASS**
- STEP501 UI/button workflow regression: **16/16 PASS**
- STEP500 full Token Queue E2E regression: **10/10 PASS**
- STEP499 load/stress regression: **7/7 PASS**
- `node --check server.js`: PASS
- `node --check app.js`: PASS
- `node --check customer.js`: PASS
- Package script `step502`: added
- Read-only ETA calculation persistence check: PASS

## Notes
ETA is an estimate, not a guaranteed appointment time. It can change when queue priority, staff availability, hold time, service duration, skip/cancel, or other live queue state changes.

Fresh live-browser visual verification was not claimed in this local automated audit.

## Verdict
**STEP502 — PASS**
