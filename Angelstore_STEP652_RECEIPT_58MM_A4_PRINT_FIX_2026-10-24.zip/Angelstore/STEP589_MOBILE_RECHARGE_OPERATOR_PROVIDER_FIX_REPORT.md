# STEP589 — Mobile Recharge Operator Detection & Provider Failure UX Fix

## Scope
- Mobile Recharge only.
- Based on STEP588.
- No UPPCL workflow changes.

## Changes
1. Added server endpoint: `GET /api/recharge/operator-detect?mobile=XXXXXXXXXX`.
2. Operator detection uses Admin-configured `ANGELSTORE_RECHARGE_OPERATOR_URL` and the existing server-side provider token.
3. Normalized provider operator values to Angelstore operators: JIO, AIRTEL, VI, BSNL.
4. Added `.env.example` entry for `ANGELSTORE_RECHARGE_OPERATOR_URL`.
5. Connected Customer `Auto Detect` button to the new endpoint, updates the selected operator, and reloads plans.
6. Recharge plans provider failures now return a controlled fallback response instead of an HTTP 502 for the customer UI.
7. Customer UI distinguishes provider-unavailable fallback from ordinary fallback catalogue.

## Verification
- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- `npm run check` — PASS
- Operator detection mock-provider test — PASS (Vodafone Idea → VI)
- Plans mock-provider test — PASS
- No-provider detection response — PASS
- No-provider plans response — PASS

## Provider configuration
Admin/provider configuration remains server-side. No provider credentials were added to frontend code.

## Status
PASS
