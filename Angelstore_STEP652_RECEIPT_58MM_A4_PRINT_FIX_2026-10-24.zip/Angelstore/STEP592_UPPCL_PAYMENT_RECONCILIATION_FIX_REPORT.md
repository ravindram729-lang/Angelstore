# STEP592 — UPPCL Payment Reconciliation Fix

## Fixes
- Verified UPPCL payments are now carried forward across bill versions for the same manual bill ID when the Admin updates the bill.
- Customer bill summary now calculates Verified Paid, Remaining and Advance using all verified payments linked to that bill ID, while pending payments remain scoped to the current bill version.
- Admin UPPCL payment queue now shows cumulative verified/completed totals across bill versions.
- UPPCL Completed gate now uses cumulative verified payment total across bill versions.
- Empty UTR is no longer treated as a duplicate UTR, so multiple screenshot-only payments can be submitted after prior payments are verified.
- Existing non-empty UTR duplicate protection remains active.

## Verification
- `node --check server.js` — PASS
- `node STEP585_UPPCL_FULL_CUSTOM_ADVANCE_E2E.js` — PASS
- Targeted bill-version + screenshot-only cumulative E2E — PASS (5/5)
- No existing customer/payment data modified.
