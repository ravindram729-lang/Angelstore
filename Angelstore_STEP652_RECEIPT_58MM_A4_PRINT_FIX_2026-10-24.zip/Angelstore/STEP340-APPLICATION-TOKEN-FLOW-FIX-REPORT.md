# STEP340 — Application → Payment → Token Flow Fix

## Problem verified
Customer payment submission could show `Valid application required है` even when the customer had selected a service and had a stale/missing `angelApplicationId` in browser localStorage.

## Root cause
- Customer UI reused `angelApplicationId` without validating that the saved application metadata matched the current customer + mobile + service.
- Backend payment endpoint required the exact application ID and rejected a missing/stale ID before resolving an existing valid application for the same authenticated customer/service.

## Fix
- Customer panel now stores application metadata alongside `angelApplicationId`.
- If the stored application metadata does not match the current customer/mobile/service, a fresh application is created before payment submission.
- Backend now safely resolves the latest non-token-generated application for the authenticated customer/mobile/service when an application ID is stale or missing.
- If an explicitly supplied application belongs to another customer/service, the request is rejected rather than silently reassigned.
- Existing guest-session application binding remains enforced.
- Payment → Admin verification → Live Token workflow remains intact.

## Verification
- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- End-to-end local API smoke test — PASS:
  - application creation — PASS
  - customer-scoped payment submission with UTR + screenshot — PASS
  - response: `Pending Verification`
- Test data was removed from the release package after verification.

## Files changed
- `customer.js`
- `server.js`
- `STEP340-APPLICATION-TOKEN-FLOW-FIX-REPORT.md`
