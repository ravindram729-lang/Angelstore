const fs=require('fs');
const server=fs.readFileSync('server.js','utf8');
const customer=fs.readFileSync('customer.js','utf8');
const admin=fs.readFileSync('admin.html','utf8');
const checks=[
 ['retry endpoint is customer protected',server.includes("if(p==='/api/customer/recharge/retry'&&req.method==='POST')")&&server.includes("Customer login required")],
 ['retry only accepts Failed source',server.includes("source.status!=='Failed'")],
 ['retry ownership is enforced',server.includes("इस recharge पर access नहीं है")],
 ['idempotency replay returns existing retry before child guard',server.includes('Idempotent replay must win before the linear-chain guard')],
 ['same idempotency payload returns HTTP 200',server.includes("return json(res,200,{ok:true,payment:customerPayment(ep),recharge:customerRecharge(er)")],
 ['same idempotency key conflict is blocked',server.includes('Same idempotency key अलग retry payload')],
 ['duplicate UTR blocked',server.includes('यह UTR पहले से दर्ज है')],
 ['duplicate proof hash blocked',server.includes('यह payment screenshot पहले से दर्ज है')],
 ['retry metadata forms a single chain',server.includes('retry_of_recharge_id:source.id')&&server.includes('retry_group_id:rootId')&&server.includes('attempt_no:attemptNo')],
 ['new retry starts Pending',server.includes("status:'Pending',source:'customer-recharge-retry'")],
 ['old failed attempt does not receive retry receipt',server.includes("receipt_no:null")],
 ['Success requires linked Verified payment',server.includes("linkedPayment&&linkedPayment.status==='Verified'")],
 ['fresh recharge receipt generated',server.includes("'RCP-RCH-'")],
 ['retry submission notification exists',server.includes("'Recharge Retry Submitted'")],
 ['retry completion notification exists',server.includes("'Recharge Completed'")],
 ['receipt notification is idempotent',server.includes('receipt_generated_at_notified')],
 ['admin exposes attempt chain',server.includes('attempt_chain:chain.map')&&admin.includes('recharge-attempt-chain')],
 ['customer exposes Retry only for Failed',customer.includes("failed?`<button type=\"button\" class=\"receipt-action recharge-retry\"")],
 ['customer Details action remains available',customer.includes('recharge-detail')],
 ['no cart/order dependency',!/(cart|order)/i.test(server.match(/\/api\/customer\/recharge\/retry[\s\S]{0,18000}/)?.[0]||'')]
];
let pass=0;for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} | ${n}`);if(ok)pass++}
console.log(`STEP534 FINAL LIFECYCLE AUDIT: ${pass}/${checks.length} PASS`);
process.exit(pass===checks.length?0:1);
