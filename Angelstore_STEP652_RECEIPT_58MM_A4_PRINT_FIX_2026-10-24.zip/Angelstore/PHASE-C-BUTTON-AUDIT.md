# Phase C — UI Button & Link Audit

Base: Angelstore CSC Phase 20 Guest Customer / Optional Login.

## Scope

Checked Customer, Admin and Staff HTML controls against JavaScript handlers and backend routes. No production data was used for functional smoke tests; backend tests ran on an isolated copy.

## Fixed

### Customer
- Customer Account → Refresh: now refreshes authenticated account data; guests are sent to Customer Login.
- Token History → Refresh: now loads authenticated customer records.
- Receipt & Records → Refresh: now loads authenticated records/receipts.
- My Applications → Refresh: now loads authenticated applications.
- Appointments → Refresh: now loads authenticated appointments.
- Customer record renderer was missing even though `refreshAll()` called it. Added `renderCustomerRecords()` so dashboard refresh no longer throws a ReferenceError after login.
- LIVE SCREEN → Details: now opens the relevant customer service/token area instead of being inert.

### Admin/Public
- Public Customer Login/Register buttons on admin.html now open `customer.html` instead of showing an obsolete “login removed” toast.
- Public Token Status now queries the backend queue first and uses local fallback only if the backend request fails.
- Static “related service” buttons on the detail page now navigate to service search/details instead of being inert.

## Verified Existing Controls

- Admin navigation uses `data-page` routing.
- Service filters and search have handlers.
- Request Next/Reset and file selection have handlers.
- Token issue/view and token control actions have handlers.
- Payment modal open/save/cancel/close has handlers.
- Reports, Control Center, Production Audit and backup controls have handlers.
- Staff create/refresh, assignment and activate/deactivate controls have handlers.
- Home/Delivery and Finance controls have handlers.
- Staff Start/Hold/Complete, Final Review, Home Service and Delivery actions have handlers.

## Tests

- `server.js` syntax: PASS
- `storage.js` syntax: PASS
- `app.js` syntax: PASS
- Customer inline script syntax: PASS
- Admin inline scripts syntax: PASS
- Staff inline script syntax: PASS
- Local routes `/`, `/index.html`, `/customer.html`, `/admin.html`, `/staff.html`: HTTP 200
- `/api/health`: HTTP 200
- Public `/api/customer/tokens`: HTTP 200
- Admin login on isolated test copy: HTTP 200
- Customer registration on isolated test copy: HTTP 201

## Remaining Design Notes

- Some filter buttons intentionally only change UI filters; they are not API actions.
- Receipt “Save” uses the browser print dialog (Save as PDF) rather than silently writing a file.
- Real external UPI app behavior depends on the user's device/browser and cannot be fully verified in a headless server test.
- Live hosting/CORS/persistent storage still require actual production deployment verification.
