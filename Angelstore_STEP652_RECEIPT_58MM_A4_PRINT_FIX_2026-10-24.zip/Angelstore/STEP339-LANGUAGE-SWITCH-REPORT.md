# STEP339 — Language Switch Mode

## Change
- Removed the always-visible bilingual presentation layer.
- Reworked `bilingual-ui.js` into a single-language UI switcher.
- Added persistent Hindi/English selection using `localStorage` key `angelstoreLanguage`.
- Added a clickable language button to Admin, Customer, Staff and public Home panels.
- Added exact-text translation for common labels, buttons, headings, placeholders, options and dynamically rendered UI text.
- Added MutationObserver support so newly rendered panels/modals are translated too.
- Added cache-busting query string to all page references.

## Behaviour
- Default language: Hindi (`hi`) when no preference exists.
- Click `English` → page switches to English.
- Click `हिंदी` → page switches back to Hindi.
- Selection persists across page refresh/navigation within the Angelstore site.

## Files changed
- `bilingual-ui.js`
- `style.css`
- `admin.html`
- `customer.html`
- `staff.html`
- `index.html`
- `STEP339-LANGUAGE-SWITCH-REPORT.md`

## Verification
- JavaScript syntax check: PASS (`node --check bilingual-ui.js`)
- Existing API/backend workflow: unchanged.
- Existing token/payment/workflow logic: unchanged.
- No bilingual `English / Hindi` rendering layer remains active.
