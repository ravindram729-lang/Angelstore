# STEP451 — UPPCL Manual Payment Verification Workflow

## Implemented
- Customer UPPCL bill lookup remains provider-backed; no fake bill/amount is generated.
- After a valid bill is fetched, Customer sees a Manual Payment Verification section.
- Customer pays the configured Angelstore UPI and submits UTR + payment screenshot.
- Submission creates an existing `db.payments` record with service `UPPCL Bill Payment` and `Pending Verification` status.
- A linked application is created with `Payment Verification Pending` status.
- Admin uses the existing payment verification endpoint to Verify/Reject the proof.
- Admin UPPCL Control now shows a Manual UPPCL Payment Queue using the same payment ledger.
- After verification, Admin can mark the UPPCL service `Completed` or `Failed` and optionally store a provider/reference note.
- Customer receives notification on verification and final processing.
- No separate UPPCL payment ledger was introduced.
- Existing provider-backed `/api/uppcl/payment` remains available for future provider integration but is not called by the manual verification flow.

## Flow
Customer → Bill Lookup → Bill Amount → Angelstore UPI Payment → UTR + Screenshot → Pending Verification → Admin Verify/Reject → Admin manually processes UPPCL bill → Completed/Failed → Customer notification.

## Verification
- `node --check server.js` PASS
- `node --check customer.js` PASS
- `/api/health` on isolated test port: HTTP 200
- Customer manual UPPCL payment without session: HTTP 401
- Admin manual UPPCL queue without admin session: HTTP 401
