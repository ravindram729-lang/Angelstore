# STEP585 — UPPCL Custom / Advance Payment Fix Report

## Scope
Only the existing UPPCL customer/admin structure was changed. No new UPPCL external provider/API was added.

## Implemented
- Customer fetches the Admin-published manual bill using the existing Account/Mobile lookup.
- Customer can pay the full bill amount, a custom/partial amount, or an advance amount above the bill total.
- Payment amount is no longer forced to equal the bill total.
- UTR is optional; screenshot is optional; at least one of UTR or screenshot is required.
- Admin payment queue shows full UTR when supplied, current paid amount, bill total, cumulative verified paid, remaining amount, and advance amount.
- Multiple verified payments can accumulate against the same bill version.
- Admin cannot mark a partially paid bill as Completed until cumulative verified payments cover the bill total.
- If cumulative verified payments exceed the bill total, the excess is shown as Advance.
- Completion continues to use the existing Angelstore automatic receipt generation flow.
- Customer bill summary refreshes with Verified Paid / Remaining / Advance.
- Existing UPPCL structure, verification, processing, notification and receipt lifecycle were preserved.

## Verification
- `npm run check` — PASS
- `STEP585_UPPCL_FULL_CUSTOM_ADVANCE_E2E.js` — PASS
  - Custom amount + UTR-only — PASS
  - Screenshot-only — PASS
  - Partial completion blocked — PASS
  - Additional payment — PASS
  - Advance payment — PASS
  - Cumulative verified total — PASS
  - Advance calculation — PASS
  - Automatic Angelstore receipt — PASS
  - Customer bill summary — PASS

## Example verified scenario
Bill total: ₹1,120
- Payment 1: ₹500 (UTR only) → Verified
- Payment 2: ₹300 (Screenshot only) → Verified
- Payment 3: ₹500 (UTR only) → Verified
- Cumulative verified: ₹1,300
- Remaining: ₹0
- Advance: ₹180
- Final completion + Angelstore receipt: PASS

## Explicit non-scope
- No external UPPCL official receipt/reference was added or stored.
- No external UPPCL bill/payment API was introduced.
