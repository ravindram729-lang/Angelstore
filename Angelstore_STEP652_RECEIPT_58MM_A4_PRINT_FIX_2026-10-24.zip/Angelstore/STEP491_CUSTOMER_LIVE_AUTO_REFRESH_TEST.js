const fs=require('fs');
const assert=require('assert');
const customer=fs.readFileSync('customer.js','utf8');
const server=fs.readFileSync('server.js','utf8');
function ok(name,fn){try{fn();console.log('PASS',name)}catch(e){console.error('FAIL',name,e.message);process.exitCode=1}}
ok('5 second customer live sync timer exists',()=>assert(customer.includes('customerLiveSyncTimer=setInterval(tick,5000)')&&customer.includes('if(shouldPoll()&&hasCustomerLogin()){syncCustomerRechargeState();refreshAll().catch(()=>{});}'), 'live timer missing'));
ok('live sync polls only status/token/home',()=>assert(customer.includes("h==='customer-status'||h==='customer-token'||h==='customer-home'"), 'scope missing'));
ok('live sync stops when page is outside live scope',()=>assert(customer.includes('else if(!shouldPoll())stopCustomerLiveSync()'), 'stop guard missing'));
ok('refresh generation guards stale responses',()=>assert(customer.includes('const requestGeneration=++customerRefreshGeneration')&&customer.includes('if(requestGeneration!==customerRefreshGeneration)return;'), 'generation guard missing'));
ok('logout stops live polling',()=>assert(customer.includes('if(!loggedIn){\n      stopCustomerLiveSync();'), 'logout stop missing'));
ok('customer live queue exposes last_action_at',()=>assert(/\/api\/customer\/live-queue[\s\S]*last_action_at:x\.last_action_at/.test(server), 'last_action_at missing'));
ok('customer token endpoint uses server public token state',()=>assert(/const customerRows=db\.tokens\.filter\(x=>x\.mobile===c\.mobile/.test(server)&&server.includes('const rows=customerRows.map(x=>publicToken(x,queueCtx))'), 'public token mapping missing'));
console.log('STEP491 targeted verification: PASS');
