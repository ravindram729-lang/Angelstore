const fs=require('fs');
const s=fs.readFileSync(__dirname+'/server.js','utf8');
const checks=[
 ['transaction snapshot','applicationsBefore=db.applications.length;'],
 ['payment snapshot','paymentsBefore=db.payments.length;'],
 ['audit snapshot','auditBefore=db.audit.length;'],
 ['rollback application','db.applications.length=applicationsBefore;'],
 ['rollback payment','db.payments.length=paymentsBefore;'],
 ['rollback audit','db.audit.length=auditBefore;'],
 ['proof cleanup','fs.unlinkSync(path.join(UPLOAD_DIR,proof.filename))'],
 ['retryable save failure','retryable:true'],
 ['atomic save try','try{\n        save();'],
 ['payment/application linkage','application_id:applicationId']
];
let ok=true;
for(const [name,needle] of checks){const pass=s.includes(needle);console.log(`${pass?'PASS':'FAIL'} ${name}`);ok&&=pass;}
const block=s.match(/const applicationsBefore=db\.applications\.length;[\s\S]{0,5000}?return json\(res,200,\{ok:true,payment:customerPayment\(pay\)/);
console.log(`${block?'PASS':'FAIL'} consistency transaction block present`);ok&&=!!block;
process.exit(ok?0:1);
