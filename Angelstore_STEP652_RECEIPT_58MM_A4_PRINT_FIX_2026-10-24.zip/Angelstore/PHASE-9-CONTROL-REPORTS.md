# Angelstore CSC — Phase 9

## Scope
Admin Control Center + reports/analytics + service-wise contribution + staff performance + customer history.

## Backend additions
- `GET /api/control-center` — pending payments, unassigned tokens, QC pending, active staff, home-service pending and open complaints.
- `GET /api/reports/service?from=&to=` — service-wise token count, completion rate, verified collection, official fee, staff commission and contribution.
- `GET /api/reports/staff?from=&to=` — assigned/completed/active tasks, QC pass/pending, home visits, deliveries and commission.
- `GET /api/customer-history?mobile=` — customer tokens, payments, applications, home services and deliveries.
- Existing `/api/reports` now returns the advanced analytics together with the original report data.

## Admin UI
- New **Control Center** page with KPI cards and action queue.
- Reports page now loads service-wise and staff-wise tables for the selected date range.
- Customer Management now has a **History** action for the selected mobile number.

## Data safety
No existing business record was intentionally deleted or rewritten. Phase 8 storage schema is reused. No new database collection was required for Phase 9.

## Verification
- `node --check server.js` passed.
- `node --check app.js` passed.
- `node --check storage.js` passed.
- Fresh backend smoke test on an isolated port passed for health, control center, service report and staff report endpoints.
- Existing Phase 7 test staff records remain present in the copied data set; they were not removed.

## Important interpretation
Service-wise “Contribution” is not the same as final net profit. It excludes broader salary/operating overhead and is therefore presented as contribution, not as a profitability verdict.
