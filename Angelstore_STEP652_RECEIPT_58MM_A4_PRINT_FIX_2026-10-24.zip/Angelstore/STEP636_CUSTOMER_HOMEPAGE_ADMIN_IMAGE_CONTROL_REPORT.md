# STEP636 — Customer Homepage Admin Image Control

## Scope
Admin can change the Customer Homepage hero image without editing source code.

## Changes
- Added persistent `homepage_hero_image` setting with existing homepage image as fallback.
- Added Admin Settings → Branding → Customer Homepage Hero Image upload control.
- PNG/JPG/WEBP accepted, maximum 5 MB.
- Added Admin-only upload endpoint with CSRF/session protection.
- Added public read endpoint for the currently configured homepage image.
- Customer Homepage reads the configured image from public configuration and replaces the default hero image.
- Previous uploaded homepage hero file is removed when replaced.
- Existing Quick Services, Token, Payment, UPPCL and Recharge workflows are untouched.

## Verification
- `node --check server.js` PASS
- `node --check app.js` PASS
- `node --check customer.js` PASS
- Local backend `/api/public-config` PASS
- Admin login + CSRF-protected homepage image upload PASS
- Public configuration returns the newly uploaded homepage image PASS
- ZIP integrity PASS
