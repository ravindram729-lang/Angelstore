# STEP484 — Admin Login Local Password Fix Report

## Scope
- Local admin username: `ravindram143`
- Local development password: set to the operator-supplied password.
- No plaintext password is stored in the credential database or release documentation.

## Root cause
The hardened server had removed the local bootstrap credential path while the local browser instance expected the existing development admin credential. A fresh local install with no `admin_credentials` therefore could not authenticate with the documented local account.

## Fix
- Restored a **local-development-only** bootstrap credential path.
- The local password is represented only by a fixed scrypt salt/hash pair in source; the plaintext password is not stored in source or `data.json`.
- On first local admin login, the hashed credential is persisted to `admin_credentials`.
- Production still requires `ANGELSTORE_ADMIN_USER`, `ANGELSTORE_ADMIN_PASS`, and other production configuration.
- The production startup gate explicitly rejects known weak/default passwords, so the local development password cannot be used for production deployment.

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- Fresh local server with no admin env — PASS
- `POST /api/auth/login` with local admin account — PASS
- Wrong-password rejection — PASS
- Production weak-password configuration gate — PASS (startup rejected)
- `FINAL-RELEASE-AUDIT.js` — PASS

## Security note
Use a unique high-entropy password for any public/production deployment. The requested local development password is intentionally not accepted by the production configuration gate.
