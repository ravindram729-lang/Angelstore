# Angelstore STEP378 — Priority Fix Report

Date: 2026-09-26

## Fixed

1. Final Quality Gate was made explicit:
   - Admin `save` no longer implicitly passes quality review.
   - `pass` is a separate action.
   - PASS requires checklist + document gate + payment gate.
   - Gate status is returned to the UI and shown in the Token Work Center.
2. Required document validation now matches required document labels/types instead of only comparing counts.
3. Document-status synchronization and customer progress use the same required-document gate.
4. Payment proof policy is consistent for UPI/Bank customer and manual admin payment entry: UTR + screenshot/proof are required; Cash remains proof-free.
5. Application tracking now accepts both Application IDs and Token numbers.
6. Staff RBAC was added with explicit permissions and Admin role management:
   - viewer
   - staff
   - senior_staff
   - supervisor
   - manager
   - legacy role aliases retained for existing records
7. OCR upload records now expose structured extracted fields (document type, Aadhaar/PAN/mobile/email/DOB and basic marks/percentage fields when detected).
8. SOP document fallback no longer incorrectly copies documents from the first service in a category.
9. Frontend cache-busters were advanced for the changed Admin and Customer JavaScript.
10. Node engine requirement pinned to `>=20 <23`; package version bumped to 3.0.3.
11. README service count corrected to 25 categories / 116 sub-services and first-run Staff setup documented.
12. Phase 33 and Phase 34 audit tests were updated to match the current backup manifest and current security behavior.

## Verification

- All JavaScript files: syntax PASS
- `npm run check`: PASS
- `FINAL-RELEASE-AUDIT.js`: PASS
- Full isolated E2E test: PASS
- Phase 33 backup/restore/concurrency audit: PASS
- Phase 34 security abuse audit: PASS

## Architecture items intentionally not migrated automatically

- The project still uses the existing JSON repository. It has atomic writes, a write lock, revision checks, pruning and backup/restore. A move to PostgreSQL/MySQL is a larger migration and should be done against a chosen production database target rather than guessed.
- Off-site backup transport is already implemented through `ANGELSTORE_OFFSITE_BACKUP_URL` and token configuration; the actual provider endpoint/credentials must be supplied by deployment configuration.
- OCR structured extraction is now available as metadata, but full document-specific form auto-fill and a complete marksheet calculation UI remain a separate feature phase.
