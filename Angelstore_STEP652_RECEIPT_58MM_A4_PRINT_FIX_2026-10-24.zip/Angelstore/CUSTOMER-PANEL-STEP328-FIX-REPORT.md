# Customer Panel STEP328 Fix Report

Date: 2026-09-24

## Scope
Customer panel P1/P2/P3 remediation based on the end-to-end audit. Cart/order functionality is intentionally not included.

## Completed

### P1
1. Fixed mobile LIVE SCREEN horizontal overflow with narrow-screen wrapping/overflow rules.
2. Fixed `home-service` deep-link so it opens `customer-home-service`.
3. Added customer appointment booking form with service/date/time and backend POST integration.
4. Added automatic payment-status polling through the existing 3-second refresh cycle.
5. Made customer service/pricing data load from backend `/api/services` and `/api/service-charges` rather than relying only on the embedded catalog.
6. Added linked-service support for LIVE OFFERS. Admin can associate an offer with a concrete `Category — Sub-service`; customer action selects that service and recalculates the server-backed amount.
7. Added authenticated customer document upload/listing for application documents.
8. Added OCR architecture using server-side Tesseract for image documents (`eng+Devanagari`), storing OCR status/text. PDFs are stored without OCR. OCR failure is recorded rather than reported as successful.

### P2
9. Added customer receipt Print / Save PDF browser workflow.
10. Added application View detail workflow, including application metadata and uploaded-document/OCR status.
11. Converted payment UI to a real HTML form with submit prevention and native required file validation.
12. Added frontend and backend past-date/time validation for appointments and home-service requests.
13. Improved mobile UPI/QR layout and wrapping; desktop/mobile UPI behavior is now clearer.
14. Removed the unused customer local-mode implementation and its `angelLocal*` business-state storage paths; backend is the only runtime data path.
15. Corrected `/api/customer/applications` to return all applications belonging to the authenticated customer instead of only the current application.
16. Improved queue wait estimate from a hard-coded 3-minute multiplier to a configurable average-minute value with correct pending-position calculation.

### P3 / partial
17. Extracted the large inline customer script from `customer.html` into `customer.js`, reducing HTML/script coupling. Deeper module splitting remains future work.
18. Customer service/pricing reads now go through backend catalog/charge APIs; a full database-backed single pricing source remains future architecture work.
19. Live queue still uses polling. SSE/WebSocket has not been substituted yet because the current authenticated customer flow requires secure per-customer state delivery.
20. Added basic `aria-live` regions for payment, queue and update status areas. Full accessibility audit remains future work.
21. Static/API/E2E-style regression checks were rerun. Full interactive browser E2E against a deployed environment is still pending.

## Cart policy
Cart is intentionally absent. No cart, add-to-cart, cart total, or e-commerce checkout workflow was added.

## Backend additions
- `GET /api/customer/application?id=...`
- `GET /api/customer/documents`
- `POST /api/customer/documents`
- Customer application documents are ownership-checked against the authenticated customer.
- Image documents attempt Tesseract OCR and store `ocr_status`/`ocr_text`.
- Appointment API now rejects invalid/past dates and validates service.
- Home-service API now rejects invalid/past requested date/time.
- LIVE offers support a linked `service` field.

## Verification
- `npm run check` — PASS
- `node --check customer.js` — PASS
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `FINAL-RELEASE-AUDIT.js` — PASS
- `/api/health` boot test — PASS
- Customer registration/session test — PASS
- Appointment POST test — PASS
- Customer application API test — PASS
- Customer document upload/list/detail test — PASS
- Customer payment submission test — PASS
- Original `data.json` restored after temporary test records; test uploads removed.

## Remaining
- Real transactional database migration
- Deeper customer JS module split
- Database-backed single service/pricing authority
- SSE/WebSocket live queue
- Full accessibility review
- Full browser E2E on deployed production environment
- More complete OCR field extraction/auto-fill for Aadhaar, PAN and marksheets
