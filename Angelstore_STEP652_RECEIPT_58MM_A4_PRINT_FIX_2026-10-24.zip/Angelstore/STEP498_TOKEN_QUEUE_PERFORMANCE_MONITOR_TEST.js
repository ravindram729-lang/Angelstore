const fs=require('fs');
const assert=require('assert');
const server=fs.readFileSync('server.js','utf8');
const customer=fs.readFileSync('customer.js','utf8');
function pass(name){console.log('PASS',name)}
assert(server.includes('const auditByToken=new Map()'),'audit index missing'); pass('audit index is built once per health scan');
assert(server.includes('const notesByToken=new Map()'),'notification index missing'); pass('notification index is built once per health scan');
assert(server.includes('tokenLifecycleReconcile(t,ctx)'),'health monitor uses indexed reconciliation'); pass('health monitor uses indexed reconciliation');
assert(customer.includes('if(refreshAllInFlight)return refreshAllInFlight;\n  const requestGeneration=++customerRefreshGeneration;'),'in-flight generation ordering missing'); pass('refresh generation cannot invalidate the active in-flight request');
assert(customer.includes('if(document.hidden)return;'),'hidden-tab guard missing'); pass('live refresh pauses while tab is hidden');
assert(!customer.includes('setInterval(refreshAll,3000)'),'legacy 3-second global refresh remains'); pass('legacy global 3-second refresh removed');
const intervals=(customer.match(/setInterval\(tick,5000\)/g)||[]).length; assert.strictEqual(intervals,1); pass('customer live sync uses a single 5-second timer');
console.log('STEP498 targeted checks: 6/6 PASS');
