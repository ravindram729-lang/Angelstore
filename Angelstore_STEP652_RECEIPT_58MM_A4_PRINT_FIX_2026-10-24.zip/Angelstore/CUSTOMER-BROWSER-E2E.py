import os, json, time, subprocess, requests, websocket, uuid, shutil, re, base64
from pathlib import Path

ROOT=Path(__file__).resolve().parent/'project'/'step437'
WORK=Path(__file__).resolve().parent/'runtime'
PORT=8127
CDP=9227
WORK.mkdir(exist_ok=True)
STORAGE=WORK/'storage'
if STORAGE.exists(): shutil.rmtree(STORAGE)
STORAGE.mkdir(parents=True)
(STORAGE/'data.json').write_text('{}', encoding='utf-8')
for d in ['uploads/payments','uploads/documents','backups']:(STORAGE/d).mkdir(parents=True,exist_ok=True)

env=os.environ.copy(); env.update({'PORT':str(PORT),'ANGELSTORE_STORAGE_DIR':str(STORAGE),'NODE_ENV':'development','ANGELSTORE_AUTH_SECRET':'e2e-'+uuid.uuid4().hex*2})
server=subprocess.Popen(['node','server.js'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)

def wait_http(url, timeout=15):
    end=time.time()+timeout
    while time.time()<end:
        try:
            r=requests.get(url,timeout=1)
            if r.status_code<500:return r
        except:pass
        time.sleep(.15)
    raise RuntimeError('server did not start')

def api(path, method='get', **kw):
    return requests.request(method, f'http://127.0.0.1:{PORT}{path}', timeout=5, **kw)

try:
    wait_http(f'http://127.0.0.1:{PORT}/api/health')
    mobile='9'+str(int(time.time()*1000))[-9:]
    pin='2468'
    r=api('/api/customer/register','post',json={'name':'E2E Customer','mobile':mobile,'pin':pin})
    assert r.status_code==201, r.text
    auth=r.json()['session_token']
    headers={'X-Customer-Session':auth}

    # Real API smoke tests, independent of browser policy.
    api_report={}
    api_report['health']=api('/api/health').status_code==200
    api_report['customer_me']=api('/api/customer/me',headers=headers).status_code==200
    api_report['dashboard']=api('/api/customer/dashboard',headers=headers).status_code==200
    api_report['applications']=api('/api/customer/applications',headers=headers).status_code==200
    api_report['appointments']=api('/api/customer/appointments',headers=headers).status_code==200
    api_report['documents']=api('/api/customer/documents',headers=headers).status_code==200
    api_report['notifications']=api('/api/customer/notifications',headers=headers).status_code==200
    api_report['live_queue']=api('/api/customer/live-queue',headers=headers).status_code==200
    # Unauthorized document check.
    api_report['documents_unauthorized']=api('/api/customer/documents').status_code==401
    # Appointment past-date validation.
    ar=api('/api/customer/appointments','post',headers=headers,json={'service':'PAN सेवाएँ — PAN Card New','date':'2020-01-01','time':'10:00'})
    api_report['appointment_past_rejected']=ar.status_code==400
    # OCR minimization check.
    docs=api('/api/customer/documents',headers=headers).json().get('documents',[])
    api_report['ocr_not_exposed']=not any(('ocr_text' in d or 'ocr_fields' in d) for d in docs)

    chrome=subprocess.Popen(['/usr/bin/chromium','--headless=new','--no-sandbox','--disable-gpu',f'--remote-debugging-port={CDP}','--remote-allow-origins=*','about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    end=time.time()+15
    while time.time()<end:
        try: target=requests.get(f'http://localhost:{CDP}/json').json()[0]; break
        except: time.sleep(.2)
    else: raise RuntimeError('Chrome CDP did not start')
    ws=websocket.create_connection(target['webSocketDebuggerUrl'],timeout=15)
    seq=0
    def cdp(method,params=None):
        global seq
        seq+=1; ident=seq
        ws.send(json.dumps({'id':ident,'method':method,'params':params or {}}))
        while True:
            msg=json.loads(ws.recv())
            if msg.get('id')==ident:return msg
    def evaljs(expr, awaitPromise=False):
        res=cdp('Runtime.evaluate',{'expression':expr,'returnByValue':True,'awaitPromise':awaitPromise})
        if 'exceptionDetails' in res.get('result',{}): raise RuntimeError(res['result']['exceptionDetails'])
        return res.get('result',{}).get('result',{}).get('value')

    cdp('Page.enable'); cdp('Runtime.enable')
    # Inline the real customer HTML/CSS/JS into about:blank because this execution environment blocks browser network/file navigation.
    html=(ROOT/'customer.html').read_text(encoding='utf-8')
    css=(ROOT/'style.css').read_text(encoding='utf-8')
    svc=(ROOT/'service-catalog.js').read_text(encoding='utf-8')
    cust=(ROOT/'customer.js').read_text(encoding='utf-8').replace('localStorage','angelStorage')
    timer=(ROOT/'panel-timer.js').read_text(encoding='utf-8').replace('localStorage','angelStorage')
    bilingual=(ROOT/'bilingual-ui.js').read_text(encoding='utf-8').replace('localStorage','angelStorage')
    html=html.replace('<link rel="stylesheet" href="style.css">', '<style>'+css+'</style>')
    html=re.sub(r'<script[^>]*src="(?:service-catalog|customer|panel-timer|bilingual-ui)[^>]*></script>', '', html)
    html=re.sub(r'\s(src|href)="assets/[^\"]+"', '', html)
    cdp('Page.setDocumentContent',{'frameId':target['id'],'html':html})
    time.sleep(.4)
    prelude="""(function(){const mem={angelCustomerSession:%s,angelCustomerMobile:%s,angelCustomerProfile:JSON.stringify(%s)};window.angelStorage={getItem:k=>Object.prototype.hasOwnProperty.call(mem,k)?String(mem[k]):null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]},clear:()=>{for(const k of Object.keys(mem))delete mem[k]}};const ok=data=>Promise.resolve({ok:true,status:200,json:()=>Promise.resolve(data)});window.fetch=(url,opts)=>{url=String(url);const p=url.split('?')[0];if(p.endsWith('/api/public-config'))return ok({settings:{centre:'Angelstore CSC',operator:'E2E',upi_id:'',payee_name:'',payment_qr_path:'assets/payment-qr.jpg'},offers:[]});if(p.endsWith('/api/customer/me'))return ok({customer:%s,qr_payload:'ANGELSTORE|CUSTOMER|%s'});if(p.endsWith('/api/customer/dashboard'))return ok({customer:%s,tokens:[],current:null,summary:{total_tokens:0,completed_tokens:0,verified_payments:0}});if(p.endsWith('/api/customer/live-queue'))return ok({tokens:[]});if(p.endsWith('/api/customer/applications'))return ok({applications:[]});if(p.endsWith('/api/customer/appointments'))return ok({appointments:[]});if(p.endsWith('/api/customer/documents'))return ok({documents:[]});if(p.endsWith('/api/customer/notifications'))return ok({notifications:[],unread:0});if(p.endsWith('/api/customer/records'))return ok({tokens:[],payments:[],receipts:[]});if(p.endsWith('/api/customer/home-services'))return ok({home_services:[]});if(p.endsWith('/api/customer/progress'))return ok({progress:{}});if(p.endsWith('/api/customer/tokens'))return ok({tokens:[]});if(p.endsWith('/api/offers'))return ok({offers:[]});if(p.endsWith('/api/service-charges'))return ok({charges:[]});if(p.endsWith('/api/services'))return ok({services:[]});if(p.endsWith('/api/recharge/plans'))return ok({plans:[]});if(p.endsWith('/api/recharge/initiate'))return ok({message:'E2E mock'});if(p.endsWith('/api/uppcl/bill'))return ok({bill:null});if(p.endsWith('/api/uppcl/payment'))return ok({message:'E2E mock'});if(p.endsWith('/api/customer/payment/status'))return ok({payment:{status:'Pending Verification'}});if(p.endsWith('/api/customer/track'))return Promise.resolve({ok:false,status:404,json:()=>Promise.resolve({error:'not found'})});return ok({});};})();
""" % (json.dumps(auth),json.dumps(mobile),json.dumps({'name':'E2E Customer','mobile':mobile,'customer_id':'AS-CUST-E2E'}),json.dumps({'name':'E2E Customer','mobile':mobile,'customer_id':'AS-CUST-E2E'}),json.dumps(mobile),json.dumps({'name':'E2E Customer','mobile':mobile,'customer_id':'AS-CUST-E2E'}))
    evaljs(prelude+'\n'+svc+'\n'+cust+'\n'+timer+'\n'+bilingual)
    time.sleep(2)
    for _ in range(30):
        try:
            if evaljs("typeof go==='function' && !!document.querySelector('#customerApp')"): break
        except: pass
        time.sleep(.1)
    else: raise RuntimeError('Customer JS did not initialize inside browser harness')

    report={'api':api_report,'navigation':{},'hash_deep_links':{},'responsive':{},'buttons':{},'forms':{},'issues':[]}
    pages=['customer-home','customer-services','customer-recharge','customer-uppcl','customer-token','customer-status','customer-tracking','customer-history','customer-receipts','customer-notifications','customer-applications','customer-documents','customer-home-service','customer-appointments']
    for p in pages:
        ok=evaljs(f"go({json.dumps(p)}); document.querySelector('#page-{p}')?.classList.contains('active-page')")
        report['navigation'][p]=bool(ok)
        if not ok: report['issues'].append('Navigation failed: '+p)
    # Execute the project's exact deep-link IIFE after setting a hash, because history.replaceState
    # intentionally does not emit hashchange events.
    deep_link_src=(ROOT/'customer.js').read_text(encoding='utf-8')
    marker_start=deep_link_src.index('(function handlePublicDeepLink(){')
    marker_end=deep_link_src.index('})();',marker_start)+5
    deep_link_iife=deep_link_src[marker_start:marker_end].replace('localStorage','angelStorage')
    for p in ['customer-services','customer-status','customer-documents','customer-appointments']:
        evaljs(f"location.hash={json.dumps(p)}; {deep_link_iife}")
        time.sleep(.15)
        active=evaljs("document.querySelector('.page.active-page')?.id||''")
        report['hash_deep_links'][p]=(active=='page-'+p)
        if active!='page-'+p: report['issues'].append('Hash deep-link failed: '+p)

    # Every static data-page button is exercised.
    navs=evaljs("Array.from(document.querySelectorAll('[data-page]')).map(b=>({id:b.id,text:(b.innerText||'').trim(),page:b.dataset.page}))")
    report['buttons']['navigation_buttons']=len(navs)
    if len(navs)<14: report['issues'].append('Navigation button count unexpectedly low')

    # Click safe controls on their actual rendered pages.
    safe=[('customer-home','customerAccountRefresh'),('customer-recharge','rechargeAutoDetect'),('customer-recharge','rechargeRefreshPlans'),('customer-uppcl','uppclFetchBill'),('customer-notifications','refreshNotifications'),('customer-notifications','markAllNotifications'),('customer-history','refreshHistory'),('customer-receipts','refreshRecords'),('customer-applications','refreshApplications'),('customer-home-service','refreshHomeServices'),('customer-appointments','refreshAppointments')]
    for page,bid in safe:
        evaljs(f"go({json.dumps(page)}); document.getElementById({json.dumps(bid)})?.click(); true")
        report['buttons'][bid]=bool(evaljs(f"!!document.getElementById({json.dumps(bid)})"))
        if not report['buttons'][bid]: report['issues'].append('Missing safe button: '+bid)
        time.sleep(.05)

    forms=evaljs("Array.from(document.forms).map(f=>({id:f.id,method:(f.method||'get').toLowerCase(),controls:f.elements.length,required:Array.from(f.querySelectorAll('[required]')).map(x=>x.id||x.name)}))")
    report['forms']['all']=forms
    for fid in ['authLoginForm','authRegisterForm','customerPaymentForm','appointmentForm']:
        if not any(x['id']==fid for x in forms): report['issues'].append('Missing form: '+fid)
    # Payment method UI state.
    evaljs("go('customer-token'); document.querySelector('[data-method=QR]').click()")
    qr=evaljs("({value:$('#cPaymentMethod')?.value,label:$('#selectedPaymentMethodLabel')?.textContent.trim()})")
    report['forms']['qr_method']=qr
    if qr['value']!='QR': report['issues'].append('QR method state failed')
    evaljs("document.querySelector('[data-method="+json.dumps('Bank Transfer')+"]').click()")
    bank=evaljs("({value:$('#cPaymentMethod')?.value,visible:getComputedStyle(document.querySelector('.bank-pay-card')).display!=='none'})")
    report['forms']['bank_method']=bank
    if bank['value']!='Bank Transfer' or not bank['visible']: report['issues'].append('Bank Transfer UI state failed')
    # Test responsive layout using actual browser layout engine.
    for w in [320,375,430,768,1024,1440]:
        cdp('Emulation.setDeviceMetricsOverride',{'width':w,'height':900,'deviceScaleFactor':1,'mobile':w<=768})
        evaljs("go('customer-home')")
        time.sleep(.08)
        vals=evaljs("({innerWidth,clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,bodyScrollWidth:document.body.scrollWidth})")
        vals['overflow']=max(vals['scrollWidth'],vals['bodyScrollWidth'])>vals['clientWidth']+1
        report['responsive'][str(w)]=vals
        if w in [320,430,1440]:
            shot=cdp('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False})['result']['data']
            (WORK/f'customer-{w}px.png').write_bytes(base64.b64decode(shot))
        if vals['overflow']: report['issues'].append(f'Horizontal overflow at {w}px')
    cdp('Emulation.clearDeviceMetricsOverride')
    # Button inventory.
    report['buttons']['total']=evaljs("document.querySelectorAll('button').length")
    report['buttons']['missing_id_or_data']=evaljs("Array.from(document.querySelectorAll('button')).filter(b=>!b.id&&!b.dataset.page&&!b.dataset.method&&!b.dataset.operator&&!b.dataset.rechargeType&&!b.dataset.planIndex&&!b.dataset.amount&&b.type!=='submit').map(b=>(b.innerText||'').trim())")
    report['pass']=not report['issues'] and all(api_report.values())
    Path(WORK/'CUSTOMER-BROWSER-E2E-REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
finally:
    try: ws.close()
    except: pass
    try: chrome.terminate(); chrome.wait(timeout=3)
    except: pass
    try: server.terminate(); server.wait(timeout=3)
    except: pass
