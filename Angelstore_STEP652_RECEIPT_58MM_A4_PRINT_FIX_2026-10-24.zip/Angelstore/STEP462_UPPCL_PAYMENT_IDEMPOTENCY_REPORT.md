# STEP462 — UPPCL Payment Idempotency / Retry Safety

## Objective
Prevent duplicate UPPCL payment/application creation when a customer retries after a network timeout, double submission, or lost response.

## Implemented
- Added a client-generated UPPCL `idempotency_key` that remains stable across a failed/retried request and is cleared only after a successful response.
- Added server-side idempotency lookup before creating a new UPPCL payment/application.
- Same customer + same bill/version + same amount + same retry key returns the original payment with `idempotent: true` instead of creating another payment/application.
- Reusing a retry key for a different request is rejected with HTTP 409.
- Existing UTR duplicate protection remains active.
- Requests without the new key retain safe fallback behavior using a deterministic customer/bill/version/UTR key, preserving compatibility with existing clients/tests.
- Stored `uppcl_bill_id` and `uppcl_bill_version` on the payment record for exact request matching/auditability.

## Verification
- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- `npm run check` — PASS
- `STEP456_UPPCL_SECURITY_E2E.js` — PASS
- `STEP462_UPPCL_IDEMPOTENCY_E2E.js` — PASS
  - first submit
  - same retry key returns same payment
  - different payload with same key blocked
  - legacy/no-key deterministic fallback retry safe
- `P0-P1-REGRESSION-TEST.js` — PASS
- `FINAL-RELEASE-AUDIT.js` — PASS

## Browser note
No fresh live Chromium localhost visual PASS is claimed because the environment has previously blocked/hung localhost browser access. Server/API and static verification were used instead.

## Result
UPPCL payment submission is now retry-safe against duplicate request creation while preserving existing stale-bill, UTR, screenshot, verification, processing, and receipt protections.
