# STEP377 — Final Quality Gate / Stale Admin JS Fix

## Problem observed
The browser showed the legacy `OK = final PASS / Cancel = reject/close` dialog and clicking OK resulted in `Quality Review rejected`, even though the checklist displayed 5/5.

## Root cause
The STEP376 `admin.html` loaded `app.js` with the old cache-busting query `?v=step352-final-gap-fixes-20260925`. The current STEP376 `app.js` already contains the consolidated Work Center and authoritative Admin PASS/REJECT handlers, but a browser can retain the older JavaScript bundle under the same URL.

## Fix
- Updated `admin.html` to load `app.js?v=step377-quality-gate-20260925`.
- The current Work Center's PASS action calls `/api/service-quality` without `action:'reject'`, so the server follows the Admin PASS path.
- The server still enforces required checklist, verified payment, and required-document gates before setting `quality_status='passed'`.
- Explicit Reject remains available only through the separate Reject / Correction action with a required reason.

## Expected behavior
5/5 required checks + verified payment + required documents verified -> `passed`.
Reject / Correction -> `rejected` only when the explicit Reject button is used and a reason is supplied.
