# STEP349 — Customer Document → Admin/Staff Handoff Fix

## Scope
Verified the existing document workflow from Customer upload to Admin/Staff verification and fixed one Staff-panel UI bug.

## Existing verified workflow
1. Customer uploads PDF/JPG/PNG/WEBP against a specific Application.
2. Backend stores the file under the private document storage directory and creates a `documents` record linked to the Application.
3. Customer progress reads `/api/customer/progress` and displays document progress.
4. Admin opens Token Management → `काम का विवरण` → `📄 Documents देखें`.
5. Admin can Open / Verify / Reject each document.
6. Staff opens an assigned task → `📄 Documents`.
7. Staff can Open / Verify / Reject only documents belonging to the assigned token/application.
8. Document files are not exposed through public `/uploads/` static access; they are served through authenticated document endpoints.
9. Document views are recorded in the audit log.

## Fix made in STEP349
Staff document Verify/Reject refresh used an undefined `tokenId` variable after the action. It now reopens the document list using the current token id argument (`id`).

Before:
`window.documents(tokenId)`

After:
`window.documents(id)`

## Validation
- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- `node --check app.js` — PASS
- `node --check panel-timer.js` — PASS
- `node --check bilingual-ui.js` — PASS
- Local backend `/api/health` — HTTP 200
- `index.html`, `customer.html`, `admin.html`, `staff.html` — HTTP 200
- Full existing E2E workflow — PASS (`ok: true`)
- Customer document upload + Admin document metadata/file access — PASS during focused API verification

## Security
- Customer document upload requires a customer session and application ownership.
- Admin document access requires Admin authentication.
- Staff document access is restricted to an assigned token/application.
- Document file endpoint uses `Cache-Control: no-store` and `X-Content-Type-Options: nosniff`.
- Direct `/uploads/` access remains blocked.

## Important note
The package contains the actual local backend and storage implementation. This verification is local; production deployment still requires its real persistent storage/environment configuration and a live deployment test.
