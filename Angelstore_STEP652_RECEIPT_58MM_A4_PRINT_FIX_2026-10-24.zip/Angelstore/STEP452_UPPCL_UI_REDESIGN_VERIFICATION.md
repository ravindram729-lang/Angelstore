# STEP452 — UPPCL Customer Manual Payment UI Redesign

## Scope
- Replaced the Customer → UPPCL Bill Payment page UI with the approved manual-payment layout.
- Preserved existing UPPCL API/payment workflow and existing element IDs required by customer.js.
- Added responsive desktop/tablet/mobile styling.

## Workflow
1. Consumer details
2. Live UPPCL bill lookup
3. Pay exact fetched payable amount through Angelstore UPI/QR
4. Submit UTR + payment screenshot
5. Admin verification
6. Manual UPPCL processing
7. Receipt/status tracking

## Safety / validation
- Payable amount is read-only on the proof form and comes from the fetched bill.
- Screenshot type limited to PNG/JPEG/WEBP and 5 MB client-side.
- Existing server endpoint still validates amount, UTR, screenshot, duplicate UTR and duplicate proof.
- UPI settings endpoint aligned to `/api/public-config`.

## Verification
- `node --check customer.js` — PASS
- `node --check server.js` — PASS
- `customer.html` HTML parser — PASS
- Local server started on port 8000 — PASS
- `/api/public-config` returned HTTP 200 — PASS
- Customer page returned HTTP 200 — PASS
