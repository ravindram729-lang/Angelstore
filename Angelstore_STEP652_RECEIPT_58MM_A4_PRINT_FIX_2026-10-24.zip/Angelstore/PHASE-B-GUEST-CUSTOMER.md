# Phase B — Guest Customer Workflow + Optional Login

## Goal
Customer login is optional. A guest can browse services, start an application, submit UPI payment proof (UTR + screenshot), wait for admin verification, and generate a live token. Login is required only for account/history/records/appointments.

## Security model
- Public application creation creates a signed, application-scoped guest token.
- Guest token is accepted only by payment submission/status and token generation.
- Guest token cannot access customer dashboard, account, history, receipts, applications list, appointments, home-services, deliveries, or customer logout.
- Guest token is scoped to its application/mobile.
- Existing logged-in customer sessions continue to work.

## UI behavior
- Customer page opens without a forced login overlay.
- Header shows `Guest Customer` + Login button.
- Service browsing, Token/Payment page and Live Queue remain available to guests.
- Account/history/receipts/applications/appointments open the login dialog when not authenticated.
- Successful login switches header to the customer account state.

## Verification
- Backend health: PASS
- Public application: PASS
- Guest payment submission with UTR + screenshot: PASS
- Guest payment status: PASS
- Guest access to dashboard: correctly rejected with 401
- Admin proof-view + verification: PASS
- Guest token generation after verification: PASS
- Customer frontend JavaScript syntax: PASS

## Not verified
Live Netlify deployment and external production hosting were not modified or claimed as live-verified in this phase.
