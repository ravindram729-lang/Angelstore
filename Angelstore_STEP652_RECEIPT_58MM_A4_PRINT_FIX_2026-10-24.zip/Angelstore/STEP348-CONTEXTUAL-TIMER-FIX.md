# STEP348 — Contextual Token Timer Fix

## Problem
The global token timer was injected into the page header. On the Customer panel this made the timer appear above the navigation/content instead of next to the Current Token it described.

## Fix
- Removed header insertion for the global timer.
- Customer panel: timer is now rendered inside the `Current Token` card below the service name.
- Staff panel: timer is now rendered inside the `मेरे Assigned Tasks` panel above the task table.
- Admin panel: no duplicate global timer is injected; Admin already has the contextual `Work Timer` / `Pending Timer` inside `#tokenRuntimeMeta` of Token Management.
- Preserved the same live polling and 1-second display refresh behavior.
- Updated script cache-busting to `step348-contextual-timer` on Customer and Staff pages.

## Validation
- `node --check panel-timer.js` PASS
- `node --check customer.js` PASS
- `node --check server.js` PASS
- `node --check app.js` PASS
- Customer/Staff HTML reference STEP348 timer version.
