# Angelstore Release Data Policy

This release package is a clean production template. It intentionally contains no customer records, payment records, application records, uploaded documents, payment proofs, active sessions, admin credentials, staff credentials, or runtime backups.

Production secrets must be supplied through environment variables. Runtime uploads and backups are created under configured storage paths after deployment.

The service catalog and explicit service workflow configuration are retained because they are application configuration, not customer runtime data.
