# Phase 30 — Automated Alert & Incident System

## Scope
Built on Phase 28/29 without rewriting business workflows. Adds operational incident lifecycle: detect → open → notify → persist → recover/resolve.

## Changes
- Added migration-safe `incidents` collection.
- Added monitoring configuration:
  - `ANGELSTORE_ALERT_WEBHOOK_URL`
  - `ANGELSTORE_ALERT_WEBHOOK_TOKEN`
  - `ANGELSTORE_MONITOR_INTERVAL_MINUTES` (minimum 5)
  - `ANGELSTORE_BACKUP_OVERDUE_MULTIPLIER` (default 1.5)
- Added scheduled monitoring loop and startup check.
- Added incident deduplication by incident type.
- Added recovery detection when a condition clears.
- Added admin APIs:
  - `GET /api/admin/monitoring`
  - `GET /api/admin/incidents`
  - `POST /api/admin/incidents/resolve`
- Added optional generic webhook alert delivery. No provider or credential was fabricated.
- Added Admin UI page: Monitoring & Incidents.

## Incident conditions
- Database integrity failure — critical
- Database storage unavailable — critical
- Persistent storage not configured — critical
- Scheduled backup overdue — warning (only when scheduled backup is enabled)

## Security
- Monitoring and incident endpoints require admin authentication.
- Webhook token is never returned by monitoring APIs.
- Existing auth, payment, token, staff and QC gates are unchanged.

## Verification
- `node --check server.js` PASS
- `node --check storage.js` PASS
- `node --check app.js` PASS
- `/api/health` 200 PASS
- Monitoring endpoint unauthenticated 401 PASS
- Admin login PASS
- Authenticated monitoring PASS
- Incident persistence/deduplication logic loaded PASS
- Healthy-state check PASS

## Not verified
- Real production alert delivery, because no external webhook provider/credential was supplied.
- Real Render scheduled execution, because live production access is not available from this environment.
