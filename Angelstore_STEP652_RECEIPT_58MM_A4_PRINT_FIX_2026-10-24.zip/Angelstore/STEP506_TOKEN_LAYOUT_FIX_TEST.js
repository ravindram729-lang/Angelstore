const fs=require('fs');
const html=fs.readFileSync('customer.html','utf8');
const checks=[
 ['STEP506 style present', html.includes('step506-token-layout-fix')],
 ['desktop token grid balanced', html.includes('grid-template-columns:minmax(0,1.45fr) minmax(320px,.85fr)')],
 ['payment spans first two rows', html.includes('.token-reference-right > .token-payment-ref{grid-column:2;grid-row:1 / span 2}')],
 ['proof moved to left column', html.includes('.token-reference-right > .token-proof-ref{grid-column:1;grid-row:4}')],
 ['next workflow remains right', html.includes('.token-reference-right > .token-next-ref{grid-column:2;grid-row:3}')],
 ['generated token remains right', html.includes('.token-reference-right > .token-generated-wrap{grid-column:2;grid-row:4}')],
 ['payment methods wrap to 2 columns', html.includes('.token-ref-methods{grid-template-columns:repeat(2,minmax(0,1fr))}')],
 ['mobile single column', html.includes('@media(max-width:820px)') && html.includes('grid-template-columns:1fr')],
 ['payment form preserved', html.includes('id="customerPaymentForm"')],
 ['token controls preserved', ['generateToken','submitPayment','refreshMyToken','goLive'].every(id=>html.includes(`id="${id}"`))]
];
let pass=0; for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`); if(ok) pass++;}
console.log(`RESULT ${pass}/${checks.length}`); process.exit(pass===checks.length?0:1);
