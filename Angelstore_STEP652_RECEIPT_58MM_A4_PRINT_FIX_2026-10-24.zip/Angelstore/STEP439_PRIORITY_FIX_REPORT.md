# STEP439 — Priority Fix & Reverification Report

## Fixed

### P0
- Offer price is now validated and bound to the actual payment amount.
- Offer service/date/price validation is enforced server-side for create/update/payment.
- Appointment-required services are now gated at token issuance on the backend, including Admin-issued tokens.
- Admin appointment status updates validate dates and confirmed-slot conflicts.
- Payment status polling timer is stopped when payment state is cleared/logout occurs.

### P1
- Queue current-token lookup is date-scoped and priority-aware.
- Admin live queue endpoint is today-scoped and uses the same ordering model.
- Customer live queue now exposes priority and uses priority-aware ordering.
- Customer application detail no longer returns OCR raw text/fields; OCR remains an internal processing record.
- Document file/download/delete authorization is centralized through one authorization helper.
- Admin/staff failed-login rate limits are persisted in storage instead of process-only memory.

### Backup/security
- Off-site backup upload now fails closed when application-level encryption is not configured. Plaintext off-site upload is no longer allowed.

## Verification after fixes

- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `node --check customer.js` — PASS
- `npm run check` — PASS
- `npm run p0-p1-regression` — PASS
- Full `E2E-TEST.js` on isolated test storage — PASS
- Appointment gate: 409 before approval — PASS
- Appointment confirmation → token generation — PASS
- Offer amount mismatch blocked — PASS
- Pending → Called → Processing — PASS
- Customer OCR data minimization — PASS
- Current-day queue scope — PASS

## Not migrated in this step

- Relational database migration
- Dedicated OCR worker
- SSE/WebSocket
- Full source modularization
