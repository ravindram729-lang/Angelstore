# Phase 34 — Security & Abuse/Attack Simulation Audit

## Scope

Security-focused validation of the Phase 33 Angelstore CSC backend. The audit covered authentication/authorization boundaries, malformed and oversized payloads, public-token privacy, brute-force controls, path traversal protection, and production CORS behavior.

Tests were run against isolated local storage. No production database or production credentials were used.

## Verification Results

| Check | Result |
|---|---|
| Unauthenticated admin monitoring | PASS — 401 |
| Unauthenticated admin storage status | PASS — 401 |
| Unauthenticated staff dashboard | PASS — 401 |
| Unauthenticated customer records | PASS — 401 |
| Malformed JSON | PASS — 400 |
| Oversized payload | PASS — connection rejected by payload guard |
| Public token privacy | PASS — unauthenticated response does not expose full token/customer list |
| Forged admin bearer token | PASS — 401 |
| Guest application rate limit | PASS — 18th+ invalid requests reached 429 in the test run |
| Production authenticated backup path traversal | PASS — 400 |
| Production admin login | PASS |
| Production admin brute-force protection | PASS — 11th failed attempt returned 429 |
| Production CORS | PASS — configured origin is returned; arbitrary origin is not reflected |

## Important observations

1. **Production CORS is fixed-origin, not request-origin reflection.** The response contains the configured frontend origin even when a different Origin header is supplied. A browser will not accept that response as cross-origin for the unconfigured origin because the ACAO value does not match it.
2. **Local development uses `*` CORS by design.** Production configuration requires an explicit HTTPS origin and the production preflight rejects invalid configuration.
3. **Payload protection intentionally terminates oversized requests.** The current implementation destroys the connection after the 15 MB threshold rather than continuing to parse the body. This is an acceptable defensive behavior; clients may observe `ECONNRESET` instead of a JSON 413 response.
4. **No authorization bypass was found in the tested admin/staff/customer endpoints.** This audit is not a formal penetration test and does not prove absence of all vulnerabilities.

## Security controls confirmed in code

- HMAC-signed expiring bearer tokens.
- Server-side session records with revocation and expiry checks.
- Separate admin, staff, and customer authentication paths.
- Staff token access restricted to assigned staff.
- Customer token/payment access scoped to authenticated customer or guest application.
- Admin-only monitoring, backup, restore, SOP, offer and management endpoints.
- Login attempt rate limits for admin, staff and customer authentication.
- Guest application rate limiting.
- UTR duplicate prevention.
- Token-per-payment duplicate prevention.
- Backup filename validation plus `path.basename()` handling.
- JSON payload size protection.
- Production configuration requires a strong auth secret, explicit HTTPS CORS origin and strong admin password.

## Not verified

- External internet/WAF/CDN behavior.
- Actual Render/Netlify production deployment.
- Automated DAST scanner results.
- Browser-based CSRF behavior under every deployment configuration.
- File-system permissions on the real Render persistent disk.
- Third-party webhook security configuration.
- Full source-code penetration test by an independent security tester.

## Conclusion

Phase 34 found no confirmed authentication/authorization bypass in the tested attack surface. Existing defensive controls behaved as expected under the simulated abuse cases. The remaining security risk is primarily coverage: a production security review should still include external-network testing, dependency scanning, and a dedicated penetration test before treating the system as formally security-certified.
