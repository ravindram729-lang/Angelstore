# STEP533 — Recharge Retry Security & Concurrency Hardening

## Scope
Hardened the Failed Recharge retry workflow against duplicate/concurrent retry submissions and branching retry chains.

## Fix
- A Failed recharge can have only one direct child retry attempt.
- Once a child retry exists, the parent attempt cannot be retried again.
- This forces a linear retry chain: Attempt 1 → Attempt 2 → Attempt 3.
- Existing idempotency-key protection remains active.
- UTR uniqueness remains global.
- Payment screenshot SHA-256 duplicate protection remains active.
- Retry remains customer-session and ownership protected.
- Retry still starts `Pending` and receipt generation remains tied to successful completion.

## Targeted verification
- STEP530 audit: 14/14 PASS
- STEP531 audit: 14/14 PASS
- STEP532 E2E: 11/11 PASS
- STEP533 concurrency audit: 17/17 PASS
- STEP533 runtime concurrency E2E: 6/6 PASS

## Concurrency scenario verified
Two simultaneous retry requests against the same Failed recharge using different UTRs, different proof images, and different idempotency keys produce exactly one new child retry (`201`) and one conflict (`409`).

Repeated attempts against the original parent remain blocked after the child exists.

## Static / release verification
- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- `node --check app.js` — PASS
- `npm run check` — PASS
- `FINAL-RELEASE-AUDIT.js` — PASS

## Browser limitation
No fresh live Chromium visual PASS is claimed. Runtime API E2E and release validation were executed.

## Architecture
No cart/order dependency was introduced.
