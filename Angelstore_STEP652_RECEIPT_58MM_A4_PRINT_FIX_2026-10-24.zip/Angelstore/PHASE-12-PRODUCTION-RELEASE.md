# PHASE 12 — Production Release & Deployment Readiness

## Scope
Phase 12 prepares the Phase 11 build for controlled production deployment without changing the existing JSON schema or payment/QC business rules.

## Changes
- Added production deployment runbook.
- Added dependency-free smoke-test script.
- Production configuration errors are logged and startup is blocked after the server binds, preventing an incorrectly configured public instance from remaining online.
- Static responses now include the same baseline security headers used by API responses.
- Added graceful SIGINT/SIGTERM shutdown with a bounded 10-second drain.
- Added malformed-client connection handling.

## Important storage limitation
The application still uses local `data.json`, `backups/`, and `uploads/payments/`. A production host needs persistent storage. If the host is ephemeral, a managed database/object storage migration is required before claiming durable production storage.

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- Local `/api/health` — PASS
- Static admin page — PASS
- Authenticated reports/preflight smoke test — run with local test credentials
- Logout + revoked admin session — PASS
