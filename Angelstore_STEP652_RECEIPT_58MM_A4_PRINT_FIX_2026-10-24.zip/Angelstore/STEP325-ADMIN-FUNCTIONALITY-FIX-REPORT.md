# STEP325 — Admin Panel Functional Fix Report

## Root causes fixed
1. Admin navigation was bound only to sidebar selectors (`#nav [data-page], .side-bottom [data-page]`). Buttons inside page content using `data-page` were dead.
2. Quick-action buttons using `data-open` had no click handler.
3. Finance/operations inline admin API helper used relative `fetch(path)`, which fails when the frontend is hosted separately from the backend (e.g. Netlify + Render).
4. Mobile menu close was not exposed to the global navigation handler.
5. Admin buttons without an explicit `type` could behave like submit buttons when placed inside form-like containers.

## Changes
- `app.js`: added delegated admin navigation for all `[data-page]` buttons and `[data-open]` quick actions.
- `app.js`: content buttons now use the same `go()` routing as the sidebar.
- `admin.html`: admin finance/operations API helper now uses `window.angelApi()` so it uses the configured backend URL, auth header, error handling and session handling.
- `admin.html`: mobile menu close function exposed as `window.closeAdminMobileMenu`.
- `admin.html`: static buttons now explicitly use `type="button"` to prevent accidental form submission/reload.

## Verification
- `node --check app.js` — PASS
- `node --check server.js` — PASS
- Local backend health — PASS
- Admin static page — PASS
- Admin login — PASS
- `/api/admin/preflight` — PASS
- `/api/control-center` — PASS
- `/api/reports` — PASS
- `/api/reports/service` — PASS
- `/api/reports/staff` — PASS
- Admin logout — PASS
- Revoked session rejected — PASS

No database schema or payment-verification workflow was changed.
