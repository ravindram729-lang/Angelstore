# Angelstore STEP384 — Backend/API/Database/Security P2 Fix Report

## Scope
P2 hardening after STEP383. No migration to a new database engine was performed in this step because that is a separate architectural migration requiring a rollback plan.

## Fixed
1. Document upload magic/signature validation for PDF, PNG, JPEG and WEBP on customer and admin document endpoints.
2. OCR concurrency guard with configurable `ANGELSTORE_OCR_MAX_CONCURRENCY` (default 2), preventing unbounded simultaneous Tesseract processes.
3. Manual admin payment date validation; invalid or future dates are rejected.
4. Application category is now canonicalized from the selected service category; client-supplied category cannot create a mismatch.
5. Off-site backup payloads support AES-256-GCM application-level encryption when `ANGELSTORE_OFFSITE_BACKUP_ENCRYPTION_KEY` is configured.
6. Monitoring now raises an explicit warning when off-site backup is configured without application-level encryption.
7. Release package version bumped to 3.0.5.

## Intentionally not changed
- JSON storage → PostgreSQL/SQLite migration: requires a dedicated migration/rollback phase.
- External immutable audit log: requires an external sink/retention policy and should not be improvised inside the current JSON store.
- Distributed rate limiting/session store: requires Redis or another shared service.
- Off-site provider itself: URL/token remain deployment-specific configuration.

## Verification
- `npm run check` — PASS
- `FINAL-RELEASE-AUDIT.js` — PASS; 39 checks
- `PHASE-34-SECURITY-ABUSE-AUDIT.js` — PASS; all abuse cases passed
- Runtime health — HTTP 200
- Unauthenticated protected APIs — 401
- Oversized payload — rejected
- Forged admin bearer — 401
- Guest application rate limit — 429 after threshold

## Deployment requirement
If off-site backup is enabled in production, set `ANGELSTORE_OFFSITE_BACKUP_ENCRYPTION_KEY` to a strong secret and configure the receiving service to decrypt AES-256-GCM envelopes. Without this key, off-site backup remains transport-protected but the monitor reports a warning.
