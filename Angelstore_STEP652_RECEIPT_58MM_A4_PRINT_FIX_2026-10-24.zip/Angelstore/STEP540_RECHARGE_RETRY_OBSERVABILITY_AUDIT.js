const fs=require('fs'),path=require('path');
const server=fs.readFileSync(path.join(__dirname,'server.js'),'utf8');
const checks=[
 ['observability function exists',/function rechargeRetryObservability\(\)/],
 ['counts retry transactions only',/retryRows=recharges\.filter\(r=>r\.source==='customer-recharge-retry'\)/],
 ['tracks status counts',/status_counts:byStatus/],
 ['tracks 24h retry submissions',/attempts_submitted_24h:count\('CUSTOMER_RECHARGE_RETRY_SUBMITTED'\)/],
 ['tracks 24h payment rejection',/payment_rejected_24h:count\('PAYMENT_REJECTED'\)/],
 ['tracks retry idempotency records',/idempotency_records:idems\.length/],
 ['tracks open recovery incidents',/open_recovery_incidents:openIncidents/],
 ['tracks webhook failures',/incident_webhook_failures:webhookFailures/],
 ['monitor snapshot includes observability',/recharge_retry_observability,checked_at:now\(\)/],
 ['admin observability endpoint is protected',/\/api\/admin\/recharge-retry-observability.*admin\(req\)/],
 ['endpoint returns observability snapshot',/\/api\/admin\/recharge-retry-observability.*observability:rechargeRetryObservability\(\)/],
 ['no customer endpoint added for internal metrics',!server.includes("/api/customer/recharge-retry-observability")],
 ['no cart/order dependency introduced',!/api\/admin\/recharge-retry-observability[\s\S]{0,500}(cart|order)/i.test(server)]
];
const evalCheck=(re)=>typeof re==='boolean'?re:re.test(server);
let pass=0;for(const [n,re] of checks){const ok=evalCheck(re);console.log(`${ok?'PASS':'FAIL'} — ${n}`);if(ok)pass++}
const report={step:'STEP540',scope:'Recharge Retry Observability & Production Monitoring',total:checks.length,passed:pass,failed:checks.length-pass,ok:pass===checks.length,checks:checks.map(([name,re])=>({name,ok:evalCheck(re)}))};
fs.writeFileSync(path.join(__dirname,'STEP540_RECHARGE_RETRY_OBSERVABILITY_AUDIT_REPORT.json'),JSON.stringify(report,null,2));
fs.writeFileSync(path.join(__dirname,'STEP540_RECHARGE_RETRY_OBSERVABILITY_AUDIT_REPORT.md'),`# STEP540 — Recharge Retry Observability & Production Monitoring\n\n**${pass}/${checks.length} PASS**\n\n`+checks.map(([n,r],i)=>`${i+1}. **${evalCheck(r)?'PASS':'FAIL'}** — ${n}`).join('\n')+'\n');
process.exit(report.ok?0:1);
