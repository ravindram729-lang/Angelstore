# STEP614 — UPPCL Security + Data Integrity Fix Report

## Scope
Targeted fixes only for UPPCL payment security/data integrity and the previously confirmed multiple-pending-payment blocker.

## Root causes fixed
1. `csrfOk()` existed but was not enforced at the HTTP route boundary. Authenticated state-changing requests could bypass the intended double-submit CSRF check.
2. `/api/customer/uppcl/payment` rejected a second `Pending Verification` payment for the same bill/version, preventing simultaneous independent pending payments.

## Changes
- Enforced `csrfOk(req)` for authenticated state-changing requests at the start of `route()`.
- Removed the single-active-pending UPPCL payment rejection.
- Existing protections remain in place:
  - Customer session required.
  - Admin session required for admin UPPCL endpoints.
  - Customer mobile must match the Admin-approved bill's registered mobile.
  - Bill ID and bill version must match the latest Admin-approved bill.
  - Non-empty duplicate UTR is blocked.
  - Duplicate screenshot hash is blocked.
  - Idempotency key collisions with different payloads are blocked.
  - Payment IDs remain unique.
  - Only verified payments contribute to verified totals.

## Validation
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `node --check customer.js` — PASS
- `node STEP580_AUTH_COOKIE_SECURITY_REGRESSION.js` — 11/11 PASS
- `STEP614_SECURITY_MULTIPLE_PENDING_E2E.js` — PASS:
  - CSRF enforcement
  - Admin bill save
  - Multiple simultaneous pending UPPCL payments
  - Unique payment IDs
  - Customer/account binding

## Deployment
No live deployment was performed.
