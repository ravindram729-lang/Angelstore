# Angelstore STEP425 — Core Architecture / Token Queue / Payment Workflow Fix

## Scope

Fixed only the highest-priority workflow/architecture findings identified in the STEP424 audit. No cart/e-commerce workflow was introduced.

## Authoritative workflow

Service → Application Details → Payment → Manual Payment Verification → Live Token → Documents Upload → Documents Verification → Service Processing → Completed → Receipt (when applicable)

**Documents are NOT a prerequisite for Token generation.**

## Fixes

1. Removed customer and admin required-document gates from Token generation.
2. Customer document upload is server-gated until a valid Live Token exists for the application.
3. Customer current-token responses are service-scoped and sanitized; another customer's name/mobile is not exposed as the live current token.
4. Customer dashboard/records now use the current token for the customer's active service instead of a global current token.
5. Customer frontend queue display now uses backend `ahead_count`, `estimated_wait_minutes`, and `service_average_minutes`; it no longer recalculates queue position from a global queue/localStorage average.
6. Admin Next/Recall active-token checks are service-scoped, allowing separate service queues to operate independently.
7. Payment records now store `payable_amount_snapshot`; Token generation validates the verified payment against the transaction snapshot rather than the current service price.
8. UTR-only or screenshot-only digital payment proof is accepted; both are not required.
9. Customer payment/status messages were updated to match the UTR-or-screenshot rule.
10. E2E regression test was updated to the authoritative Payment → Verification → Token → Documents workflow and the UTR-or-screenshot rule.
11. Admin token issuance follows the same Payment Verified → Token rule as customer issuance.

## Verification

- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `node --check customer.js` — PASS
- `node --check E2E-TEST.js` — PASS
- Fresh isolated runtime `/api/health` — PASS
- Payment with UTR only — PASS
- Payment verification — PASS
- Token generation before document upload — PASS
- Document upload before token — blocked with HTTP 409 — PASS
- Document upload after token — PASS
- Duplicate token — blocked with HTTP 409 — PASS
- Full updated E2E regression — PASS
- Final integrity check — PASS

## Remaining architecture items

Not changed in this step: full database migration, OCR worker architecture, complete appointment lifecycle, offer-to-transaction price binding, release-artifact data sanitization, full service configuration population, accessibility, CSP hardening, and full frontend/backend modularization.
