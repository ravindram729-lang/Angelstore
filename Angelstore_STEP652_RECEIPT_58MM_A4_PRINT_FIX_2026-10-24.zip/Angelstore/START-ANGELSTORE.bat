@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo [ERROR] Node.js nahi mila. Node.js LTS install karein.
  pause
  exit /b 1
)

echo.
echo ============================================
echo   ANGELSTORE CSC - START / SWITCH SERVER
echo ============================================
echo.

echo [1/4] Checking port 8000 and existing Angelstore server...
set "ROOT=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; $root=[IO.Path]::GetFullPath('%ROOT%'); $cs=@(Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue); foreach($c in $cs){ $pid=[int]$c.OwningProcess; if($pid -eq $PID){continue}; $p=Get-CimInstance Win32_Process -Filter ('ProcessId = '+$pid); $cmd=[string]$p.CommandLine; $name=[string]$p.Name; Write-Host ('Found PID '+$pid+' '+$name); Write-Host ('Command: '+$cmd); $isAngel=($name -ieq 'node.exe' -and (($cmd -match '(?i)server\\.js') -or ($cmd -match '(?i)Angelstore') -or ($cmd -like ('*'+$root+'*')))); if($isAngel){ Write-Host ('Stopping existing Angelstore Node server PID '+$pid); Stop-Process -Id $pid -Force; Start-Sleep -Milliseconds 700 } else { Write-Host ('[ERROR] Port 8000 is occupied by a non-Angelstore process (PID '+$pid+').'); exit 2 }}; exit 0" > "%TEMP%\angelstore_port_check.txt" 2>&1
set "PORTCHECK=%ERRORLEVEL%"
type "%TEMP%\angelstore_port_check.txt"
if not "%PORTCHECK%"=="0" (
  echo.
  echo [ERROR] Port 8000 kisi non-Angelstore application ne occupy kiya hai.
  echo Us application ko close karke START-ANGELSTORE.bat dobara chalayein.
  pause
  exit /b 2
)

echo [2/4] Confirming port 8000 is free...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue; if($c){exit 1}else{exit 0}"
if errorlevel 1 (
  echo [ERROR] Port 8000 abhi bhi busy hai. Existing server/process ko close karein.
  pause
  exit /b 2
)

echo [3/4] Removing only stale Angelstore runtime lock...
if exist "angelstore.server.lock" del /f /q "angelstore.server.lock"
if exist "angelstore.server.pid" del /f /q "angelstore.server.pid"

echo [4/4] Starting THIS folder's server...
start "Angelstore CSC Backend" /D "%~dp0" cmd /k node server.js

set READY=0
for /L %%I in (1,1,30) do (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "try{$r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:8000/api/health;if($r.StatusCode -eq 200){exit 0}else{exit 1}}catch{exit 1}" >nul 2>nul
  if not errorlevel 1 (
    set READY=1
    goto READY
  )
  timeout /t 1 /nobreak >nul
)

:READY
if "%READY%"=="0" (
  echo.
  echo [ERROR] Backend 30 seconds me start nahi hua. Backend CMD window me error dekhein.
  pause
  exit /b 1
)

echo.
echo [OK] THIS FOLDER is now serving port 8000.
echo [OK] Admin: http://127.0.0.1:8000/admin
start "Angelstore CSC Admin" http://127.0.0.1:8000/admin#home
start "Angelstore CSC Customer" http://127.0.0.1:8000/customer#home

echo.
echo Portal khul gaya. Backend CMD window band na karein.
endlocal
