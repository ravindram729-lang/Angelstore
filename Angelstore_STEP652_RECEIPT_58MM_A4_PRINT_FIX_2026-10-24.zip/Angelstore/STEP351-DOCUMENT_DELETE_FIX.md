# STEP351 — Document Delete Fix

## Scope
Added secure document deletion to Admin, Staff, and Customer panels while preserving Open/Preview and Download.

## Authorization
- Admin: can delete any document.
- Staff: can delete documents only for their assigned token/application. Verified documents cannot be deleted by Staff.
- Customer: can delete only documents belonging to their own applications. Verified documents cannot be deleted by Customer.
- Unauthenticated DELETE: HTTP 401.

## Storage / Audit
- Deletes the stored document file.
- Removes the document row from `db.documents`.
- Writes `DOCUMENT_DELETED` to the audit log with actor/role/application/document details.

## UI
- Admin: Open / Download / Delete / Verify / Reject
- Staff: Open / Download / Delete / Verify / Reject
- Customer: Download / Delete
- Verified documents show Delete disabled for Staff/Customer.

## Additional correction
Customer document download now sends the existing `X-Customer-Session` session header instead of the stale `angelCustomerToken` localStorage key.
