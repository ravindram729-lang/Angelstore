# STEP341 — Customer Service Progress Meter

## Implemented
- Added authenticated/guest-safe `/api/customer/progress` endpoint.
- Progress is calculated from real application/payment/token/workflow/quality data; no hard-coded percentage.
- Customer UI now shows a percentage meter on Home, Token Generate, and Live Token Status pages.
- Progress checklist includes Payment Verified, Photo, Signature, Documents, Data Cross-check, Submission, Quality Review, and Final Completion.
- Required document progress uses service SOP required-document count and actual uploaded document count.
- Customer progress refreshes automatically while the panel is open.
- Added Hindi/English language-switch dictionary entries for the new progress UI.

## Progress weights
Payment 10%, Photo 10%, Signature 10%, Documents 25%, Data Cross-check 15%, Submission 15%, Quality Review 10%, Final Completion 5%.

Document percentage is proportional to required documents uploaded and is capped at the document stage weight.

## Verification
- `node --check server.js` PASS
- `node --check customer.js` PASS
- `node --check bilingual-ui.js` PASS
- Duplicate HTML IDs check PASS
- Local API smoke test for `/api/customer/progress` PASS; sample application returned 0% with 3 required documents and all pending stages.
