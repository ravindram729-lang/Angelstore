# STEP432 — Server Instance / Login 500 Fix

## Root cause
The local login endpoint returned HTTP 500 when more than one Angelstore Node server process shared the same `data.json`. The storage layer correctly detected an optimistic-revision conflict, but the second process could still start and later turn that conflict into a generic `Server error`.

## Fix
A storage-root scoped server-instance lock is now acquired before monitoring/server startup. A second process using the same storage root exits with a clear message instead of sharing the database. Stale lock files are recovered when their recorded PID no longer exists.

## Admin credential
Local admin credential remains the requested account:
- username: `ravindram143`
- password: `Love@143`

## Verification
- `node --check server.js` PASS
- Fresh single-instance login test PASS
- Duplicate server startup is rejected cleanly
- Login no longer reaches the concurrent-write 500 path when the project is run as a single server instance.
