# STEP493 — Token Queue Conflict UI & Real-Time Panel Consistency

## Scope
Harden the Admin and Staff Token Queue panels so a stale/competing action produces a clear conflict response and refreshes the affected panel, without changing the approved visual design, core buttons, cart-free workflow, payment workflow, or server-authoritative token state.

## Root causes addressed
1. STEP492 already rejected stale token actions with HTTP 409, but Admin token actions displayed only the raw error and did not explicitly refresh the queue before the next action.
2. Staff task API converted non-2xx responses into plain Error objects, losing the HTTP status needed to distinguish a stale-state conflict from ordinary errors.
3. Staff stale-action conflicts did not explicitly reload the task list and could leave the visible task row behind the server state.

## Fixes
- Admin `tokenAction()` now detects HTTP 409 conflicts, reloads `/api/tokens`, and tells the operator that the latest queue state is now loaded.
- Staff `api()` now preserves `response.status` and response JSON on errors.
- Staff task action handler now detects HTTP 409, refreshes the task list, and displays a temporary conflict message.
- Existing STEP492 server-side `state_revision` and `request_id` protections remain authoritative.
- Existing action busy locks remain in place.
- No new workflow button was introduced.

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `node --check customer.js` — PASS
- STEP493 targeted UI/conflict test — PASS (7/7)
- STEP492 concurrency regression — PASS (8/8)
- STEP491 live-refresh regression — PASS (7/7)
- P0/P1 regression — PASS
- ZIP integrity — PASS

## Browser verification limitation
No fresh click-by-click Chromium visual PASS is claimed because the execution environment blocks normal localhost navigation. Verification uses source-level UI assertions plus isolated HTTP/API workflow tests.

## Production gate
This is a local implementation and regression verification PASS. Production configuration, live host availability, and real browser verification on the deployed domains remain separate operational gates.
