# Phase A — Public Customer Home + Root Route Fix

## Scope
- Added a real `index.html` public Angelstore CSC landing page.
- Changed backend `/` static mapping from `admin.html` to `index.html`.
- Kept existing customer/admin/staff panels unchanged in this phase.
- No database/data migration or destructive data change.

## Public routes
- `/` → public customer home
- `/index.html` → public customer home
- `/customer.html` → existing Customer Portal
- `/admin.html` → existing Admin panel
- `/staff.html` → existing Staff panel

## Verification
- `node --check server.js` PASS
- `node --check app.js` PASS
- `node --check storage.js` PASS
- `GET /` → 200 HTML
- `GET /index.html` → 200 HTML
- `GET /customer.html` → 200 HTML
- `GET /admin.html` → 200 HTML
- `GET /staff.html` → 200 HTML
- `GET /api/health` → 200

## Important
Customer optional-login / guest workflow is deliberately not claimed complete in this phase. That is the next phase and requires a separate backend-safe guest workflow rather than bypassing customer authentication.
