# STEP521 — Receipt PDF + Print Workflow

## Scope
Hardened the Customer **Receipt & Records** workflow on top of STEP518 without changing the payment verification or token architecture.

## Implemented
- Added **View Receipt** action for completed receipts.
- Added **Print** action with a print-ready receipt document and browser **Print / Save PDF** control.
- Kept **PDF Download** action backed by the existing authenticated `/api/customer/receipts/:id.pdf` endpoint.
- Receipt view includes Receipt No., Application ID, Token No., Customer, Mobile, Service, Amount, Payment Status, Payment Method, UTR/Reference, Completed At and Service Status.
- Receipt actions are available from both the receipt table and the available-receipts strip.
- Mobile layout keeps receipt actions usable without horizontal overflow.
- Existing customer-session ownership check and completed-receipt gate remain intact.
- Existing idempotent receipt-number generation remains intact; no duplicate receipt generation was introduced.

## Verification
- `node --check customer.js` — PASS
- `node --check server.js` — PASS
- STEP521 Receipt PDF + Print workflow audit — **10/10 PASS**
- STEP503 Receipt & Records regression — **10/10 PASS**
- STEP502 Customer Service ETA regression — **7/7 PASS**
- `npm run check` — PASS
- ZIP integrity — verified after packaging

## Browser limitation
No fresh live Chromium click-by-click PASS is claimed from this local environment. The workflow was statically/runtime-hook audited and the existing regression suites were executed.

## Rules preserved
- Manual payment verification remains unchanged.
- Receipt remains tied to a completed eligible service with verified payment.
- Customer receipt access remains session-protected and customer-scoped.
- No cart/order workflow was introduced.
