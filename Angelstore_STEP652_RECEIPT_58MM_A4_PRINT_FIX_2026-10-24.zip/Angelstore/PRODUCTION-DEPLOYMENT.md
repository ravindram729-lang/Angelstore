# Angelstore CSC — Production Deployment Guide (Phase 12)

## 1. Required environment
Set these variables in the hosting provider. Never commit real values to Git.

- `NODE_ENV=production`
- `PORT` — supplied by the host when applicable
- `ANGELSTORE_ADMIN_USER` — dedicated admin username
- `ANGELSTORE_ADMIN_PASS` — strong password, at least 12 characters
- `ANGELSTORE_AUTH_SECRET` — random secret, at least 32 characters; 64+ recommended
- `ANGELSTORE_CORS_ORIGIN` — exact HTTPS frontend origin, never `*`
- `ANGELSTORE_STORAGE_DIR` — persistent-disk mount for `data.json`, backups and payment proofs; required in production

The backend blocks production startup when these requirements are not met.

## 2. Start command
`npm start`

No external npm dependencies are required by the current backend.

## 3. Health check
Use `GET /api/health` as the hosting health check. A correctly configured production instance returns HTTP 200 and `ok: true`.

## 4. Persistent storage requirement
The current application uses a local JSON database (`data.json`) plus backups and payment-proof uploads. Phase 25 makes the storage root configurable through `ANGELSTORE_STORAGE_DIR`; by default these files live under the application directory for local use.

For production, `ANGELSTORE_STORAGE_DIR` must point to a host-provided persistent disk. The application also accepts `ANGELSTORE_UPLOAD_DIR` and `ANGELSTORE_BACKUP_DIR` overrides, but they should normally remain under the persistent storage root. If the host has no persistent disk, do not treat this JSON backend as durable production storage; migrate to a managed database/object store instead.

Admin can inspect the configured paths and file counts through authenticated `GET /api/admin/storage-status`. This endpoint does not expose database contents.

The JSON write path now uses an atomic temp-file rename with `fsync` before replacement, reducing corruption risk during process interruption. This improves durability but does not create persistence on an ephemeral host.

## 5. HTTPS
Terminate TLS at the hosting provider. Do not expose plain HTTP directly to the public internet. HSTS is emitted in production responses.

## 6. Payment verification
UPI/Bank payments remain manual: UTR + screenshot/proof + admin verification. No automatic bank verification was added.

## 7. Backup policy
Create and test backups before deployment changes. Restore creates a pre-restore safety backup. Store an additional copy outside the application server for disaster recovery.

## 8. Release procedure
1. Confirm `ANGELSTORE_STORAGE_DIR` is mounted on persistent storage.
2. Take a backup of `data.json`, `backups/`, and `uploads/payments/` (or their configured storage directories).
3. Deploy the exact release zip.
4. Set all production environment variables, including `ANGELSTORE_STORAGE_DIR`.
5. Start the server.
6. Verify `/api/health` is HTTP 200 and authenticated `/api/admin/storage-status` reports the persistent paths.
7. Run `node SMOKE-TEST.js` against the deployment URL with test credentials only.
8. Test admin login/logout, customer login, staff login, payment verification, QC gate, reports, and backup/restore using controlled test records.
9. Only then direct real customers to the service.
