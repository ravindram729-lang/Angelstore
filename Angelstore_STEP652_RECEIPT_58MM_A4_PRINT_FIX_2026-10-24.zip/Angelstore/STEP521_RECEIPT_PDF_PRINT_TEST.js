const fs=require('fs');
const assert=(c,m)=>{if(!c)throw new Error(m)};
const html=fs.readFileSync('customer.html','utf8');
const js=fs.readFileSync('customer.js','utf8');
const server=fs.readFileSync('server.js','utf8');
const checks=[
 ['receipt page has View Receipt action',js.includes("receipt-view")],
 ['receipt page has Print action',js.includes("receipt-print")],
 ['receipt PDF action remains wired',js.includes('downloadReceiptPdf(Number(b.dataset.id))')],
 ['receipt view renderer exists',js.includes('function openReceiptView(id,d)')],
 ['print renderer exists',js.includes('function printReceipt(id,d)')],
 ['receipt fields include application/token/customer/service/amount',js.includes('Application ID')&&js.includes('Token No.')&&js.includes('Customer')&&js.includes('Service')&&js.includes('Total Amount')],
 ['customer receipt endpoint remains session protected',server.includes("/api/customer/receipts/")&&server.includes('customerSession(req)')],
 ['receipt endpoint uses completed receipt lookup',server.includes('findCompletedReceipt(id)')],
 ['duplicate receipt generation remains idempotent',server.includes("pay.receipt_no=pay.receipt_no||'RCP-" )],
 ['responsive receipt actions exist',html.includes('.cr-receipt-actions')&&html.includes('@media(max-width:720px)')]
];
checks.forEach(([m,c],i)=>{assert(c,m);console.log(`PASS ${i+1}/10 ${m}`)});
console.log('STEP521 RECEIPT PDF + PRINT WORKFLOW AUDIT: 10/10 PASS');
