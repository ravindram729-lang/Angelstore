const fs=require('fs'),path=require('path'),os=require('os'),{spawn}=require('child_process');
const root=__dirname,temp=fs.mkdtempSync(path.join(os.tmpdir(),'angelstore-step472-')),now=new Date().toISOString(),day=now.slice(0,10);
const data={
 payments:[{id:1,name:'A',mobile:'9876543210',amount:100,method:'UPI',utr:'R1',status:'Verified',service:'PAN Card',official_fee:30,staff_commission:10,payment_charge:2,staff_id:'S1',created_at:now,receipt_no:'RCP-00000001',completed_at:now,completed_by:'S1'}],
 tokens:[{id:10,token:'T001',name:'A',mobile:'9876543210',service:'PAN Card',status:'पूर्ण',created_at:now,date:day,payment_id:1,application_id:5,completed_at:now}],
 applications:[{id:5,application_id:'APP-5',name:'A',mobile:'9876543210',service:'PAN Card',status:'Completed'}],
 financial_ledger:[{id:'L1',event_id:'E1',event_type:'PAYMENT_VERIFIED',payment_id:1,amount:100,status:'Verified',created_at:now,prev_hash:'',hash:'bad'}],
 staff_settlements:[{id:7,settlement_id:'SET-7',staff_id:'S1',from:day,to:day,base_salary:500,commission:10,home_allowance:20,delivery_allowance:5,advances:0,net_payable:535,status:'pending'}],
 staff:[{staff_id:'S1',employee_id:'E1',name:'Staff One',status:'active'}],expenses:[],commissions:[],recharge_transactions:[],customers:[],audit:[],notifications:[],documents:[]
};
fs.writeFileSync(path.join(temp,'data.json'),JSON.stringify(data,null,2));
const port=8772,env={...process.env,PORT:String(port),HOST:'127.0.0.1',ANGELSTORE_STORAGE_DIR:temp,ANGELSTORE_ADMIN_USER:'step472admin',ANGELSTORE_ADMIN_PASS:'Step472SecurePass!92',ANGELSTORE_AUTH_SECRET:'step472-auth-secret-012345678901234567890123',ANGELSTORE_CORS_ORIGIN:'http://127.0.0.1:'+port};
const child=spawn(process.execPath,[path.join(root,'server.js')],{cwd:root,env,stdio:['ignore','pipe','pipe']});let out='';child.stdout.on('data',d=>out+=d);child.stderr.on('data',d=>out+=d);const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function req(url,opt={}){for(let i=0;i<30;i++){try{const r=await fetch('http://127.0.0.1:'+port+url,opt);const b=await r.arrayBuffer();return {status:r.status,headers:r.headers,buf:Buffer.from(b),text:()=>r.text()}}catch{await sleep(100)}}throw Error('server unavailable '+out.slice(-500))}
(async()=>{try{await sleep(500);let r=await req('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'step472admin',password:'Step472SecurePass!92'})});if(r.status!==200)throw Error('login failed');const raw=r.headers.get('set-cookie')||'';const jar=raw.split(/, (?=[^;,]+=)/).map(v=>v.split(';')[0]).filter(Boolean).join('; ');if(!jar.includes('angel_admin='))throw Error('admin cookie missing');const h={Cookie:jar};
 r=await req('/api/admin/financial-report.pdf?from='+day+'&to='+day,{headers:h});if(r.status!==200||r.headers.get('content-type')!=='application/pdf'||!r.buf.subarray(0,5).toString().startsWith('%PDF-'))throw Error('financial PDF failed');
 r=await req('/api/admin/settlement.pdf?id=7',{headers:h});if(r.status!==200||r.headers.get('content-type')!=='application/pdf'||!r.buf.subarray(0,5).toString().startsWith('%PDF-'))throw Error('settlement PDF failed');
 r=await req('/api/admin/receipts/1.pdf',{headers:h});if(r.status!==200||r.headers.get('content-type')!=='application/pdf'||!r.buf.subarray(0,5).toString().startsWith('%PDF-'))throw Error('receipt PDF failed');
 console.log(JSON.stringify({ok:true,checks:{admin_login:true,financial_report_pdf:true,settlement_pdf:true,receipt_pdf:true,pdf_signatures:true}},null,2));
}catch(e){console.error(JSON.stringify({ok:false,error:e.message,output:out.slice(-1200)},null,2));process.exitCode=1}finally{child.kill('SIGTERM');setTimeout(()=>fs.rmSync(temp,{recursive:true,force:true}),200)}})();
