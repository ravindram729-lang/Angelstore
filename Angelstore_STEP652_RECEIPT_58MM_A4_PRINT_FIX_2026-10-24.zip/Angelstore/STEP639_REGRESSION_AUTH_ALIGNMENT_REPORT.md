# STEP639 — Regression Test Authentication Alignment

Scope: align the regression gate with the current HttpOnly cookie + CSRF customer/admin authentication model without changing application business logic.

## Canonical regression test
`STEP639_CURRENT_COOKIE_AUTH_REGRESSION_TEST.js`

Verified:
- Admin login establishes `angel_admin` HttpOnly session cookie.
- Customer registration establishes `angel_customer` HttpOnly session cookie and CSRF token.
- Customer `/api/customer/me` works from the cookie session.
- Customer application can be created from cookie session.
- Admin payment verification works from cookie-authenticated admin session.
- Customer token generation works from cookie session after verified payment.
- Customer token readback works from cookie session.
- Admin queue readback works from cookie session.
- Unauthenticated customer token access is rejected with 401.

Result: **6/6 PASS**.

Note: legacy STEP488–STEP502 artifacts that explicitly depend on the retired `access_token` / `X-Customer-Session` response model are retained for historical traceability. STEP639 establishes the current authentication regression gate and package script; those historical files are not deleted or rewritten in this step.
