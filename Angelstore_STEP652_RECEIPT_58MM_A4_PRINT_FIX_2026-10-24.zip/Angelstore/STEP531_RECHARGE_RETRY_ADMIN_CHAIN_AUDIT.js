const fs=require('fs');const path=require('path');
const root=__dirname, server=fs.readFileSync(path.join(root,'server.js'),'utf8'), admin=fs.readFileSync(path.join(root,'admin.html'),'utf8');
const checks=[
 ['admin recharge API exposes attempt chain','attempt_chain:chain.map' ],
 ['attempt chain grouped by retry group','Number(z.retry_group_id||z.id)===rootId'],
 ['attempt metadata exposes payment status','payment_status:pay?.status||null'],
 ['attempt metadata exposes receipt number','receipt_no:pay?.receipt_no||null'],
 ['retry parent link retained','retry_of_recharge_id:z.retry_of_recharge_id||null'],
 ['customer retry remains failed-only','if(source.status!==\'Failed\')'],
 ['new retry starts pending','status:\'Pending\''],
 ['admin UI shows attempt number','Attempt #'],
 ['admin UI shows retry parent','retry of #'],
 ['admin UI shows receipt state','No receipt'],
 ['admin failure action captures reason','Failure reason दर्ज करें'],
 ['admin status transition uses lifecycle guard','lifecycleCanMove(RECHARGE_LIFECYCLE,row.status,status)'],
 ['success still requires verified payment','linkedPayment.status!==\'Verified\''],
 ['no cart/order dependency in retry flow','recharge-retry']
];
let pass=0;for(const [name,needle] of checks){if(server.includes(needle)||admin.includes(needle)){console.log('PASS',name);pass++}else console.log('FAIL',name)}
console.log(`STEP531 AUDIT: ${pass}/${checks.length} PASS`);process.exit(pass===checks.length?0:1);
