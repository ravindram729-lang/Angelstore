# Phase 28 — Off-site Backup + Scheduled Recovery

## Implemented
- Manual admin backups now use the managed backup path.
- Optional off-site POST upload via `ANGELSTORE_OFFSITE_BACKUP_URL`.
- Optional bearer token via `ANGELSTORE_OFFSITE_BACKUP_TOKEN`.
- Backup bundle contains database + payment proof files + SHA-256 checksums.
- Scheduled backups can be enabled with `ANGELSTORE_SCHEDULED_BACKUP=true`.
- Interval is configurable with `ANGELSTORE_BACKUP_INTERVAL_HOURS` (minimum 1 hour).
- Local retention is configurable with `ANGELSTORE_BACKUP_RETENTION` (default 14).
- Old local backup snapshots are pruned after a new managed backup succeeds.
- Admin endpoint `/api/admin/backup-status` reports schedule, retention, off-site configuration, and latest local backup.
- No real external provider credentials were added.

## Off-site endpoint contract
The configured HTTPS endpoint receives a POST JSON document:
- `backup`: backup filename
- `created_at`: ISO timestamp
- `database`: full Angelstore database snapshot
- `payment_proofs[]`: `{name, content_type, base64, sha256}`

The endpoint should verify the bearer token (if configured), verify each SHA-256 checksum, store the payload in durable storage, and return HTTP 2xx only after the backup is durably accepted.

## Important limitation
This phase provides a provider-neutral off-site interface. It does not pretend that a real S3/Google Drive/Dropbox destination exists without credentials and an actual configured endpoint.

For production, use a separate storage system/account from the Render persistent disk and restrict the backup endpoint to authenticated HTTPS requests.
