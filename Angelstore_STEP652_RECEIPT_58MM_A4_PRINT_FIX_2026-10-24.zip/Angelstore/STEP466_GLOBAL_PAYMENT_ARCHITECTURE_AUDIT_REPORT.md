# STEP466 — Global Payment Architecture Audit & Hardening

## Scope

Audited the shared manual payment path, customer mobile-recharge payment path, and recharge processing state transitions after the UPPCL hardening work.

## Findings fixed

1. **Shared `/api/payments` lacked a common idempotency contract.**
   - Added optional `Idempotency-Key` / `idempotency_key` handling for the shared manual-payment endpoint.
   - Same key + same payload returns the existing payment.
   - Same key + different payload returns HTTP 409.
   - Existing UTR duplicate protection remains active.

2. **Customer recharge payment lacked idempotency and could create duplicate Application + Payment + Recharge records on retry.**
   - Customer recharge submit now requires an idempotency key.
   - The key is persisted in `payment_idempotency` with a payload fingerprint and linked payment/recharge/application IDs.
   - Same retry returns the existing payment/recharge pair.
   - Payload mutation with the same key is rejected with HTTP 409.
   - Frontend keeps the key during a failed request so a network retry can safely reuse it; the key is cleared only after a successful response.

3. **Recharge status transitions were too permissive.**
   - `Success` is now terminal.
   - `Failed` is now terminal.
   - Repeating the same status is rejected.
   - Customer-linked recharge can reach `Success` only when its linked payment is `Verified`.

## Data model addition

`db.payment_idempotency` is initialized migration-safely, so existing databases continue to load without a schema migration step.

## Targeted E2E verification

`STEP466_GLOBAL_PAYMENT_ARCHITECTURE_E2E.js` passed all checks:

- Shared manual payment same-key retry returns the same payment.
- Shared manual payment same-key payload conflict is blocked.
- Recharge same-key retry returns the same Payment + Recharge pair.
- Recharge same-key payload conflict is blocked.
- Recharge cannot be marked Success before payment verification.
- Successful recharge is terminal.
- Failed recharge is terminal.
- Idempotency records persist.

## Regression / release checks

- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- `npm run release-audit` — PASS

The repository's generic `P0-P1-REGRESSION-TEST.js` was not run from the release archive because this release package does not contain the historical `data.json` fixture that script requires. No PASS claim is made for that fixture-dependent command in STEP466.

## Browser limitation

No fresh live Chromium visual PASS is claimed because the environment's localhost browser access remains restricted. The STEP466 E2E uses isolated temporary storage and direct HTTP API execution.
