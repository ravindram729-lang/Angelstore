# STEP507 — Token Generate Reference Gap/Layout Fix

## Scope
Updated the Customer Token Generate page to more closely match the supplied final reference image while preserving existing token/payment/document runtime IDs and handlers.

## Root-cause findings
1. The previous STEP506 grid placed Payment Proof on grid row 4 while the left Amount section ended on row 3, creating an avoidable vertical dead-space in the right column.
2. The "Token मिलने के बाद क्या होगा?" card was placed on row 3 while Payment Proof was on row 4, so the visual rhythm did not match the reference.
3. Generated Token was sharing the right-side row structure instead of behaving as a later full-width result area.
4. The reference expects the desktop rhythm: left Step 1/2/3/6 aligned with right Payment/Proof/Next Workflow, with Generated Token appearing after the primary workflow.

## Fix
- Payment Method card: desktop grid row 1–2 on the right.
- Payment Proof: row 3 on the right, aligned with Payable Amount.
- Next Workflow: row 4 on the right, aligned with Documents.
- Documents: row 4 on the left.
- Generated Token: row 5 full-width.
- Explicit desktop rows are reset to automatic single-column flow below 820px.
- Existing payment form, token controls, document gate, ETA/live queue and API IDs remain unchanged.
- Four payment methods remain usable without desktop clipping.

## Verification
- STEP507 targeted reference gap test: **12/12 PASS**
- STEP504 Token reference regression: **10/10 PASS**
- STEP502 Customer ETA regression: **7/7 PASS**
- STEP503 Receipt & Records regression: **10/10 PASS**
- `node --check server.js`: PASS
- `node --check customer.js`: PASS
- `node --check app.js`: PASS
- ZIP integrity: PASS

## Visual verification note
The supplied screenshot was used as the design baseline. Automated source/structure/regression checks passed. No fresh browser click-by-click PASS is claimed from this run.
