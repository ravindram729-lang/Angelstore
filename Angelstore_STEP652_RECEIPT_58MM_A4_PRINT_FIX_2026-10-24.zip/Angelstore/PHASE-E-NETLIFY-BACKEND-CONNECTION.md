# PHASE E — Netlify + Backend Connection

## Scope
This phase connects the current Angelstore frontend deployment to the existing Node backend without changing the database schema or payment workflow.

### Production frontend
- Netlify: `https://eloquent-tulumba-26fd2e.netlify.app`

### Production backend configured in the frontend
- Render: `https://angelstore-csc-project4.onrender.com`

## Changes made
1. `app.js`
   - Added one explicit production backend constant.
   - Netlify/angelcsc.in frontend hosts use the Render backend by default.
   - Local/file mode continues to use `http://127.0.0.1:8000`.
2. `customer.html`
   - Fixed the production default: previously a Netlify customer page used `location.origin`, which would send `/api/*` requests back to Netlify instead of the Node backend.
   - Netlify/angelcsc.in now use the same Render backend as the main app.
3. Saved `angelBackendUrl` remains supported for intentional overrides; local/file mode clears stale remote overrides.

## Required Render environment variables
Set these in the backend hosting environment; do not commit real values:

- `NODE_ENV=production`
- `PORT` — hosting platform supplied value is acceptable.
- `ANGELSTORE_ADMIN_USER` — real admin username.
- `ANGELSTORE_ADMIN_PASS` — real admin password, minimum 12 characters.
- `ANGELSTORE_AUTH_SECRET` — random secret, minimum 32 characters.
- `ANGELSTORE_CORS_ORIGIN=https://eloquent-tulumba-26fd2e.netlify.app`

If a custom production frontend domain is later used, change `ANGELSTORE_CORS_ORIGIN` to that exact HTTPS origin.

## Netlify deployment
The frontend is static. Publish the project directory containing `index.html`, `customer.html`, `admin.html`, `staff.html`, `app.js`, `style.css`, and `service-catalog.js`.

The Node backend files must **not** be treated as a Netlify static API. The backend remains a separate Node service (for example, Render).

## Verification performed in this environment
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- Static inspection confirmed both admin/main and customer frontend production defaults point to the same Render backend.

## Not verified here
External DNS/network access is unavailable in this execution environment, so the live Netlify URL and live Render `/api/health` endpoint could not be contacted from here. Therefore this phase does **not** claim that the deployed services are currently online or that Render CORS environment variables are already set.

## Browser smoke test after deployment
1. Open Netlify home.
2. Open Customer page and check that services load.
3. Open Admin page and login.
4. In browser DevTools → Network, confirm API requests go to `angelstore-csc-project4.onrender.com`, not `eloquent-tulumba-26fd2e.netlify.app/api/...`.
5. Confirm `OPTIONS`/API requests are not blocked by CORS.
6. Test guest application, payment proof submission, customer login, admin payment verification, and token generation.
7. Confirm payment screenshot remains admin-only.

## Data safety
No database schema migration was introduced in Phase E. No existing JSON data is included in the release archive.
