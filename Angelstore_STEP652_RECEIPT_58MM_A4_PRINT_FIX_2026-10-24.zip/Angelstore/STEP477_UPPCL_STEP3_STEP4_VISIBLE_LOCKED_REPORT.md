# STEP477 — UPPCL Steps 3 & 4 Visible Workflow

## Scope
Updated the STEP476 UPPCL customer workflow so Steps 3 and 4 are present in the desktop two-column workflow from the initial page state, while remaining locked until an Admin-approved bill is loaded.

## UI
- Step 3 — UPI से भुगतान करें remains visible beside Step 4.
- Step 4 — भुगतान की जानकारी दर्ज करें remains visible beside Step 3.
- Locked state is visually muted and non-interactive.
- Clear lock guidance explains that Step 2 must load an Admin-approved bill first.
- After a valid bill lookup, Steps 3 and 4 automatically unlock.
- Existing Step 3 UPI/QR workflow is preserved.
- Existing Step 4 UTR + screenshot validation is preserved.
- Mobile/tablet responsive stacking is preserved.

## Workflow safety
No payment or proof action is enabled before the Admin-approved bill lookup succeeds.

## Verification
- `node --check customer.js` — PASS
- `node --check server.js` — PASS
- `npm run release-audit` — PASS
- ZIP integrity — PASS
- No cart/order workflow introduced.
- No live-browser visual PASS claimed.
