# PHASE 26 — Render Production Configuration Audit

## Scope
Audited the Phase 25 build for Render Web Service deployment and persistent storage. No business workflow or database schema changes were made.

## Findings
1. Render web services need the process to listen on the host-provided port and public interface. The server now explicitly binds to `0.0.0.0` while retaining the `PORT` environment variable.
2. Render filesystems are ephemeral by default. The application already supports `ANGELSTORE_STORAGE_DIR`; this phase adds a ready-to-review `render.yaml` that mounts `/var/data/angelstore` and points the application at it. Render documents that only files under the disk mount path persist across deploys/restarts.
3. Render HTTP health checks can use `/api/health`; the Blueprint now declares that path.
4. Production secrets are not committed. The Blueprint uses `sync: false` for admin username/password and `generateValue: true` for the auth secret.
5. CORS is explicitly pinned to the current Netlify origin.

## Render configuration added
- Runtime: Node
- Plan: `starter` because Render persistent disks are not available on the Free plan.
- Build: `npm install`
- Start: `npm start`
- Health check: `/api/health`
- Persistent disk: 1 GB at `/var/data/angelstore`
- `ANGELSTORE_STORAGE_DIR=/var/data/angelstore`
- `ANGELSTORE_CORS_ORIGIN=https://eloquent-tulumba-26fd2e.netlify.app`

## Important limitation
The Blueprint is configuration-as-code; it does not prove that the existing Render service has actually been updated. That requires access to the Render workspace/service or a successful live network check. This environment could not resolve the supplied Render/Netlify hostnames, so live deployment status was not claimed.

## Manual Render verification
1. Open the existing Render web service.
2. Confirm it is a Node web service and start command is `npm start`.
3. Attach a persistent disk at `/var/data/angelstore` (1 GB minimum for this configuration).
4. Set `NODE_ENV=production`.
5. Set `ANGELSTORE_CORS_ORIGIN` exactly to the Netlify origin.
6. Set strong admin credentials and `ANGELSTORE_AUTH_SECRET`.
7. Set `ANGELSTORE_STORAGE_DIR=/var/data/angelstore`.
8. Set HTTP health check path to `/api/health`.
9. Deploy and confirm `/api/health` returns HTTP 200.
10. Log in as admin and check `GET /api/admin/storage-status`; confirm all persistent paths are under `/var/data/angelstore`.
11. Create a controlled test record, restart/redeploy, and verify the record and payment proof remain available.

## Verification performed locally
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `node --check storage.js` — PASS
- `render.yaml` syntax/field review against current Render Blueprint documentation — PASS
- Production-style startup with `PORT`, CORS, secrets and persistent storage — PASS
- HTTP health endpoint — PASS
- Storage persistence across process restart — PASS
- Public unauthenticated storage status remains protected — PASS

## External references
Render Persistent Disks: https://render.com/docs/disks
Render Web Services: https://render.com/docs/web-services
Render Health Checks: https://render.com/docs/health-checks
Render Blueprint Reference: https://render.com/docs/blueprint-spec
