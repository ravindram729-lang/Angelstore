const fs=require('fs');
const path=require('path');
const server=fs.readFileSync(path.join(__dirname,'server.js'),'utf8');
const customer=fs.readFileSync(path.join(__dirname,'customer.js'),'utf8');
const checks=[
 ['customer session required',/const c=customerAccess\(req\);if\(!c\)return json\(res,401/.test(server)],
 ['retry ownership enforced',/source\.customer_id&&c\.customer_id[\s\S]*?String\(source\.mobile\)===String\(c\.mobile\)/.test(server)],
 ['retry only Failed source',/if\(source\.status!==['"]Failed['"]\)return json\(res,409/.test(server)],
 ['retry rate limited',/rechargeRetryAttempts=new Map\(\)/.test(server)&&/retryLimit=12/.test(server)&&/return json\(res,429/.test(server)],
 ['UTR charset and length restricted server-side',/function validUtr\(u\)\{return \/\^\[A-Za-z0-9\._\\-\/\]\{6,50\}\$\/.test\(String\(u\|\|''\)\)\}/.test(server)&&/if\(utr&&!validUtr\(utr\)\)/.test(server)],
 ['idempotency conflict protected',/existingIdem\?\.conflict\)return json\(res,409/.test(server)],
 ['idempotent replay precedes child guard',/if\(existingIdem\?\.payment_id\)[\s\S]*?const childRetry=/.test(server)],
 ['linear retry child guard',/const childRetry=\(db\.recharge_transactions\|\|\[\]\)\.find/.test(server)],
 ['duplicate UTR blocked',/db\.payments\.some\(p=>String\(p\.utr\|\|'\'\)\.toLowerCase\(\)===utr\.toLowerCase\(\)\)/.test(server)],
 ['proof validated by MIME and magic bytes',/safeImage\(x\.screenshot\)/.test(server)&&/Valid PNG\/JPEG\/WEBP/.test(server)&&/buf\.subarray\(0,8\)/.test(server)],
 ['proof max 5MB',/buf\.length>5\*1024\*1024/.test(server)],
 ['proof SHA-256 duplicate protection',/duplicateProof=db\.payments\.some/.test(server)&&/crypto\.createHash\('sha256'\)/.test(server)],
 ['old failed attempt immutable/no receipt generation on retry creation',/retry_of_recharge_id:source\.id/.test(server)&&/receipt_no:null/.test(server)],
 ['success requires verified payment',/status==='Success'&&row\.payment_id[\s\S]*?linkedPayment\.status!=='Verified'/.test(server)],
 ['no cart/order dependency in retry endpoint',!/cart|order/i.test(server.match(/if\(p==='\/api\/customer\/recharge\/retry'[\s\S]*?(?=\n    if\(p===)/)?.[0]||'')],
 ['frontend retry endpoint uses idempotency key',/idempotency_key:key/.test(customer)]
];
let pass=0;for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} — ${name}`);if(ok)pass++;}
const report={step:'STEP537',total:checks.length,passed:pass,failed:checks.length-pass,ok:pass===checks.length,checks:checks.map(([name,ok])=>({name,ok}))};
fs.writeFileSync(path.join(__dirname,'STEP537_RECHARGE_RETRY_SECURITY_ABUSE_AUDIT_REPORT.md'),`# STEP537 — Recharge Retry Security & Abuse Hardening Audit\n\n${pass}/${checks.length} PASS\n\n`+checks.map(([n,o],i)=>`${i+1}. **${o?'PASS':'FAIL'}** — ${n}`).join('\n')+'\n');
fs.writeFileSync(path.join(__dirname,'STEP537_RECHARGE_RETRY_SECURITY_ABUSE_AUDIT_REPORT.json'),JSON.stringify(report,null,2));
process.exit(report.ok?0:1);
