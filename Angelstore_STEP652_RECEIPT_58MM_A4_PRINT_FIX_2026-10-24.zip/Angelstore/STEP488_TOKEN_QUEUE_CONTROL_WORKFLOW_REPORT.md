# STEP488 — Token Queue Control Workflow Hardening

## Scope
Harden Admin Token & Queue controls without changing the approved visual design, colors, core buttons, tools, or business workflow.

## Root-cause findings
1. `Recall` was exposed in the Admin UI for a token already in `बुलाया` (Called) state, but the backend transition table only allowed transitions *to* `बुलाया` from other states. Clicking Recall on an already-called token therefore returned an error.
2. A held token had no explicit Resume presentation. The existing Start Work action could resume it through the backend transition, but the label remained `काम शुरू करें`, which was ambiguous.
3. Hold/Delay/Recall controls were visually available in states where the action was not valid.

## Fixes
- Recall now supports re-calling an already-called token and increments `recall_count`.
- Recall creates a customer notification and audit trail.
- `Start Work` changes to `Resume` when the current token is on Hold.
- Hold, Delay and Recall controls are disabled when their current state does not support the action.
- Existing backend state machine, queue ordering, priority, staff assignment, transfer, no-show, cancel, QC and completion rules remain unchanged.

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- STEP487 queue metrics test — PASS
- Targeted Recall/Resume/invalid-control-state test — PASS
- P0/P1 regression — PASS
- Final release audit — PASS
- Isolated token workflow E2E — PASS
- Duplicate token protection — PASS
- Payment → Token → Queue → Staff → QC → Completion → Receipt — PASS

## Production gates
Live deployment reachability and host-specific production configuration remain separate deployment gates.
