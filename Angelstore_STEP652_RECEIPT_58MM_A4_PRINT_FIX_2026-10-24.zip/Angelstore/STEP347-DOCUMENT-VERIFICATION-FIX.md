# STEP347 — Document Verification & Secure Viewer

## Problem found
Customer progress already counted required documents, but Admin/Staff did not have a secure UI to open the uploaded document file. The existing `/api/documents` GET endpoint returned metadata only, and `/uploads/` is intentionally blocked from direct static access.

## Changes
- Added secure `GET /api/workflow/documents?token_id=...` endpoint.
  - Admin can view documents for any token/application.
  - Staff can view documents only for their assigned token/application.
- Added secure `GET /api/documents/:id/file` endpoint.
  - Requires Admin bearer session or Staff session.
  - Validates document ownership/assignment before serving the file.
  - Records `DOCUMENT_VIEWED` audit event.
- Added `POST /api/documents/:id/status` endpoint.
  - `uploaded` / `verified` / `rejected`.
  - Verified documents cannot be downgraded.
  - Records reviewer and review note.
- Admin Token Management → `काम का विवरण` now has `📄 Documents देखें`.
- Admin can Open / Verify / Reject each document.
- Staff Assigned Tasks now has `📄 Documents`.
- Staff can Open / Verify / Reject documents for their assigned token only.

## Intended flow
Customer uploads → document stored against Application ID → Token references Application → Admin/Staff opens Documents → verifies readability/validity → Quality Review → Complete.

## Security
Direct `/uploads/` static access remains blocked. Documents are served only through authenticated endpoints.

## Validation
- `node --check server.js` PASS
- Embedded Admin JavaScript syntax checks PASS
- Staff JavaScript syntax check PASS
