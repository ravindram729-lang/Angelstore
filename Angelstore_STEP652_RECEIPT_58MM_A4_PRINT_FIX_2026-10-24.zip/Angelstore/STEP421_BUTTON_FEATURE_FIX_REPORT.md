# STEP421 — Customer Button & Feature Fix Report

## Root-cause fixes
- Removed stale `#refreshStatus` event binding from `customer.js`; the existing `#refreshMyToken` control remains the Refresh Status action.
- Fixed Live Token Status receipt button logic so it enables only when the current completed service has a receipt and opens the customer receipt PDF.
- Fixed customer payment-method selector: UPI, QR Code, Bank Transfer and CSC Cash are now interactive buttons.
- Customer payment method is submitted to the backend instead of always being hard-coded as UPI.
- Customer payment submission now accepts **UTR OR payment screenshot** for digital methods; both are no longer mandatory.
- CSC Cash can be submitted without UTR/screenshot and remains Pending Verification for manual admin verification.

## Verification
- `node --check customer.js` — PASS
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- Static customer JS selector audit — PASS; no missing direct `#id` references.
- Local backend `/api/health` on test port — PASS.
- Customer application + UTR-only payment submission — PASS (returns Pending Verification).
- Customer application + Cash payment submission without proof — PASS (returns Pending Verification).

## Note
The repository's existing E2E runner still stops at its Admin Login step when pointed at the pre-existing local server. This was not used as a reason to claim full end-to-end production verification.
