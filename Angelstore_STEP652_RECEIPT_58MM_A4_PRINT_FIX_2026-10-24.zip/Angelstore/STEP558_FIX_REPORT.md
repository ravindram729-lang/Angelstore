# STEP558 — Priority Fix / Tools / Features / Working Button Verification

Date: 2026-10-06

## Fixes applied

1. **Production release artifact cleanup**
   - Removed bundled runtime `data.json` from the release artifact.
   - Runtime storage still creates/uses `data.json` under `ANGELSTORE_STORAGE_DIR`.
   - This removes stale runtime incident data from the shipped source package.

2. **Database transaction rollback hardening**
   - `withDbTransaction()` now deep-clones affected collections with `structuredClone()` before mutation.
   - Rollback can therefore restore nested object mutations, not only the array structure.

3. **JSON request body byte-limit hardening**
   - Added an explicit 15 MiB byte limit (`MAX_JSON_BODY_BYTES`).
   - Payload size is now measured from Buffer bytes instead of JavaScript string length.

4. **HTTP server timeout hardening**
   - Request timeout: 120 seconds.
   - Headers timeout: 15 seconds.
   - Keep-alive timeout: 5 seconds.
   - Maximum requests per socket: 1000.

5. **Transaction integrity audit update**
   - STEP538 audit now verifies the deep-clone transaction implementation.
   - No production logic was weakened to satisfy the audit.

## Verification after fixes

- JavaScript syntax: PASS
- Customer/Admin/Staff button + workflow audit: 16/16 PASS
- P0/P1 regression: PASS
- Recharge retry E2E: 11/11 PASS
- Recharge retry concurrency: 6/6 PASS
- Recharge retry lifecycle: 20/20 PASS
- Recharge retry security/abuse: PASS
- Recharge retry transaction integrity: 14/14 PASS
- Recovery/crash consistency: PASS
- Observability: PASS
- Admin resilience: 12/12 PASS
- Admin monitoring keyboard/focus: 12/12 PASS
- Admin monitoring contrast/semantics: 12/12 PASS
- Admin monitoring responsive: 15/15 PASS
- STEP480 release gate: bundled `data.json` blocker removed.

## Not fixed / not claimable yet

1. Production host secrets/environment are not available inside this local audit environment.
2. Live deployment verification could not be completed because external deployment domains were inaccessible from the audit environment.
3. Actual Render persistent-disk behavior must still be verified on the deployed service.
4. Off-site backup receiver/encryption and alert webhook require real production configuration if those operational features are required.
5. The application still uses JSON-file persistence rather than a production database.
6. Customer/staff session tokens are still stored in browser localStorage; migrating to secure HttpOnly cookies remains a separate security hardening task.
7. Customer session lifetime remains 30 days; shortening/rotation policy remains a separate decision.
8. OCR remains an in-process Tesseract worker/queue and depends on the host OCR runtime.
9. Backend/frontend remain substantially monolithic and have not been refactored merely for architecture aesthetics.
10. Historical audit reports are evidence only; current regression results above are the acceptance evidence for this fix cycle.

## Release verdict

**NOT YET PRODUCTION VERIFIED.**

The source-level fixes in this cycle are verified. Production readiness still depends on real host configuration and live deployment verification.
