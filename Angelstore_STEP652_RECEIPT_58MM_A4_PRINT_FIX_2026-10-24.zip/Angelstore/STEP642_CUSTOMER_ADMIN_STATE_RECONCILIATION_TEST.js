const fs=require('fs');
const src=fs.readFileSync('customer.js','utf8');
const checks=[
 ['server dashboard is authoritative',/Server dashboard is authoritative/],
 ['stale payment id is reconciled',/reconcileId\('angelPaymentId',dashboardPayments\)/],
 ['stale UPPCL id is reconciled',/reconcileId\('angelUppclPaymentId',dashboardPayments\)/],
 ['stale application id is reconciled',/reconcileId\('angelApplicationId',dashboardApplications\)/],
 ['stale token id is cleared',/removeItem\('angelCurrentTokenId'\)/],
 ['documents gate follows token validity',/syncTokenDocumentsGate\(false\)/]
];
let pass=0; for(const [n,re] of checks){if(re.test(src)){console.log('PASS',n);pass++;}else console.log('FAIL',n)}
console.log(`STEP642 ${pass}/${checks.length} PASS`); process.exit(pass===checks.length?0:1);
