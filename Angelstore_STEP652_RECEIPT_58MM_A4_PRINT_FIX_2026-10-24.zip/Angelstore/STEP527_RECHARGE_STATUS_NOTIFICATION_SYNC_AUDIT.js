const fs=require('fs');
const server=fs.readFileSync('server.js','utf8');
const customer=fs.readFileSync('customer.js','utf8');
const checks=[
 ['Customer records exposes recharge transactions',/const recharges=\(db\.recharge_transactions\|\|\[\]\)\.filter\(x=>x\.customer_id===c\.customer_id\|\|x\.mobile===c\.mobile\)\.map\(customerRecharge\)/.test(server)],
 ['Recharge status rendered as Pending/Completed/Failed',/const label=success\?'Completed':failed\?'Failed':'Pending'/.test(customer)],
 ['Receipt shown only for successful recharge',/const receipt=success\?payment\?\.receipt_no\|\|''/.test(customer)],
 ['Recharge details action exists',/class="receipt-action recharge-detail"/.test(customer)],
 ['Recharge notifications have dedicated icon/type support',/recharge:'📱'/.test(customer)],
 ['Notification changes can refresh customer records',/changed&&rows\.some\(n=>String\(n\.type\|\|'\'\)===\'recharge\'/.test(customer)],
 ['Recharge notification links open Receipt & Records',/data-open-records="1"/.test(customer)&&/go\('customer-receipts'\)/.test(customer)],
 ['No cart/order dependency introduced',!/(cart|order)/i.test(customer.match(/STEP527[\s\S]{0,500}/)?.[0]||'')]
];
let pass=0;for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} — ${name}`);if(ok)pass++;}
console.log(`STEP527 AUDIT: ${pass}/${checks.length} PASS`);process.exit(pass===checks.length?0:1);
