# STEP354 — Quality Review Gate Fix

## Requirement
Final Quality Review must be a real gate. Staff may prepare/submit the checklist, but Staff must not be able to final-pass their own work. Admin must perform the final PASS/REJECT decision.

## Changes
- Staff Quality Review now stores `submitted` / `needs_review` instead of granting `passed`.
- Admin-only final PASS is enforced server-side.
- Admin PASS requires all required checklist items to be checked.
- If the service defines required documents, those documents must be verified before PASS.
- If a linked payment exists, it must be `Verified` before PASS.
- Admin can REJECT a review only with a mandatory rejection reason.
- Rejection stores audit information and moves the application to `Correction Required`.
- Quality review records now contain review stage, reviewer, timestamps and rejection reason where applicable.
- Added `/api/admin/quality-review` for the Admin Control Center pending-review list.
- Admin Control Center now exposes pending Quality Reviews and a Review action.
- Staff UI now tells the operator that the review was submitted to Admin instead of claiming PASS.
- Completion remains blocked until the server-side Admin Quality Review status is `passed`.
- Automatic receipt generation remains behind the completion gate.

## Verification
- `node --check server.js` — PASS
- `node --check app.js` — PASS
- `node --check E2E-TEST.js` — PASS
- Clean-storage E2E — PASS
  - Staff submits Quality Review
  - Staff cannot complete before Admin QC
  - Required documents uploaded and Admin-verified
  - Admin final Quality Review PASS
  - Staff completion succeeds only after Admin PASS
  - Automatic receipt generated after completion
  - Reports/control/finance pass
  - Final integrity pass
  - Session revocation checks pass

## Important
This verifies the local clean-storage application workflow. A real hosted production browser click-through still requires the deployed environment to be tested separately.
