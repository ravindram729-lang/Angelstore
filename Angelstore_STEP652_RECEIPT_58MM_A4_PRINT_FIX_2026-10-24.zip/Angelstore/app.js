const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const escapeHtml=v=>String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
const titles={control:'Admin Control Center',home:'Home',services:'सभी सेवाएँ',charges:'Service Charges','custom-services':'Custom Services',sop:'SOP & Quality Control',detail:'सेवा विवरण',request:'ऑनलाइन सेवा अनुरोध',tokens:'टोकन सिस्टम',tokenmgmt:'टोकन प्रबंधन',status:'Live Token Display',customers:'Customer Management',payments:'Payment Dashboard',recharge:'Recharge Management','uppcl-control':'UPPCL Control Panel',reports:'Reports & Analytics',notifications:'Notifications / Updates',livecontent:'LIVE SCREEN Manager',staff:'Staff Management',operations:'Home Service & Delivery',finance:'Finance & Profit',settings:'Settings',monitoring:'Monitoring & Incidents',preflight:'Production Readiness Audit',business:'Business Management',security:'Security & Audit',workflow:'Service Workflow Config',admin:'Admin Dashboard'};
const FALLBACK_SERVICES=[['🪪','आधार सेवाएँ',20,'popular'],['💳','पैन सेवाएँ',8,'popular'],['📜','प्रमाण पत्र सेवाएँ',12,'gov'],['🏦','बैंकिंग सेवाएँ',15,'popular'],['🌱','किसान सेवाएँ',18,'gov'],['🛡️','बीमा सेवाएँ',10,'digital'],['🧾','टैक्स एवं GST',12,'gov'],['🎓','शिक्षा एवं छात्र',15,'digital'],['🚙','यातायात सेवाएँ',10,'digital'],['🚗','वाहन सेवाएँ',12,'digital'],['🏠','संपत्ति एवं भूमि',8,'gov'],['⚖️','कानूनी सेवाएँ',9,'gov'],['❤️','स्वास्थ्य सेवाएँ',8,'gov'],['🔎','डिजिटल सेवाएँ',10,'digital'],['👨‍💼','अन्य नागरिक सेवाएँ',5,'new'],['📱','मोबाइल रिचार्ज',6,'digital'],['💡','बिजली बिल भुगतान',7,'digital'],['🚰','पानी बिल भुगतान',5,'digital'],['✈️','यात्रा टिकट',4,'digital'],['🏛️','सरकारी योजना',14,'gov'],['🧑‍💻','ई-गवर्नेंस सेवाएँ',11,'new'],['📮','डाक एवं कुरियर',4,'digital'],['💰','पेंशन सेवाएँ',6,'gov'],['👨‍👩‍👧','परिवार रजिस्टर',5,'gov']];
let services=FALLBACK_SERVICES, backendServiceCatalog=[], SERVICE_CATALOG_BY_CATEGORY={}, role=(document.body?.dataset.panel==='admin'?'admin':'customer'), currentUser=null, currentCustomer=null;
const BACKEND_KEY='angelBackendUrl';
const BACKEND_PRODUCTION_URL='https://angelstore-csc-project4.onrender.com';
const NETLIFY_FRONTEND_URL='https://eloquent-tulumba-26fd2e.netlify.app';
const host=location.hostname;
const isProductionFrontend=host.endsWith('angelcsc.in')||host.endsWith('netlify.app');
const SAVED_BACKEND=(localStorage.getItem(BACKEND_KEY)||'').trim();
const IS_FILE_PAGE=location.protocol==='file:';
const IS_LOCAL_PAGE=location.hostname==='127.0.0.1'||location.hostname==='localhost';
const BACKEND_DEFAULT=(IS_FILE_PAGE||IS_LOCAL_PAGE)?'http://127.0.0.1:8000':(isProductionFrontend?BACKEND_PRODUCTION_URL:'');
// Never let a stale saved Render/remote URL override the local backend when the app is opened from disk.
let backendUrl=(IS_FILE_PAGE||IS_LOCAL_PAGE)?BACKEND_DEFAULT:(SAVED_BACKEND||BACKEND_DEFAULT);
if(IS_FILE_PAGE && SAVED_BACKEND && SAVED_BACKEND!==BACKEND_DEFAULT) localStorage.removeItem(BACKEND_KEY);
const LOCAL_MODE=false;
// If opened directly from disk, transparently switch to the local server when it is running.
// This also prevents a stale saved Render URL from breaking local login.
if(IS_FILE_PAGE){
  fetch('http://127.0.0.1:8000/api/health',{cache:'no-store'}).then(r=>{
    if(r.ok){
      const target=location.pathname.toLowerCase().endsWith('customer.html')?'customer.html':'admin.html';
      location.replace('http://127.0.0.1:8000/'+target);
    }
  }).catch(()=>{});
}
function localRead(k,d){try{return JSON.parse(localStorage.getItem(k)||JSON.stringify(d))}catch{return d}}
function toast(msg,type='info'){
  const text=String(msg??'');
  if(typeof window.showToast==='function' && window.showToast!==toast){
    try{return window.showToast(text,type)}catch{}
  }
  const el=document.getElementById('toast');
  if(!el){console[type==='error'?'error':'log'](text);return;}
  el.textContent=text;
  el.className='show '+type;
  el.setAttribute('role','status');
  el.hidden=false;
  clearTimeout(window.__angelToastTimer);
  window.__angelToastTimer=setTimeout(()=>{el.className='';el.hidden=true;},3500);
}
function localWrite(k,v){localStorage.setItem(k,JSON.stringify(v));return v}
function localId(){return Date.now()+Math.floor(Math.random()*1000)}
async function localApi(){throw new Error('Local fallback API disabled. Start the Angelstore backend and use the configured API.')}
function showAdminLogin(message=''){clearStaff();$('#app')?.classList.add('hidden');$('#adminAuth')?.classList.remove('hidden');$('#loginUser')?.focus();if(message)$('#adminAuth small')?.setAttribute('title',message)}
window.handleAdminUnauthorized=()=>showAdminLogin('Session expired or invalid');
async function api(path,opts={}){if(LOCAL_MODE)return localApi(path,opts);if(!backendUrl)throw new Error('Backend URL सेट नहीं है।');const headers={...(opts.body instanceof FormData?{}:{'Content-Type':'application/json'}),...(opts.headers||{})};const csrf=document.cookie.match(/(?:^|;\s*)angel_csrf=([^;]+)/)?.[1];if(csrf&&['POST','PUT','PATCH','DELETE'].includes(String(opts.method||'GET').toUpperCase()))headers['X-CSRF-Token']=decodeURIComponent(csrf);let r;try{r=await fetch(backendUrl.replace(/\/$/,'')+path,{...opts,headers,credentials:'include'})}catch(e){throw new Error('Backend से connection नहीं हो रहा। Render API URL या CORS settings जाँचें.')}let d={};try{d=await r.json()}catch{}if(r.status===401&&!path.startsWith('/api/auth/login')&&(role==='admin'||path.startsWith('/api/admin/'))){showAdminLogin('Admin session expired या invalid है। कृपया दोबारा login करें।');const e=new Error('Admin session मान्य नहीं है। सुरक्षा के लिए दोबारा login करें, फिर Recharge Plan सेव करें।');e.status=401;e.silent=true;throw e}if(!r.ok){const e=new Error(d.error||('Backend request failed ('+r.status+')'));e.status=r.status;throw e}return d}
window.angelApi=api;
function go(page,syncHash=true){
  const target=document.getElementById('page-'+page);
  if(!target)return;
  document.querySelectorAll('.page').forEach(x=>x.classList.remove('active-page'));
  target.classList.add('active-page');
  document.querySelectorAll('#nav [data-page],.side-bottom [data-page]').forEach(x=>x.classList.toggle('active',x.dataset.page===page));
  const crumb=document.getElementById('crumb'); if(crumb)crumb.textContent=titles[page]||page;
  try{localStorage.setItem('angelAdminPage',page)}catch{}
  if(syncHash && location.hash !== '#'+page){history.pushState(null,'','#'+page)}
  loadPageData(page);
  if(page==='operations'&&window.angelLoadOps)window.angelLoadOps();
  if(page==='finance'&&window.angelLoadFinance)window.angelLoadFinance();
}
function bindAdminNavigation(){
  if(document.body?.dataset.panel!=='admin')return;
  const bind=()=>document.querySelectorAll('[data-page]').forEach(b=>{
    if(b.dataset.boundNav==='1')return;
    const page=b.dataset.page;
    if(!page)return;
    b.dataset.boundNav='1';
    b.addEventListener('click',e=>{e.preventDefault();go(page);if(page==='security')loadSecurityAudit(); if(window.closeAdminMobileMenu)window.closeAdminMobileMenu()});
  });
  bind();
  if(!window.__angelPageDelegation){
    window.__angelPageDelegation=true;
    document.addEventListener('click',e=>{
      const pageBtn=e.target.closest?.('[data-page]');
      if(pageBtn && document.body?.dataset.panel==='admin'){e.preventDefault();go(pageBtn.dataset.page);window.closeAdminMobileMenu?.();return;}
      const openBtn=e.target.closest?.('[data-open]');
      if(openBtn && document.body?.dataset.panel==='admin'){
        e.preventDefault();
        const page=openBtn.dataset.open;
        const name=openBtn.dataset.service;
        if(page==='detail' && name){
          const svc=services.find(x=>x[1]===name);
          if(svc){openPublicServiceDetails(svc);renderDetailPage(svc);$('#reqCat').value=svc[1];syncCustomerServiceControls();}
        }
        go(page);
      }
    });
  }
  const hash=location.hash.replace(/^#/,'');
  const saved=localStorage.getItem('angelAdminPage');
  if(hash&&document.getElementById('page-'+hash))go(hash,false);
  else if(saved&&document.getElementById('page-'+saved))go(saved);
  else go('home');
  if(!window.__angelAdminHashBound){
    window.__angelAdminHashBound=true;
    window.addEventListener('hashchange',()=>{const p=location.hash.replace(/^#/,'');if(p&&document.getElementById('page-'+p))go(p,false)});
  }
}
async function verifyAdminSession(){try{await api('/api/tokens');currentUser={name:localStorage.getItem('angelStaffName')||'Admin',role:'admin'};$('#adminAuth')?.classList.add('hidden');$('#app')?.classList.remove('hidden');applyRoleAccess();go('admin');return true}catch(e){if(e?.status===401||e?.silent)return false;showAdminLogin();return false}}
async function customerApi(path,opts={}){if(LOCAL_MODE)return localApi(path,opts);const headers={...(opts.headers||{})};const csrf=document.cookie.match(/(?:^|;\s*)angel_csrf=([^;]+)/)?.[1];if(csrf&&['POST','PUT','PATCH','DELETE'].includes(String(opts.method||'GET').toUpperCase()))headers['X-CSRF-Token']=decodeURIComponent(csrf);if(!(opts.body instanceof FormData))headers['Content-Type']='application/json';let r=await fetch(backendUrl.replace(/\/$/,'')+path,{...opts,headers,credentials:'include'});let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||('Backend request failed ('+r.status+')'));return d}
function openAdmin(){location.href='admin.html'}
function closeAdmin(){$('#adminAuth')?.classList.add('hidden')}
function openCustomer(){
  $('#customerAuth')?.classList.remove('hidden');
}
function closeCustomer(){$('#customerAuth')?.classList.add('hidden')}
if($('#adminLoginTop'))$('#adminLoginTop').onclick=openAdmin;if($('#closeAdminAuth'))$('#closeAdminAuth').onclick=closeAdmin;if($('#customerLoginTop'))$('#customerLoginTop').onclick=openCustomer;if($('#customerLoginHero'))$('#customerLoginHero').onclick=openCustomer;if($('#browseServicesBtn'))$('#browseServicesBtn').onclick=()=>document.querySelector('#public-services')?.scrollIntoView({behavior:'smooth'});
if($('#customerLogoutTop'))$('#customerLogoutTop').onclick=()=>{localStorage.removeItem('angelCustomerLocal');localStorage.removeItem('angelCustomerLogin');currentCustomer=null;updateCustomerButton();['reqName','reqMobile','tokenName','tokenMobile'].forEach(id=>{if($('#'+id))$('#'+id).value=''});toast('Customer logout सफल हुआ')};
if($('#closeCustomerAuth'))$('#closeCustomerAuth').onclick=closeCustomer;if($('#closePublicDetail'))$('#closePublicDetail').onclick=()=>$('#publicDetailModal').classList.add('hidden');if($('#closePublicDetail2'))$('#closePublicDetail2').onclick=()=>$('#publicDetailModal').classList.add('hidden');$$('.link-btn').forEach(b=>b.onclick=()=>{const requested=b.dataset.service||b.textContent.trim();const target=services.find(x=>x[1]===requested)||services.find(x=>x[1]&&b.textContent.includes(x[1]));if(target){renderDetailPage(target);go('detail')}else{go('services');if($('#serviceSearch'))$('#serviceSearch').value=requested;renderServices('all',requested)}});$('#publicDetailApply').onclick=()=>{const cat=$('#publicDetailTitle').textContent.trim();const info=selectedPublicService?.info||getServiceInfo(cat,services.find(x=>x[1]===cat));const sub=selectedPublicService?.sub||info?.services?.[0];if(!sub)return toast('Individual service चुनें');$('#publicDetailModal').classList.add('hidden');$('#reqService').value=cat+' — '+sub.name;$('#reqCat').value=cat;$('#tokenService').value=cat+' — '+sub.name;go('request');toast('Service चुनी गई — अब नाम और मोबाइल भरें');};
if($('#customerLoginTab'))$('#customerLoginTab').onclick=()=>{$('#customerLoginTab').classList.add('sel');$('#customerRegisterTab').classList.remove('sel');$('#customerLoginForm').classList.remove('hidden');$('#customerRegisterForm').classList.add('hidden')};
if($('#customerRegisterTab'))$('#customerRegisterTab').onclick=()=>{$('#customerRegisterTab').classList.add('sel');$('#customerLoginTab').classList.remove('sel');$('#customerRegisterForm').classList.remove('hidden');$('#customerLoginForm').classList.add('hidden')};
function setStaffSession(d){role='admin';currentUser=d?.user||{name:'Admin',role:'admin'}}
function clearStaff(){['angelLogin','angelRole','angelStaffName'].forEach(k=>localStorage.removeItem(k));role='';currentUser=null}
function applyRoleAccess(){const r=role||'customer';const name=currentUser?.name||currentCustomer?.name||'Customer';const u=$('.user');if(u)u.innerHTML='👤 '+escapeHtml(name)+' <span>· '+escapeHtml(r.toUpperCase())+'</span>';const rules={admin:['control','home','services','charges','sop','detail','request','tokens','tokenmgmt','status','customers','payments','control','reports','staff','operations','finance','notifications','livecontent','settings','monitoring','preflight','business','security','workflow','custom-services','admin'],customer:['home','services','detail','request','tokens','status']};const allowed=rules[r]||rules.customer;$$('#nav [data-page],.side-bottom [data-page]').forEach(b=>b.style.display=allowed.includes(b.dataset.page)?'':'none')}
$('#adminLoginForm')?.addEventListener('submit',async(e)=>{e.preventDefault();const btn=$('#loginBtn');try{btn.disabled=true;const d=await api('/api/auth/login',{method:'POST',body:JSON.stringify({username:$('#loginUser').value.trim(),password:$('#loginPass').value})});setStaffSession(d.user);$('#adminAuth')?.classList.add('hidden');$('#app')?.classList.remove('hidden');applyRoleAccess();go('admin');toast('Admin login सफल हुआ')}catch(e){toast(e.message)}finally{btn.disabled=false}})
if($('#logout'))$('#logout').onclick=async()=>{if(role==='admin'){try{await api('/api/auth/logout',{method:'POST'})}catch{} clearStaff();location.href='index.html'}else{customerLogout();location.reload()}};
$('#changeAdminPassword')?.addEventListener('click',async()=>{const current=$('#adminCurrentPassword')?.value||'',next=$('#adminNewPassword')?.value||'',confirm=$('#adminConfirmPassword')?.value||'';if(!current||!next||!confirm)return toast('तीनों password fields भरें');try{const d=await api('/api/auth/password',{method:'POST',body:JSON.stringify({current_password:current,new_password:next,confirm_password:confirm})});if(d.relogin_required){clearStaff();alert('Password बदल गया। सुरक्षा के लिए फिर से login करें।');location.reload()}}catch(e){toast(e.message)}});
if($('#customerRegisterBtn'))$('#customerRegisterBtn').onclick=()=>location.href='customer.html';
if($('#customerLoginBtn'))$('#customerLoginBtn').onclick=()=>location.href='customer.html';
function updateCustomerButton(){const logged=!!localStorage.getItem('angelCustomerLocal');const b=$('#customerLoginTop'),lo=$('#customerLogoutTop');if(b){b.textContent=logged?(currentCustomer?.name?('Customer: '+currentCustomer.name):'Customer Logged In'):'Customer Login';b.classList.toggle('hidden',false)}if(lo)lo.classList.toggle('hidden',!logged)}
function syncCustomerServiceControls(){const service=$('#reqService')?.value||'';populateTokenServices(service);if($('#tokenService')&&service)$('#tokenService').value=service;}

function customerLogout(){localStorage.removeItem('angelCustomerLogin');currentCustomer=null;updateCustomerButton();['reqName','reqMobile','tokenName','tokenMobile'].forEach(id=>{if($('#'+id))$('#'+id).value=''});toast('Customer logout सफल हुआ')}
function fillCustomer(c){if(!c)return;['reqName','tokenName'].forEach(id=>{if($( '#'+id)&&!$('#'+id).value)$('#'+id).value=c.name});['reqMobile','tokenMobile'].forEach(id=>{if($('#'+id)&&!$('#'+id).value)$('#'+id).value=c.mobile})}
function serviceFromApi(x){
 const fallback=FALLBACK_SERVICES.find(v=>v[1]===x.category);
 return [fallback?.[0]||'◉',x.category,Array.isArray(x.services)?x.services.length:0,fallback?.[3]||'digital',Number(fallback?.[4]||0),fallback?.[5]||''];
}
async function loadServiceCatalog(){
 try{
   const d=await api('/api/services');
   const rows=Array.isArray(d.services)?d.services:[];
   if(!rows.length)throw new Error('Service catalog खाली है');
   backendServiceCatalog=rows;window.angelBackendServiceCatalog=rows;
   SERVICE_CATALOG_BY_CATEGORY=Object.fromEntries(rows.map(x=>[x.category,Array.isArray(x.services)?x.services:[]]));
   services=rows.map(serviceFromApi);
   return true;
 }catch(e){
   backendServiceCatalog=[];
   SERVICE_CATALOG_BY_CATEGORY={};
   services=FALLBACK_SERVICES;
   console.warn('Service catalog API unavailable; using audited fallback catalog',e?.message||e);
   return false;
 }
}
const CATEGORY_ICONS={'आधार सेवाएँ':'icon-01.png','पैन सेवाएँ':'icon-07.png','प्रमाण पत्र सेवाएँ':'icon-12.png','बैंकिंग सेवाएँ':'icon-08.png','किसान सेवाएँ':'icon-11.png','बीमा सेवाएँ':'icon-17.png','टैक्स एवं GST':'icon-24.png','शिक्षा एवं छात्र':'icon-28.png','यातायात सेवाएँ':'icon-16.png','वाहन सेवाएँ':'icon-16.png','संपत्ति एवं भूमि':'icon-10.png','कानूनी सेवाएँ':'icon-33.png','स्वास्थ्य सेवाएँ':'icon-15.png','डिजिटल सेवाएँ':'icon-32.png','अन्य नागरिक सेवाएँ':'icon-36.png','मोबाइल रिचार्ज':'icon-19.png','बिजली बिल भुगतान':'icon-21.png','पानी बिल भुगतान':'icon-23.png','यात्रा टिकट':'icon-31.png','सरकारी योजना':'icon-11.png','ई-गवर्नेंस सेवाएँ':'icon-32.png','डाक एवं कुरियर':'icon-35.png','पेंशन सेवाएँ':'icon-18.png','परिवार रजिस्टर':'icon-03.png'};
function renderServices(filter='all',q=''){const grid=$('#serviceGrid');if(!grid)return;const s=services.filter(x=>(filter==='all'||x[3]===filter)&&x[1].toLowerCase().includes(q.toLowerCase()));grid.innerHTML=s.map(x=>`<article class="service" data-service="${escapeHtml(x[1])}"><div class="icon"><img src="assets/service-icons/${CATEGORY_ICONS[x[1]]||'icon-32.png'}" alt="${escapeHtml(x[1])}" style="width:76px;height:76px;object-fit:contain" onerror="this.onerror=null;this.src='assets/service-icons/icon-32.png'"></div><h3>${escapeHtml(x[1])}</h3><small>सेवा विवरण और शुल्क देखें</small><div><span class="tag">${x[3]==='popular'?'लोकप्रिय':x[3]==='new'?'नया':x[3]==='gov'?'सरकारी':'डिजिटल'}</span></div></article>`).join('')||'<div class="panel">कोई सेवा नहीं मिली।</div>';
$$('#serviceGrid .service').forEach(el=>el.onclick=()=>{const n=el.dataset.service;const svc=services.find(x=>x[1]===n);if(svc){openPublicServiceDetails(svc);renderDetailPage(svc);$('#reqCat').value=svc[1];syncCustomerServiceControls()}})}
const SERVICE_INFO={
'आधार सेवाएँ':{services:[
{name:'Aadhaar demographic update',csc:0,govt:'₹75 (UIDAI fee; separate update)',docs:['Aadhaar number/card','Mobile number','Address/identity proof, as applicable'],process:['सेवा और दस्तावेज़ verify करें','अधिकृत Aadhaar workflow में details दर्ज करें','आवश्यक verification पूरा करें','Acknowledgement/receipt दें']},
{name:'Aadhaar biometric update',csc:0,govt:'₹125 (UIDAI fee; MBU age exemptions apply)',docs:['Aadhaar number/card','Mobile number','Biometric verification'],process:['Update type verify करें','अधिकृत centre workflow में request दर्ज करें','Biometric verification पूरा करें','Acknowledgement दें']},
{name:'Aadhaar print / download assistance',csc:0,govt:'Download free; A4 colour print ₹40 at Aadhaar centre (where applicable)',docs:['Aadhaar number/VID','Registered mobile for OTP where required'],process:['Identity details verify करें','Download/print करें','Customer को copy/receipt दें']},
{name:'Aadhaar PVC order assistance',csc:0,govt:'₹75 (UIDAI PVC order, inclusive of GST & speed post)',docs:['Aadhaar number/VID','Registered mobile for OTP'],process:['PVC order details verify करें','Portal order complete करें','Order/reference customer को दें']}
],process:['सही Aadhaar service चुनें','Eligibility और documents verify करें','अधिकृत portal/centre process पूरा करें','Receipt/acknowledgement सुरक्षित रखें'],note:'Aadhaar की official UIDAI fee दिखायी गई है; authorised Aadhaar centre पर अतिरिक्त/मनमाना Aadhaar charge न जोड़ें।'},
'पैन सेवाएँ':{services:[
{name:'New PAN application',csc:50,govt:'₹107 (domestic physical PAN, portal charge)',docs:['Aadhaar/ID proof','Address proof','Date of birth proof','Photo/signature as required'],process:['PAN application type चुनें','KYC details भरें','Documents submit करें','Acknowledgement/reference दें']},
{name:'PAN correction / update',csc:50,govt:'₹107 (domestic physical PAN, portal charge)',docs:['Existing PAN','Corrected ID/address/DOB proof as applicable','Photo/signature if required'],process:['Existing PAN verify करें','Correction fields update करें','Documents submit करें','Acknowledgement रखें']},
{name:'PAN e-PAN download / print',csc:20,govt:'Portal charge as applicable',docs:['PAN number','Registered mobile/email as required'],process:['PAN details verify करें','Official portal से e-PAN प्राप्त करें','Print/download customer को दें']},
{name:'PAN reprint assistance',csc:40,govt:'Portal charge as applicable',docs:['PAN number','ID/KYC details as required'],process:['Reprint request verify करें','Portal request submit करें','Reference/receipt दें']}
],process:['PAN service type चुनें','KYC और documents verify करें','Authorised PAN portal process पूरा करें','Acknowledgement सुरक्षित रखें']},
'प्रमाण पत्र सेवाएँ':{services:[
{name:'Income Certificate application',csc:50,govt:'राज्य/पोर्टल अनुसार',docs:['ID proof','Address proof','Income proof/self-declaration as required'],process:['राज्य portal और eligibility verify करें','Form भरें','Documents upload करें','Application number दें']},
{name:'Caste Certificate application',csc:50,govt:'राज्य/पोर्टल अनुसार',docs:['ID proof','Address/residence proof','Caste/relationship/supporting records as applicable'],process:['Eligibility verify करें','Application भरें','Supporting documents submit करें','Status/reference दें']},
{name:'Residence / Domicile Certificate',csc:50,govt:'राज्य/पोर्टल अनुसार',docs:['ID proof','Residence proof','Local supporting document as applicable'],process:['Residence eligibility verify करें','Application submit करें','Acknowledgement/reference दें']},
{name:'Birth / Death Certificate assistance',csc:50,govt:'नगर/पोर्टल अनुसार',docs:['Applicant ID','Hospital/local record or registration details as applicable'],process:['Record details verify करें','Correction/application request भरें','Documents submit करें','Receipt/reference दें']}
],process:['संबंधित राज्य/स्थानीय portal और पात्रता verify करें','Form और documents submit करें','Application/reference सुरक्षित रखें']},
'बैंकिंग सेवाएँ':{services:[
{name:'Bank account opening assistance',csc:50,govt:'₹0 bank portal fee; bank terms apply',docs:['Aadhaar/ID','PAN where required','Mobile number','Address/KYC documents'],process:['Bank/product और KYC requirements verify करें','Authorised banking workflow में form भरें','KYC complete करें','Reference दें']},
{name:'Bank statement / transaction print',csc:20,govt:'Bank policy अनुसार',docs:['Account number/customer ID','ID proof where required'],process:['Account details verify करें','Authorised channel से statement प्राप्त करें','Print/reference दें']},
{name:'KYC / profile update assistance',csc:40,govt:'Bank policy अनुसार',docs:['Account details','Valid KYC/ID/address proof'],process:['Required update verify करें','Authorised bank workflow में submit करें','Acknowledgement दें']},
{name:'Banking form / service assistance',csc:30,govt:'Bank policy अनुसार',docs:['Account details','ID/KYC as applicable','Service-specific document'],process:['Service requirement समझें','Form/details भरें','Bank submission/reference दें']}
],process:['Bank/service eligibility verify करें','केवल अधिकृत banking/BC workflow का उपयोग करें','Transaction/reference सुरक्षित रखें'],note:'AEPS/BC/financial transactions तभी करें जब centre के पास वैध authorisation और live integration हो।'},
'किसान सेवाएँ':{services:[
{name:'PM-KISAN application/status assistance',csc:40,govt:'₹0 portal fee; eligibility applies',docs:['Aadhaar','Bank details','Land/farmer details as applicable'],process:['Eligibility verify करें','Farmer details भरें','Required records submit करें','Reference/status दें']},
{name:'Kisan / agriculture scheme application',csc:50,govt:'योजना/पोर्टल अनुसार',docs:['Aadhaar/ID','Land records','Bank details','Scheme-specific proof'],process:['Scheme eligibility check करें','Application भरें','Documents upload करें','Acknowledgement दें']},
{name:'Land / farmer record assistance',csc:50,govt:'राज्य/पोर्टल अनुसार',docs:['Land record/khata details','ID proof','Applicant details'],process:['Record identify करें','Portal request करें','Status/record copy दें']},
{name:'Farmer certificate / status assistance',csc:40,govt:'राज्य/पोर्टल अनुसार',docs:['Aadhaar/ID','Farmer/land records'],process:['Service verify करें','Application/status check करें','Reference/copy दें']}
],process:['योजना और eligibility verify करें','Farmer/land/bank details भरें','Documents submit करें','Reference सुरक्षित रखें']},
'बीमा सेवाएँ':{services:[
{name:'Insurance form assistance',csc:50,govt:'Insurer/product अनुसार',docs:['ID proof','Address proof','Policy/proposal details','Insurer-specific KYC'],process:['Product और requirement समझें','Details/documents verify करें','Authorised insurer workflow में submit करें']},
{name:'Policy renewal assistance',csc:40,govt:'Premium/insurer अनुसार',docs:['Policy number','ID/KYC as required','Renewal details'],process:['Policy status verify करें','Premium/terms customer से confirm करें','Authorised channel से renewal करें']},
{name:'Policy service request',csc:50,govt:'Insurer policy अनुसार',docs:['Policy number','ID proof','Request-specific documents'],process:['Request type verify करें','Documents submit करें','Reference/status दें']},
{name:'Claim documentation assistance',csc:75,govt:'Insurer/product अनुसार',docs:['Policy number','ID proof','Claim form','Incident/medical/death/other supporting records as applicable'],process:['Claim requirement list verify करें','Documents compile करें','Authorised insurer channel में submit करें','Claim reference दें']}
],process:['Policy/product और insurer requirements verify करें','Documents complete करें','Authorised insurer portal/channel से request submit करें'],note:'Insurance premium, payout और insurer charges product/company के अनुसार बदलते हैं।'},
'टैक्स एवं GST':{services:[
{name:'GST registration assistance',csc:100,govt:'₹0 government portal fee',docs:['PAN','Aadhaar/ID','Business/address proof','Bank details','Photo/signature as applicable'],process:['Business details verify करें','GST application भरें','KYC/documents submit करें','ARN/reference दें']},
{name:'GST return filing assistance',csc:100,govt:'₹0 government portal fee',docs:['GSTIN','Sales/purchase data','Invoices','Login/authorised access'],process:['Period/data verify करें','Return details prepare करें','Portal filing complete करें','Acknowledgement रखें']},
{name:'GST amendment / profile update',csc:75,govt:'₹0 government portal fee where applicable',docs:['GSTIN','Changed business/KYC proof'],process:['Change verify करें','Amendment application भरें','Documents submit करें','ARN/status दें']},
{name:'Tax document / challan assistance',csc:50,govt:'Tax amount as calculated by portal',docs:['PAN/TAN/GST details','Challan/return details','Relevant financial data'],process:['Tax requirement identify करें','Portal calculation/check करें','Payment/filing customer approval से करें','Challan/reference दें']}
],process:['Tax/GST requirement identify करें','Data और documents verify करें','Official government portal process पूरा करें','ARN/challan/acknowledgement दें']},
'शिक्षा एवं छात्र':{services:[
{name:'Scholarship application assistance',csc:50,govt:'₹0 portal fee where applicable',docs:['Student ID','Aadhaar/ID','Marksheets','Bank details','Income/category proof as scheme requires'],process:['Scholarship eligibility check करें','Student form भरें','Documents upload करें','Application ID दें']},
{name:'Exam / admission form filling',csc:50,govt:'Exam/institute fee as applicable',docs:['Student ID','Photo/signature','Marksheets/certificates','Exam/admission details'],process:['Form और eligibility verify करें','Details भरें','Documents upload करें','Payment/reference दें']},
{name:'Certificate / marksheet download',csc:20,govt:'Portal/institute अनुसार',docs:['Roll number/enrolment number','DOB/login details as required'],process:['Record verify करें','Official portal से download करें','Print/copy दें']},
{name:'Education document print/scan',csc:10,govt:'₹0 portal fee',docs:['Original/digital document'],process:['Document receive करें','Scan/print करें','Customer को copy दें']}
],process:['Student service और deadline verify करें','Form/documents submit करें','Application/reference सुरक्षित रखें']},
'यातायात सेवाएँ':{services:[
{name:'Learner licence application assistance',csc:100,govt:'State transport portal fee as applicable',docs:['ID/address proof','DOB proof','Photo/signature as required'],process:['Eligibility verify करें','Official transport portal form भरें','Documents/fee process करें','Application/appointment reference दें']},
{name:'Driving licence application assistance',csc:100,govt:'State transport portal fee as applicable',docs:['ID/address proof','Learner licence details where required','Photo/signature'],process:['Licence service चुनें','Form और documents submit करें','Appointment/test instructions दें','Reference दें']},
{name:'DL renewal / duplicate assistance',csc:75,govt:'State transport portal fee as applicable',docs:['Existing DL','ID/address proof','Medical/other document where required'],process:['DL details verify करें','Renewal/duplicate request submit करें','Reference/receipt दें']},
{name:'Transport application / status assistance',csc:40,govt:'Portal अनुसार',docs:['Application number','Vehicle/DL details'],process:['Reference verify करें','Official portal status check करें','Status print दें']}
],process:['Service और state portal verify करें','Eligibility/documents check करें','Official transport portal पर application करें','Receipt/appointment details दें']},
'वाहन सेवाएँ':{services:[
{name:'Vehicle registration assistance',csc:100,govt:'State transport/RTO fee as applicable',docs:['Sale invoice','Insurance','ID/address proof','Form/dealer documents as applicable'],process:['Vehicle details verify करें','Registration application submit करें','Documents/fee process करें','Receipt/reference दें']},
{name:'RC transfer / ownership assistance',csc:100,govt:'RTO fee as applicable',docs:['RC','Buyer/seller ID','Sale/transfer documents','Insurance/PUC as applicable'],process:['RC and parties verify करें','Transfer application submit करें','Acknowledgement दें']},
{name:'RC download / print assistance',csc:30,govt:'Portal fee as applicable',docs:['Registration number','Vehicle owner details'],process:['Vehicle record verify करें','Official portal से RC copy प्राप्त करें','Print दें']},
{name:'Vehicle document / status assistance',csc:40,govt:'Portal/RTO अनुसार',docs:['Registration number','Relevant vehicle document'],process:['Record verify करें','Portal status/check करें','Reference दें']}
],process:['Vehicle records verify करें','RTO/transport portal workflow पूरा करें','Receipt/reference सुरक्षित रखें']},
'संपत्ति एवं भूमि':{services:[
{name:'Land record / RoR assistance',csc:50,govt:'राज्य/पोर्टल अनुसार',docs:['Khata/khasra/survey details','ID proof'],process:['Land record identify करें','Official portal से record प्राप्त करें','Print/reference दें']},
{name:'Mutation application assistance',csc:100,govt:'राज्य/तहसील fee as applicable',docs:['Registry/deed','ID proof','Land record','Supporting documents'],process:['Mutation eligibility verify करें','Application submit करें','Acknowledgement/reference दें']},
{name:'Property document application',csc:75,govt:'State registration/portal fee as applicable',docs:['Property details','ID proof','Registry/deed details'],process:['Document type identify करें','Official portal/office process करें','Receipt/reference दें']},
{name:'Land/property certificate assistance',csc:60,govt:'राज्य/पोर्टल अनुसार',docs:['Land/property records','ID/address proof'],process:['Certificate type verify करें','Application submit करें','Reference/copy दें']}
],process:['Property/land details verify करें','State portal/office requirements follow करें','Application/reference सुरक्षित रखें']},
'कानूनी सेवाएँ':{services:[
{name:'Affidavit / declaration typing assistance',csc:50,govt:'Stamp/notary charges as applicable',docs:['ID proof','Address proof','Declaration details'],process:['Draft details verify करें','Document type/format तैयार करें','Stamp/notary requirement customer को बताएं']},
{name:'Legal application / form filling',csc:75,govt:'Court/office fee as applicable',docs:['ID proof','Case/application details','Supporting records'],process:['Form requirement समझें','Details भरें','Supporting documents attach करें','Receipt/reference दें']},
{name:'Document typing / print',csc:20,govt:'₹0 portal fee; stamp/notary extra if applicable',docs:['Source document/details'],process:['Content verify करें','Type/print करें','Final copy customer को दें']},
{name:'Status / reference assistance',csc:30,govt:'Office/portal अनुसार',docs:['Case/application/reference number','ID where required'],process:['Reference verify करें','Official portal/office status check करें','Status print दें']}
],process:['Service/document requirement स्पष्ट करें','कानूनी/सरकारी fee अलग होने पर customer को पहले बताएं','Final document/reference दें'],note:'यह centre assistance है; legal advice/representation के लिए authorised professional की आवश्यकता हो सकती है।'},
'स्वास्थ्य सेवाएँ':{services:[
{name:'Government health scheme application',csc:50,govt:'₹0 portal fee where applicable',docs:['Aadhaar/ID','Health scheme card/details','Income/category proof as applicable'],process:['Scheme eligibility verify करें','Application भरें','Documents submit करें','Reference दें']},
{name:'Health card / Ayushman assistance',csc:40,govt:'₹0 portal fee where applicable',docs:['Aadhaar/ID','Family/member details','Existing card if any'],process:['Eligibility/record verify करें','Authorised portal workflow पूरा करें','Card/reference दें']},
{name:'Hospital/health appointment assistance',csc:20,govt:'Hospital/portal fee as applicable',docs:['Patient ID','Hospital/department details'],process:['Hospital/service choose करें','Appointment details verify करें','Booking/reference दें']},
{name:'Health document print/download',csc:20,govt:'Portal/institution अनुसार',docs:['Patient/reference/login details'],process:['Record verify करें','Official source से document प्राप्त करें','Print दें']}
],process:['Health scheme/service identify करें','Patient details और documents verify करें','Authorised portal/institution process पूरा करें']},
'डिजिटल सेवाएँ':{services:[
{name:'Online form filling',csc:30,govt:'Portal fee as applicable',docs:['Service-specific ID/documents','Mobile number','Email where required'],process:['Form requirement verify करें','Data enter करें','Documents upload करें','Reference दें']},
{name:'Document scan / upload',csc:10,govt:'₹0 portal fee',docs:['Original document'],process:['Document scan करें','File size/format check करें','Portal पर upload करें']},
{name:'Online application status / download',csc:20,govt:'Portal fee as applicable',docs:['Application/reference number','Login/OTP details where required'],process:['Reference verify करें','Official portal status/download करें','Print/copy दें']},
{name:'Digital document print / copy',csc:10,govt:'₹0 portal fee',docs:['Digital document/file'],process:['File verify करें','Print/copy तैयार करें','Customer को दें']}
],process:['Digital service identify करें','Required data/documents verify करें','Official portal process पूरा करें','Acknowledgement/download दें']},
'अन्य नागरिक सेवाएँ':{services:[
{name:'Citizen online application',csc:40,govt:'Portal fee as applicable',docs:['Valid ID','Address proof','Service-specific documents'],process:['Service identify करें','Form भरें','Documents submit करें','Reference दें']},
{name:'Citizen certificate download',csc:20,govt:'Portal fee as applicable',docs:['Certificate/application number','ID where required'],process:['Record verify करें','Official portal से certificate प्राप्त करें','Print दें']},
{name:'Citizen form / document print',csc:15,govt:'₹0 portal fee',docs:['Digital form/document'],process:['File verify करें','Print करें','Customer को दें']},
{name:'General digital assistance',csc:30,govt:'Portal/service अनुसार',docs:['Service-specific details/documents'],process:['Request समझें','Official portal/service पूरा करें','Reference/receipt दें']}
],process:['Customer request और eligibility समझें','Official service/portal चुनें','Documents submit करें','Reference/receipt दें']},
'मोबाइल रिचार्ज':{services:[
{name:'Prepaid mobile recharge',csc:10,govt:'₹0 government fee; operator/offer terms apply',docs:['10-digit mobile number','Operator/plan confirmation'],process:['Number verify करें','Operator और plan/amount confirm करें','Customer payment लें','Transaction reference/receipt दें']},
{name:'Data / special plan recharge',csc:10,govt:'₹0 government fee; operator price as applicable',docs:['Mobile number','Selected plan'],process:['Plan details confirm करें','Payment लें','Recharge/reference दें']},
{name:'Recharge receipt / status assistance',csc:10,govt:'₹0 government fee',docs:['Mobile number','Transaction/reference if available'],process:['Transaction details verify करें','Status check करें','Receipt/reference दें']}
],process:['Number और plan customer से confirm करें','Payment से पहले final amount बताएं','Transaction reference/receipt दें'],note:'यह project external recharge API के बिना manual workflow है; live recharge तभी होगा जब authorised recharge integration जोड़ी जाए।'},
'बिजली बिल भुगतान':{services:[
{name:'Electricity bill payment assistance',csc:10,govt:'Bill amount + portal/BBPS fee as applicable',docs:['Consumer number','Latest bill'],process:['Consumer number verify करें','Outstanding amount confirm करें','Customer approval/payment लें','Receipt/reference दें']},
{name:'Electricity bill download / print',csc:15,govt:'Portal अनुसार',docs:['Consumer number / bill'],process:['Consumer record verify करें','Bill प्राप्त करें','Print दें']},
{name:'Electricity payment receipt / status',csc:10,govt:'Portal/BBPS अनुसार',docs:['Consumer number','Payment reference if available'],process:['Payment/reference verify करें','Official source से status/receipt दें']}
],process:['Consumer number और final payable amount verify करें','Customer approval के बाद payment करें','Receipt/reference दें'],note:'इस version में live BBPS payment gateway नहीं है; payment को external gateway success न दिखाएँ।'},
'पानी बिल भुगतान':{services:[
{name:'Water bill payment assistance',csc:10,govt:'Bill amount + portal fee as applicable',docs:['Consumer number','Latest bill'],process:['Consumer number verify करें','Amount confirm करें','Payment लें','Receipt/reference दें']},
{name:'Water bill download / print',csc:15,govt:'Portal अनुसार',docs:['Consumer number / bill'],process:['Record verify करें','Bill download करें','Print दें']},
{name:'Water payment receipt / status',csc:10,govt:'Portal अनुसार',docs:['Consumer number','Payment reference if available'],process:['Reference verify करें','Status/receipt प्राप्त करें','Customer को दें']}
],process:['Consumer details verify करें','Amount customer से confirm करें','Payment/reference receipt दें']},
'यात्रा टिकट':{services:[
{name:'Bus ticket booking assistance',csc:50,govt:'Operator fare + booking fee as applicable',docs:['Passenger name','Journey date/route','ID where required'],process:['Route/date/seat verify करें','Fare customer को बताएं','Booking करें','Ticket/PNR दें']},
{name:'Train ticket booking assistance',csc:50,govt:'Rail fare + IRCTC/booking charges as applicable',docs:['Passenger ID/details as required','Journey details'],process:['Availability/fare verify करें','Passenger details confirm करें','Authorised booking workflow से ticket करें','PNR दें']},
{name:'Flight ticket booking assistance',csc:100,govt:'Airline fare + taxes/booking fee as applicable',docs:['Passenger name as per ID','Journey details','ID details where required'],process:['Flight/fare compare करें','Passenger details confirm करें','Booking करें','PNR/e-ticket दें']},
{name:'Ticket print / PNR status',csc:20,govt:'Portal/operator अनुसार',docs:['PNR/booking reference','Passenger details'],process:['Reference verify करें','Official source से status/ticket प्राप्त करें','Print दें']}
],process:['Journey details और passenger name verify करें','Fare/charges customer से पहले confirm करें','Booking के बाद ticket/PNR दें']},
'सरकारी योजना':{services:[
{name:'Scheme eligibility check',csc:20,govt:'₹0 portal fee where applicable',docs:['Aadhaar/ID','Income/category/family details as scheme requires'],process:['Scheme rules check करें','Customer details verify करें','Eligibility result/reference दें']},
{name:'Government scheme application',csc:50,govt:'योजना/पोर्टल अनुसार',docs:['Aadhaar/ID','Bank details','Income/category/other scheme-specific proof'],process:['Eligibility verify करें','Form भरें','Documents upload करें','Application reference दें']},
{name:'Scheme status / correction assistance',csc:30,govt:'Portal अनुसार',docs:['Application/reference number','ID/details'],process:['Reference verify करें','Status/correction option check करें','Updated reference दें']},
{name:'Scheme document upload / download',csc:20,govt:'Portal अनुसार',docs:['Application number','Required document'],process:['File verify करें','Portal upload/download करें','Acknowledgement दें']}
],process:['Scheme और eligibility verify करें','Application/documents submit करें','Reference/status customer को दें']},
'ई-गवर्नेंस सेवाएँ':{services:[
{name:'Government portal form filling',csc:40,govt:'Portal fee as applicable',docs:['ID proof','Mobile/email','Service-specific documents'],process:['Portal/service identify करें','Form भरें','Documents upload करें','Reference दें']},
{name:'Online certificate application',csc:50,govt:'State/portal अनुसार',docs:['ID/address proof','Certificate-specific documents'],process:['Certificate type verify करें','Application submit करें','Acknowledgement दें']},
{name:'Government status / download assistance',csc:20,govt:'Portal अनुसार',docs:['Application/reference number'],process:['Reference verify करें','Official portal से status/document प्राप्त करें','Print दें']},
{name:'Digital government document print',csc:15,govt:'₹0 portal fee where applicable',docs:['Digital document/reference'],process:['Document verify करें','Print/copy दें']}
],process:['Official government portal/service identify करें','Applicant details और documents verify करें','Application/status/download पूरा करें']},
'डाक एवं कुरियर':{services:[
{name:'Parcel booking assistance',csc:30,govt:'Post/courier tariff as applicable',docs:['Sender/receiver name/address/mobile','ID where required'],process:['Parcel details verify करें','Weight/charges confirm करें','Authorised booking करें','Receipt/tracking दें']},
{name:'Courier booking assistance',csc:30,govt:'Courier tariff as applicable',docs:['Sender/receiver details','ID where required'],process:['Courier service/charges confirm करें','Booking करें','Tracking/reference दें']},
{name:'Tracking assistance',csc:15,govt:'₹0 portal fee where applicable',docs:['Tracking number'],process:['Tracking number verify करें','Official courier/post portal पर status देखें','Status print/share करें']},
{name:'Packing / print support',csc:20,govt:'Material cost as applicable',docs:['Parcel/document'],process:['Packing requirement समझें','Material/print charge confirm करें','Parcel तैयार करें']}
],process:['Sender/receiver details verify करें','Tariff/charges customer को बताएं','Booking receipt/tracking दें']},
'पेंशन सेवाएँ':{services:[
{name:'Pension application assistance',csc:75,govt:'राज्य/विभाग/पोर्टल अनुसार',docs:['Aadhaar/ID','Bank details','Age/service/pension records as applicable'],process:['Pension category verify करें','Application भरें','Documents submit करें','Reference दें']},
{name:'Pension status assistance',csc:30,govt:'₹0 portal fee where applicable',docs:['PPO/application number','ID where required'],process:['Reference verify करें','Official portal/department status check करें','Status print दें']},
{name:'Life certificate assistance',csc:50,govt:'Department/portal अनुसार',docs:['PPO/pension details','Aadhaar/ID','Biometric/verification where required'],process:['Pension record verify करें','Authorised verification workflow पूरा करें','Acknowledgement दें']},
{name:'Pension document print/download',csc:20,govt:'Portal अनुसार',docs:['PPO/reference/login details'],process:['Record verify करें','Official source से document प्राप्त करें','Print दें']}
],process:['Pension category और eligibility verify करें','Documents/records submit करें','Reference/acknowledgement सुरक्षित रखें']},
'परिवार रजिस्टर':{services:[
{name:'Family register application',csc:50,govt:'राज्य/स्थानीय portal अनुसार',docs:['Family ID/record if available','ID/address proof','Relationship proof'],process:['Family members details verify करें','Application भरें','Supporting records submit करें','Reference दें']},
{name:'Family member addition/update',csc:50,govt:'राज्य/स्थानीय portal अनुसार',docs:['Existing family record','New member ID','Relationship proof'],process:['Existing record verify करें','Update application submit करें','Acknowledgement दें']},
{name:'Family certificate assistance',csc:50,govt:'राज्य/पोर्टल अनुसार',docs:['Family record','ID/address proof','Relationship/death/other proof as applicable'],process:['Certificate type verify करें','Documents submit करें','Reference/certificate दें']},
{name:'Family register print/download',csc:20,govt:'Portal अनुसार',docs:['Family/application number','ID where required'],process:['Record verify करें','Official source से copy प्राप्त करें','Print दें']}
],process:['Family record और relationship details verify करें','State/local portal process पूरा करें','Reference/certificate दें']}
};

let selectedPublicService=null;
function getServiceInfo(name,serviceObj){
 const base=SERVICE_INFO[name]||{services:[],process:['सही service चुनें','Eligibility/documents verify करें','Official portal/process पूरा करें']};
 const backendSubs=SERVICE_CATALOG_BY_CATEGORY[name]||[];
 const embedded=Array.isArray(base.services)?base.services:[];
 const byName=new Map(embedded.map(x=>[x.name,x]));
 const merged=backendSubs.map(x=>({
   ...(byName.get(x.name)||{}),
   name:x.name,
   csc:Number(x.csc??byName.get(x.name)?.csc??0),
   govt:x.govt??byName.get(x.name)?.govt??'Portal/department अनुसार',
   docs:Array.isArray(x.docs)&&x.docs.length?x.docs:(byName.get(x.name)?.docs||['Valid ID proof','Mobile number','Service-specific documents']),
   process:Array.isArray(x.process)&&x.process.length?x.process:(byName.get(x.name)?.process||base.process)
 }));
 const finalServices=merged.length?merged:embedded;
 const categoryFee=Number(serviceObj?.[4]||0);
 return {...base,fee:categoryFee,services:finalServices};
}
function money(v){return Number(v||0).toFixed(2)}
function openPublicServiceDetails(serviceObj){
 const name=serviceObj[1],info=getServiceInfo(name,serviceObj); selectedPublicService={category:name,serviceObj,info};
 $('#publicDetailTitle').textContent=name;
 $('#publicDetailText').textContent=serviceObj[5]||name+' की individual services, centre charge, government/portal charge और documents यहाँ देखें।';
 $('#publicDetailFee').innerHTML='<b>हर individual service का अलग charge नीचे दिया है</b><br><small>Centre/CSC charge और Government/Portal charge अलग रखें।</small>';
 $('#publicDetailServices').innerHTML=info.services.map((x,i)=>`<li class="subservice-item"><div class="subservice-head"><b>${i+1}. ${escapeHtml(x.name)}</b><span>CSC ₹${money(x.csc)}</span></div><div class="subservice-fees"><span>💰 CSC/ Centre: ₹${money(x.csc)}</span><span>🏛️ Govt/Portal: ${escapeHtml(x.govt)}</span></div><div class="subservice-docs"><b>📄 Documents:</b> ${escapeHtml(x.docs.join(' · '))}</div><button class="subservice-apply" data-subservice="${i}">इस service के लिए आवेदन →</button></li>`).join('');
 const process=info.process||info.services[0]?.process||[];
 $('#publicDetailProcess').innerHTML=process.map((x,i)=>`<li><b>${i+1}.</b> ${escapeHtml(x)}</li>`).join('');
 const docs=[...new Set(info.services.flatMap(x=>x.docs||[]))];
 $('#publicDetailDocs').innerHTML=docs.map(x=>`<li>${escapeHtml(x)}</li>`).join('');
 $('#publicDetailNote').textContent=info.note||'Government/portal charges department, state, provider और service के अनुसार बदल सकते हैं। जहाँ fixed official fee नहीं है वहाँ “as applicable” दिखाया गया है। Final amount customer से confirm करके ही payment लें।';
 $('#publicDetailModal').classList.remove('hidden');
 $$('#publicDetailServices .subservice-apply').forEach(btn=>btn.onclick=()=>{
   const idx=Number(btn.dataset.subservice),sub=info.services[idx]; if(!sub)return;
   selectedPublicService={...selectedPublicService,sub};
   $('#publicDetailModal').classList.add('hidden');
   $('#reqService').value=name+' — '+sub.name;
   $('#reqCat').value=name;
   $('#tokenService').value=name+' — '+sub.name;
   go('request');
   toast('Service चुनी गई — अब नाम और मोबाइल भरें');
 });
}

function renderDetailPage(serviceObj){if(!serviceObj)return;const name=serviceObj[1],info=getServiceInfo(name,serviceObj);const root=$('#page-detail');if(!root)return;const detail=root.querySelector('.service-detail');if(!detail)return;detail.querySelector('.service-icon').textContent=serviceObj[0];detail.querySelector('h2').textContent=name;detail.querySelector('.tag').textContent=serviceObj[3]==='gov'?'सरकारी सेवा':serviceObj[3]==='popular'?'लोकप्रिय सेवा':serviceObj[3]==='new'?'नई सेवा':'डिजिटल सेवा';const ps=detail.querySelectorAll('p');if(ps[0])ps[0].textContent=serviceObj[5]||name+' की सेवा जानकारी';const hs=[...detail.querySelectorAll('h3')];const lists=detail.querySelectorAll('ul,ol');if(hs[0])hs[0].nextElementSibling.textContent='यह सेवा उन ग्राहकों के लिए है जिन्हें '+name+' से जुड़ी सहायता चाहिए।';if(lists[0]){const docs=[...new Set(info.services.flatMap(x=>x.docs||[]))];lists[0].innerHTML=docs.map(x=>`<li>${escapeHtml(x)}</li>`).join('');}if(lists[1])lists[1].innerHTML=info.process.map(x=>`<li>${escapeHtml(x)}</li>`).join('');const infoBox=root.querySelector('.info-box .check');if(infoBox)infoBox.innerHTML=`<li>CSC सेवा शुल्क: ₹${info.fee.toFixed(2)}</li><li>सरकारी/पोर्टल शुल्क: लागू होने पर अलग</li><li>आवेदन के बाद acknowledgement/receipt उपलब्ध</li>`;$('#reqService').value=name;$('#reqCat').value=serviceObj[3]==='gov'?'सरकारी योजना':(serviceObj[3]==='digital'?'डिजिटल सेवाएँ':serviceObj[1]);}
function bindPublicServiceCards(){const grid=$('#publicServiceGrid');if(!grid||grid.dataset.bound==='1')return;grid.dataset.bound='1';grid.addEventListener('click',e=>{const card=e.target.closest('.service[data-public-service]');if(!card)return;const name=card.dataset.publicService;const service=services.find(x=>x[1]===name)||FALLBACK_SERVICES.find(x=>x[1]===name);if(service)openPublicServiceDetails(service);});}
function renderPublicServices(q=''){const grid=$('#publicServiceGrid');if(!grid)return;const s=services.filter(x=>x[1].toLowerCase().includes(q.toLowerCase()));if(s.length){grid.innerHTML=s.map(x=>`<article class="service" data-public-service="${escapeHtml(x[1])}"><div class="icon">${escapeHtml(x[0])}</div><h3>${escapeHtml(x[1])}</h3><small>सेवा विवरण और शुल्क देखें</small><div><span class="tag">${x[3]==='popular'?'लोकप्रिय':x[3]==='new'?'नया':x[3]==='gov'?'सरकारी':'डिजिटल'}</span></div><span class="public-apply">विवरण देखें →</span></article>`).join('');}else{grid.innerHTML='<div class="panel">कोई सेवा नहीं मिली।</div>';}bindPublicServiceCards();}
if($('#publicServiceSearch'))$('#publicServiceSearch').oninput=e=>renderPublicServices(e.target.value);$('#serviceSearch').oninput=e=>renderServices($('#serviceChips .sel').dataset.filter,e.target.value);$$('#serviceChips button').forEach(b=>b.onclick=()=>{$$('#serviceChips button').forEach(x=>x.classList.remove('sel'));b.classList.add('sel');renderServices(b.dataset.filter,$('#serviceSearch').value)});$('#homeSearchBtn').onclick=()=>{$('#serviceSearch').value=$('#homeSearch').value;go('services');renderServices('all',$('#homeSearch').value)};$('#publicTokenBtn').onclick=()=>{if($('#publicLiveToken'))$('#publicLiveToken').textContent='Login करें';toast('Live Queue देखने के लिए Customer Login जरूरी है')};
function renderQueue(rows){const body=$('#queueTable');if(!body)return;body.innerHTML=(rows||[]).map((r,i)=>{const extra=r.status==='होल्ड'?`<small class="muted">${escapeHtml(r.hold_reason||'')} · ${r.hold_overdue?'OVERDUE':((r.hold_remaining_minutes??'—')+' min')}</small>`:r.status==='स्किप'?`<small class="muted">Reason: ${escapeHtml(r.skip_reason||'')}</small>`:'';return `<tr><td>${i+1}</td><td><b>${escapeHtml(r.token)}</b></td><td>${escapeHtml(r.service||'—')}</td><td>${escapeHtml(r.name||'—')}</td><td>${escapeHtml(r.staff_name||'—')}</td><td>${r.priority?'⭐':'—'}</td><td>${r.estimated_wait_minutes??'—'} min</td><td><span class="status-pill ${r.status==='पूर्ण'?'done':'pending'}">${escapeHtml(r.status)}</span>${extra}</td></tr>`}).join('')||'<tr><td colspan="8">आज कोई token नहीं है</td></tr>'}
function renderServiceQueues(queues){const box=$('#serviceQueueCards');if(!box)return;box.innerHTML=(queues||[]).map(q=>`<article class="service"><div class="icon">🎫</div><h3>${escapeHtml(q.service)}</h3><small>Waiting: ${q.waiting} · Completed: ${q.completed}</small><p class="muted">Current: <b>${escapeHtml(q.current||'—')}</b></p></article>`).join('')||'<div class="panel">कोई service-wise queue नहीं है।</div>'}
function istDateKey(value){
 const raw=String(value??'').trim();
 if(!raw)return '';
 // Date-only fields are already calendar dates; do not reinterpret them as UTC.
 if(/^\d{4}-\d{2}-\d{2}$/.test(raw))return raw;
 const d=new Date(raw);
 if(Number.isNaN(d.getTime()))return '';
 return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(d);
}
function istCalendarDays(count=7){
 const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
 const y=Number(parts.find(x=>x.type==='year').value),m=Number(parts.find(x=>x.type==='month').value),day=Number(parts.find(x=>x.type==='day').value);
 const out=[];
 for(let i=count-1;i>=0;i--){
   const d=new Date(Date.UTC(y,m-1,day-i,12,0,0));
   const key=d.toISOString().slice(0,10);
   out.push({key,label:new Intl.DateTimeFormat('hi-IN',{timeZone:'Asia/Kolkata',day:'2-digit',month:'2-digit'}).format(d),count:0});
 }
 return out;
}
function renderHomeAnalytics(rows){
 const list=Array.isArray(rows)?rows:[];
 const days=istCalendarDays(7);
 const dayMap=new Map(days.map(x=>[x.key,x]));
 list.forEach(t=>{
   const raw=t.date||t.created_at||t.createdAt||'';
   const key=istDateKey(raw);
   const hit=dayMap.get(key); if(hit)hit.count++;
 });
 const bars=$('#homeTokenBars');
 const max=Math.max(1,...days.map(x=>x.count));
 if(bars){
   bars.innerHTML=days.map(x=>`<b title="${x.label}: ${x.count} token" style="height:${Math.max(8,Math.round(x.count/max*100))}%"><span>${x.count}</span></b>`).join('')+
     days.map(x=>`<small class="bar-label">${escapeHtml(x.label)}</small>`).join('');
 }
 const graphStatus=$('#homeTokenGraphStatus'); if(graphStatus)graphStatus.textContent='LIVE · 7 दिन';
 const groups=new Map();
 list.forEach(t=>{
   const service=String(t.service||t.service_name||'अन्य सेवा').trim()||'अन्य सेवा';
   groups.set(service,(groups.get(service)||0)+1);
 });
 const ranked=[...groups.entries()].sort((a,b)=>b[1]-a[1]);
 const total=ranked.reduce((a,x)=>a+x[1],0);
 const visible=ranked.slice(0,6);
 const remainder=ranked.slice(6).reduce((a,x)=>a+x[1],0);

 const chartItems=remainder>0?[...visible,['अन्य सेवाएँ',remainder]]:visible;
 const donut=$('#homeServiceDonut');
 if(donut){
   if(!total){donut.style.background='conic-gradient(#d7e5f5 0 100%)';}
   else{
     let cursor=0; const stops=[]; const fills=['#1679ee','#22a06b','#f2b632','#7b61ff','#ef6c9b','#11a9b8','#9aa9b8'];
     chartItems.forEach(([,n],i)=>{const end=cursor+n/total*100;stops.push(`${fills[i%fills.length]} ${cursor}% ${end}%`);cursor=end;});
     donut.style.background=`conic-gradient(${stops.join(',')})`;
   }
 }
 const legend=$('#homeServiceLegend');
 if(legend){
   legend.innerHTML=chartItems.length?chartItems.map(([name,n])=>`<li><span>${escapeHtml(name)}</span><b>${n} (${total?Math.round(n/total*100):0}%)</b></li>`).join(''):'<li>अभी कोई token data उपलब्ध नहीं है</li>';
 }
}

function renderLive(rows){
 const list=Array.isArray(rows)?rows:[];
 const active=list.find(x=>['बुलाया','प्रगति'].includes(x.status))||list.find(x=>x.status==='लंबित')||list[0];
 if(!active){
   $('#liveCurrent').textContent='—';$('#currentToken').textContent='—';$('#currentCustomer').textContent='कोई active token नहीं';
   $('#liveCurrentService').textContent='सेवा: —';if($('#liveCurrentCounter'))$('#liveCurrentCounter').textContent='काउंटर —';$('#nextTokens').innerHTML='<div class="next-empty">अभी कोई अगला token नहीं है</div>';return;
 }
 $('#liveCurrent').textContent=active.token||'—';$('#currentToken').textContent=active.token||'—';$('#currentCustomer').textContent=(active.name||'ग्राहक')+' · '+(active.service||'—');
 $('#liveCurrentService').textContent='सेवा: '+(active.service||'—');
 if($('#liveCurrentCounter'))$('#liveCurrentCounter').textContent='काउंटर '+(active.counter_no||active.counter||'1');
 const next=list.filter(x=>x.id!==active.id&&!['पूर्ण','रद्द','स्किप'].includes(x.status)).slice(0,5);
 $('#nextTokens').innerHTML=next.length?next.map((x,i)=>`<div class="next-token-card"><b>${escapeHtml(x.token||'—')}</b><span>${escapeHtml(x.service||'सेवा')}</span><strong>काउंटर ${escapeHtml(x.counter_no||x.counter||'—')}</strong></div>`).join(''):'<div class="next-empty">अभी कोई अगला token नहीं है</div>';
}
async function loadTokens(){try{const d=await api('/api/tokens');const tokens=d.tokens||[];window.__angelTokenRows=tokens;renderQueue(tokens);renderServiceQueues(d.service_queues||[]);renderLive(tokens);const active=tokens.filter(x=>!['पूर्ण','रद्द','स्किप'].includes(x.status)).length;const waiting=tokens.filter(x=>x.status==='लंबित').length;const completed=tokens.filter(x=>x.status==='पूर्ण').length;const waits=tokens.filter(x=>Number.isFinite(Number(x.estimated_wait_minutes))).map(x=>Number(x.estimated_wait_minutes));if($('#tokenActiveCount'))$('#tokenActiveCount').textContent=active;if($('#tokenWaitingCount'))$('#tokenWaitingCount').textContent=waiting;if($('#tokenCompletedCount'))$('#tokenCompletedCount').textContent=completed;if($('#tokenAvgWait'))$('#tokenAvgWait').textContent=(waits.length?Math.round(waits.reduce((a,b)=>a+b,0)/waits.length):0)+' min';if($('#statTokens'))$('#statTokens').textContent=tokens.length;if($('#waitTime'))$('#waitTime').textContent=((d.current?.estimated_wait_minutes??tokens.find(x=>x.status==='लंबित')?.estimated_wait_minutes)??'—')+' मिनट';if(d.control_current){localStorage.setItem('angelCurrentTokenId',String(d.control_current.id));}const control=d.control_current;if($('#startWork')){const hold=control?.status==='होल्ड';$('#startWork').textContent=hold?'▶ Resume':'▶ काम शुरू करें';$('#startWork').title=hold?'Hold token को Resume करें':'Current token पर काम शुरू करें';}if($('#hold'))$('#hold').disabled=tokenActionBusy||!control||!['बुलाया','प्रगति'].includes(control.status);if($('#extendHold'))$('#extendHold').disabled=tokenActionBusy||control?.status!=='होल्ड';if($('#recall'))$('#recall').disabled=tokenActionBusy||!control||!['बुलाया','स्किप'].includes(control.status);window.dispatchEvent(new CustomEvent('angel:tokens-loaded',{detail:tokens}));}catch(e){toast(e.message)}}
function safeGet(key, fallback=''){try{return localStorage.getItem(key)??fallback}catch{return fallback}}
function safeSet(key,value){try{localStorage.setItem(key,value);return true}catch{return false}}
function readJson(key,fallback){try{const raw=safeGet(key,'');return raw?JSON.parse(raw):fallback}catch{return fallback}}
function writeJson(key,value){safeSet(key,JSON.stringify(value))}
function getToday(){return new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Kolkata'})}
function populateTokenServices(preferred=''){
 const sel=$('#tokenService'); if(!sel)return;
 const current=preferred||sel.value||'';
 const names=[];
 Object.values(SERVICE_INFO||{}).forEach(info=>(info.services||[]).forEach(sub=>{if(sub?.name&&!names.includes(sub.name))names.push(sub.name)}));
 // keep the selected category-level service if an older flow supplied it
 services.forEach(x=>{if(x?.[1]&&!names.includes(x[1]))names.push(x[1])});
 sel.innerHTML='<option value="">सेवा चुनें</option>'+names.map(n=>`<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>` ).join('');
 if(current){const exists=[...sel.options].some(o=>o.value===current);if(!exists){const o=document.createElement('option');o.value=current;o.textContent=current;sel.appendChild(o)}sel.value=current;}
}
async function issueLocalToken(){
 const btn=$('#issueToken'); if(btn?.dataset.busy==='1')return; if(btn)btn.dataset.busy='1';
 try{const service=(($('#tokenService')?.value||'').trim()||($('#reqService')?.value||'').trim());const name=(($('#tokenName')?.value||'').trim()||currentCustomer?.name||'').trim();const mobile=(($('#tokenMobile')?.value||'').trim()||currentCustomer?.mobile||'').trim();if(!service)return toast('पहले सेवा चुनें');if(!name)return toast('ग्राहक का नाम भरें');if(!/^\d{10}$/.test(mobile))return toast('सही 10 digit मोबाइल भरें');const payment_id=Number(localStorage.getItem('angelPaymentId')||0);let d;if(role==='customer'){if(!payment_id)return toast('पहले payment submit करें');d=await api('/api/customer/tokens',{method:'POST',body:JSON.stringify({service,name,mobile,payment_id})})}else{const payment_id=Number($('#tokenPaymentId')?.value||localStorage.getItem('angelPaymentId')||0);if(!payment_id)return toast('Verified Payment ID जरूरी है');d=await api('/api/tokens',{method:'POST',body:JSON.stringify({action:'issue',service,name,mobile,payment_id})})}currentCustomer={name,mobile};writeJson('angelCustomerLocal',currentCustomer);safeSet('angelCustomerLogin','1');updateCustomerButton();fillCustomer(currentCustomer);$('#tokenNumber').textContent=d.token;$('#ticketService').textContent='सेवा: '+service;await loadTokens();toast('नया token '+d.token+' जारी हुआ')}catch(e){toast(e.message)}finally{if(btn)setTimeout(()=>btn.dataset.busy='0',350)}}
$('#issueToken').onclick=issueLocalToken;
document.addEventListener('click',e=>{const btn=e.target.closest?.('#issueToken');if(btn){e.preventDefault();issueLocalToken()}},true);

$('#newToken').onclick=()=>$('#issueToken').click();$('#viewToken').onclick=()=>go('status');
let tokenActionBusy=false;
function setTokenActionBusy(busy){tokenActionBusy=busy;['#nextCounter','#recall','#startWork','#hold','#extendHold','#skip','#cancelToken','#complete','#assignToken','#priorityToken','#transferToken','#notifyToken'].forEach(sel=>{const el=$(sel);if(el)el.disabled=busy;});}
async function tokenAction(action,extra={}){if(tokenActionBusy)return;setTokenActionBusy(true);try{const q=await api('/api/tokens');const storedId=Number(localStorage.getItem('angelCurrentTokenId'))||null;let id=storedId||Number(q.current?.id)||null;let selected=null;if(action!=='next'){selected=(q.tokens||[]).find(t=>Number(t.id)===id)||null;if(!selected){const label=$('#currentToken')?.textContent?.trim();selected=(q.tokens||[]).find(t=>t.token===label)||null;id=Number(selected?.id)||null;}}if(action!=='next'&&!id)throw new Error('Current token नहीं मिला');const nextService=String($('#tokenService')?.value||$('#reqService')?.value||'').trim();const requestId=(crypto.randomUUID?crypto.randomUUID():('tok-'+Date.now()+'-'+Math.random().toString(36).slice(2)));const payload=action==='next'?{action,service:nextService,request_id:requestId}:{action,id,...extra,request_id:requestId,expected_state_revision:Number(selected?.state_revision||0)};const d=await api('/api/tokens',{method:'POST',body:JSON.stringify(payload)});if(d?.id!=null)localStorage.setItem('angelCurrentTokenId',String(d.id));await loadTokens();toast('Token '+d.token+' — '+d.status)}catch(e){if(Number(e.status)===409){await loadTokens().catch(()=>{});toast('⚠ Token state बदल चुका है। Queue refresh कर दी गई है; latest state देखकर action दोबारा करें।')}else toast(e.message)}finally{setTokenActionBusy(false);await loadTokens().catch(()=>{})}}

async function holdToken(){const reason=askReason('काम Pending / Hold');if(!reason)return;const owner=(await angelPrompt('Delay किसकी वजह से है? customer / operator / portal / department / other','customer')||'').trim().toLowerCase();if(!['customer','operator','portal','department','other'].includes(owner)){toast('Valid delay owner चुनें');return}const mins=Number(await angelPrompt('Expected delay कितने मिनट?','15'));if(!Number.isInteger(mins)||mins<1||mins>1440){toast('1 से 1440 मिनट चुनें');return}tokenAction('hold',{reason,owner,delay_minutes:mins})}
function skipToken(){const reason=askReason('Token Skip');if(reason)tokenAction('skip',{reason})}
async function extendHold(){const mins=Number(await angelPrompt('और कितने मिनट बढ़ाना है?','15'));if(!Number.isInteger(mins)||mins<1||mins>1440){toast('1 से 1440 मिनट चुनें');return}const reason=askReason('Delay Extension');if(reason)tokenAction('extend_hold',{delay_minutes:mins,reason})}
async function selectedTokenRecord(){const q=await api('/api/tokens');const storedId=Number(localStorage.getItem('angelCurrentTokenId'))||null;return (q.tokens||[]).find(t=>Number(t.id)===storedId)||q.current||null}
async function chooseStaff(){const d=await api('/api/staff');const staff=(d.staff||[]).filter(x=>x.status==='active');if(!staff.length)throw new Error('कोई active staff उपलब्ध नहीं है');const list=staff.map((x,i)=>`${i+1}. ${x.name} (${x.employee_id})`).join('\n');const n=Number(await angelPrompt('Staff चुनें:\n'+list+'\n\nNumber:','1'));if(!Number.isInteger(n)||n<1||n>staff.length)throw new Error('Valid staff चुनें');return staff[n-1]}
async function assignCurrentToken(action='assign'){try{const t=await selectedTokenRecord();if(!t)throw new Error('Current token नहीं मिला');const st=await chooseStaff();const reason=action==='transfer'?askReason('Transfer Reason'):'';if(action==='transfer'&&!reason)return;await api('/api/tokens',{method:'POST',body:JSON.stringify({action, id:t.id, staff_id:st.staff_id, from_staff_id:t.staff_id||null, reason:reason||''})});await loadTokens();toast((action==='transfer'?'Token transfer':'Staff assignment')+' सफल')}catch(e){toast(e.message)}}
async function togglePriority(){try{const t=await selectedTokenRecord();if(!t)throw new Error('Current token नहीं मिला');const enabled=!Boolean(t.priority);const reason=enabled?askReason('Priority Token'):'';if(enabled&&!reason)return;await api('/api/tokens',{method:'POST',body:JSON.stringify({action:'priority',id:t.id,enabled,reason:reason||''})});await loadTokens();toast(enabled?'Priority Token set':'Priority हटाई गई')}catch(e){toast(e.message)}}
async function cancelCurrentToken(){try{const t=await selectedTokenRecord();if(!t)throw new Error('Current token नहीं मिला');const reason=askReason('Token Cancel');if(!reason)return;await api('/api/tokens',{method:'POST',body:JSON.stringify({action:'cancel',id:t.id,reason})});await loadTokens();toast('Token cancelled')}catch(e){toast(e.message)}}
async function notifyCurrentToken(){try{const t=await selectedTokenRecord();if(!t)throw new Error('Current token नहीं मिला');const message=await angelPrompt('Customer notification message:',`Token ${t.token}: आपकी service queue में update है।`);if(!message?.trim())return;await api('/api/tokens',{method:'POST',body:JSON.stringify({action:'notify',id:t.id,title:'Token Update',message:message.trim()})});toast('Notification record बनाया गया')}catch(e){toast(e.message)}}
async function currentTokenId(){const d=await api('/api/tokens');const t=d.tokens.find(x=>x.token===$('#currentToken').textContent);if(!t)throw new Error('Current token नहीं मिला');return t.id}
$('#nextCounter').onclick=()=>tokenAction('next');$('#recall').onclick=()=>tokenAction('recall');$('#startWork').onclick=()=>tokenAction('processing');$('#hold').onclick=holdToken;$('#extendHold').onclick=extendHold;$('#skip').onclick=skipToken;$('#cancelToken').onclick=cancelCurrentToken;$('#complete').onclick=()=>tokenAction('complete');$('#assignToken').onclick=()=>assignCurrentToken('assign');$('#priorityToken').onclick=togglePriority;$('#transferToken').onclick=()=>assignCurrentToken('transfer');$('#notifyToken').onclick=notifyCurrentToken;
async function loadCustomers(q=''){try{const d=await api('/api/customers?q='+encodeURIComponent(q));const rows=d.customers||[];$('#customerTable').innerHTML=rows.map(r=>`<tr><td><b>${escapeHtml(r.name)}</b></td><td>${escapeHtml(r.mobile)}</td><td>${r.services||0}</td><td>${escapeHtml(r.last_service||'—')}</td><td><span class="status-pill ${r.active?'done':'pending'}">${r.active?'सक्रिय':'बंद'}</span></td><td><button class="viewCustomer" data-id="${r.id}">हिस्ट्री</button></td></tr>`).join('')||'<tr><td colspan="6">कोई ग्राहक नहीं मिला</td></tr>';$$('.viewCustomer').forEach(b=>b.onclick=()=>showCustomerHistory(b.dataset.id))}catch(e){toast(e.message)}}
async function showCustomerHistory(mobile){try{const d=await api('/api/customer-history?mobile='+encodeURIComponent(mobile));const s=d.summary||{};$('#historyTitle').textContent=(d.customer?.name||'Customer')+' — '+mobile;$('#historySummary').textContent=`Tokens: ${s.tokens||0} · Payments: ${s.payments||0} · Applications: ${s.applications||0} · Home: ${s.home_services||0} · Delivery: ${s.deliveries||0} · Verified Paid: ₹${Number(s.verified_paid||0).toFixed(2)}`;const tokenRows=(d.tokens||[]).map(x=>`<tr><td>${escapeHtml(x.token)}</td><td>${escapeHtml(x.service)}</td><td>${escapeHtml(x.status)}</td><td>${escapeHtml(x.created_at||'')}</td></tr>`).join('')||'<tr><td colspan="4">No token history</td></tr>';const payRows=(d.payments||[]).map(x=>`<tr><td>${escapeHtml(x.txn_id)}</td><td>₹${Number(x.amount||0).toFixed(2)}</td><td>${escapeHtml(x.method)}</td><td>${escapeHtml(x.status)}</td><td>${escapeHtml(x.utr||'—')}</td></tr>`).join('')||'<tr><td colspan="5">No payment history</td></tr>';$('#historyBody').innerHTML=`<h4>Service / Token History</h4><div class="table-wrap"><table><thead><tr><th>Token</th><th>Service</th><th>Status</th><th>Date</th></tr></thead><tbody>${tokenRows}</tbody></table></div><h4 style="margin-top:16px">Payment History</h4><div class="table-wrap"><table><thead><tr><th>Txn</th><th>Amount</th><th>Mode</th><th>Status</th><th>UTR</th></tr></thead><tbody>${payRows}</tbody></table></div>`;$('#customerHistoryPanel').classList.remove('hidden');$('#customerHistoryPanel').scrollIntoView({behavior:'smooth',block:'start'})}catch(e){toast(e.message)}}
$('#closeHistory')?.addEventListener('click',()=>$('#customerHistoryPanel').classList.add('hidden'))

$('#customerSearch').oninput=e=>loadCustomers(e.target.value);$('#addCustomer').onclick=()=>go('request');
let paymentFilter='all';
async function loadPayments(){try{const d=await api('/api/payments');const allRows=d.payments||[],rows=paymentFilter==='all'?allRows:allRows.filter(r=>String(r.method||'').toLowerCase()===paymentFilter);$('#paymentsTable').innerHTML=rows.map(r=>`<tr><td>${escapeHtml(r.txn_id)}</td><td>${escapeHtml(r.name||'—')}<br><small>${escapeHtml(r.utr?'UTR: '+r.utr:'')}</small></td><td><b>₹ ${Number(r.amount).toFixed(2)}</b></td><td>${escapeHtml(r.method)}</td><td>${escapeHtml(r.created_at)}</td><td><span class="status-pill ${r.status==='Verified'?'done':r.status==='Rejected'?'hold':'pending'}">${escapeHtml(r.status)}</span></td><td>${r.proof_available?`<button class="proof-btn" data-id="${r.id}">📷 Screenshot देखें</button>`:(r.utr?'UTR only':'—')}</td><td>${r.status==='Pending Verification'?`<button class="verify-pay" data-id="${r.id}" ${(!r.proof_available&&r.utr)||(r.proof_available&&r.proof_viewed_at)?'':'disabled title="Screenshot हो तो पहले उसे देखें"'}>✅ Verify</button><button class="reject-pay" data-id="${r.id}" ${(!r.proof_available&&r.utr)||(r.proof_available&&r.proof_viewed_at)?'':'disabled title="Screenshot हो तो पहले उसे देखें"'}>❌ Reject</button>`:(r.receipt_no?`<button class="receipt-btn" data-id="${r.id}" data-receipt="${r.receipt_no}" data-name="${escapeHtml(r.name||'')}" data-amount="${r.amount}">रसीद</button>`:'—')}</td></tr>`).join('')||'<tr><td colspan="8">कोई payment नहीं है</td></tr>';
$('#totalPaid').textContent='₹ '+Number(d.total_paid||0).toFixed(2);const pc=$('#page-payments .cards article:nth-child(4) span');if(pc)pc.textContent=d.pending_count||0;const today=new Date().toISOString().slice(0,10);const todayRows=rows.filter(r=>String(r.created_at||'').slice(0,10)===today);if($('#todayTxn'))$('#todayTxn').textContent=todayRows.length;if($('#upiTxn'))$('#upiTxn').textContent=todayRows.filter(r=>r.method==='UPI').length;if($('#pendingPay'))$('#pendingPay').textContent=d.pending_count||0;$$('.proof-btn').forEach(b=>b.onclick=async()=>{const r=rows.find(x=>String(x.id)===b.dataset.id);if(!r?.proof_available)return;const w=window.open('','_blank','width=820,height=820');if(!w)return toast('Popup blocked — screenshot देखने के लिए popup allow करें');w.document.write('<!doctype html><html><head><meta charset=\"utf-8\"><title>Payment Proof</title><style>body{font-family:Arial;padding:20px;background:#f5f8fc}.box{background:#fff;border:1px solid #dbe5f0;border-radius:16px;padding:18px;max-width:760px;margin:auto}img{display:block;max-width:100%;max-height:620px;margin:15px auto;border:1px solid #dbe5f0;border-radius:10px}button{padding:10px 14px;border:0;border-radius:9px;background:#0b73e0;color:#fff;cursor:pointer}</style></head><body><div class=\"box\"><h2>📷 Payment Screenshot Verification</h2><p>Loading secure proof…</p></div></body></html>');w.document.close();try{const rr=await fetch(backendUrl.replace(/\/$/, '')+'/api/payments/proof/'+encodeURIComponent(String(r.id)),{credentials:'include'});if(!rr.ok)throw new Error('Screenshot load failed');const blob=await rr.blob(),url=URL.createObjectURL(blob),safe=x=>String(x??'').replace(/[<>&"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','\"':'&quot;'}[c]));w.document.body.innerHTML='<div class=\"box\"><h2>📷 Payment Screenshot Verification</h2><p><b>Customer:</b> '+safe(r.name)+' · <b>Mobile:</b> '+safe(r.mobile||'—')+'</p><p><b>Service:</b> '+safe(r.service||'—')+' · <b>Amount:</b> ₹'+safe(Number(r.amount||0).toFixed(2))+'</p><p><b>UTR:</b> '+safe(r.utr||'—')+'</p><img src=\"'+url+'\" alt=\"Payment screenshot\"><button onclick=\"window.print()\">Print / Save</button></div>';b.dataset.viewed='1';const verify=document.querySelector('.verify-pay[data-id=\"'+r.id+'\"]');if(verify)verify.disabled=false;const reject=document.querySelector('.reject-pay[data-id=\"'+r.id+'\"]');if(reject)reject.disabled=false;w.addEventListener('beforeunload',()=>URL.revokeObjectURL(url));}catch(e){w.document.body.innerHTML='<div style=\"font-family:Arial;padding:30px\"><h3>Screenshot load failed</h3><p>'+String(e.message||e)+'</p></div>';toast(e.message)}});
$$('.verify-pay').forEach(b=>b.onclick=async()=>{const r=rows.find(x=>String(x.id)===b.dataset.id);if(!r)return;const utr=String(r.utr||'').trim();const proof=r.proof_available?'Screenshot उपलब्ध':'UTR only';const details=`Payment ID: ${r.id}\nCustomer: ${r.name||'—'}\nAmount: ₹${Number(r.amount||0).toFixed(2)}\nUTR: ${utr||'—'}\nProof: ${proof}\n\nइस payment को verify करके token gate खोलें?`;if(!(await angelConfirm(details,utr||'—')))return;try{const v=await api('/api/payments/status',{method:'POST',body:JSON.stringify({id:+b.dataset.id,status:'Verified'})});toast('Payment verified: '+(v.receipt_no||''));loadPayments()}catch(e){toast(e.message)}});$$('.reject-pay').forEach(b=>b.onclick=async()=>{if(!(await angelConfirm('इस payment को reject करें?')))return;try{await api('/api/payments/status',{method:'POST',body:JSON.stringify({id:+b.dataset.id,status:'Rejected',reason:(await angelPrompt('Reject reason लिखें:'))||'Payment proof rejected'})});toast('Payment rejected');loadPayments()}catch(e){toast(e.message)}});$$('.receipt-btn').forEach(b=>b.onclick=()=>{const r=rows.find(x=>String(x.id)===b.dataset.id);showReceipt(r?.name||b.dataset.name||'—',r?.mobile||'—',r?.service||'सेवा शुल्क',b.dataset.receipt,'₹ '+Number(r?.amount??b.dataset.amount??0).toFixed(2))})}catch(e){toast(e.message)}}
$$('.filters button').forEach(b=>b.onclick=()=>{const label=b.textContent.trim().toLowerCase();paymentFilter=label==='upi'?'upi':label==='cash'?'cash':label==='bank transfer'?'bank transfer':'all';$$('.filters button').forEach(x=>x.classList.remove('sel'));b.classList.add('sel');loadPayments()});
$('#payMethod').onchange=()=>{$('#utrWrap').style.display=$('#payMethod').value==='Cash'?'none':'';if($('#payProofWrap'))$('#payProofWrap').style.display=$('#payMethod').value==='Cash'?'none':''};$('#payMethod').dispatchEvent(new Event('change'));$('#savePayment').onclick=async()=>{try{const method=$('#payMethod').value,service=$('#payService')?.value?.trim()||'',file=$('#payProof')?.files?.[0];if(method!=='Cash'&&(!$('#payUtr').value.trim()||!file))return toast('UPI/Bank payment में UTR और Screenshot/Proof दोनों दें');let proof_data='';if(file){if(!/^image\/(png|jpeg|webp)$/.test(file.type)||file.size>5*1024*1024)return toast('Proof PNG/JPG/WEBP और अधिकतम 5 MB होना चाहिए');proof_data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(new Error('Proof file read नहीं हो सकी'));r.readAsDataURL(file)})}const payload={service,name:$('#payName').value.trim(),mobile:$('#payMobile').value.trim(),application_id:Number($('#payApplication').value||0)||null,amount:Number($('#payAmount').value||0),method,utr:$('#payUtr').value.trim(),payment_date:$('#payDate').value,proof_data};if(!payload.service)return toast('Service चुनें');if(!payload.name||!/^[0-9]{10}$/.test(payload.mobile))return toast('नाम और 10 digit mobile भरें');if(!payload.amount)return toast('राशि भरें');if(method!=='Cash'&&(!payload.utr||!proof_data))return toast('UPI/Bank payment में UTR और Screenshot/Proof दोनों दें');const d=await api('/api/payments',{method:'POST',body:JSON.stringify(payload)});toast(d.status==='Verified'?'Cash payment verified और receipt तैयार':'Payment दर्ज: proof verify होने तक Pending रहेगा');$('#paymentModal').classList.add('hidden');if($('#payProof'))$('#payProof').value='';loadPayments()}catch(e){toast(e.message)}};
function showReceipt(name,mobile,service,token,amount){$('#rName').textContent=name;$('#rMobile').textContent=mobile;$('#rService').textContent=service;$('#rToken').textContent=token;$('#rAmount').textContent=String(amount).startsWith('₹')?amount:'₹ '+amount;$('#receiptModal').classList.remove('hidden')}$('#closeReceipt').onclick=()=>$('#receiptModal').classList.add('hidden');$('#printReceipt').onclick=()=>window.print();$('#saveReceipt').onclick=()=>window.print();
$('#newPayment').onclick=()=>{$('#paymentModal').classList.remove('hidden');$('#payDate').value=new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16);if($('#payService'))$('#payService').innerHTML=backendServiceCatalog.flatMap(g=>(g.services||[]).map(v=>({category:g.category,name:v.name}))).map(v=>`<option value="${escapeHtml(v.category+' — '+v.name)}">${escapeHtml(v.category+' — '+v.name)}</option>`).join('');$('#payName').focus()};$('#closePayment').onclick=()=>$('#paymentModal').classList.add('hidden');$('#cancelPayment').onclick=()=>$('#paymentModal').classList.add('hidden');
$('#adminRequestForm')?.addEventListener('submit',async(e)=>{e.preventDefault();

 const name=$('#reqName').value.trim(),mobile=$('#reqMobile').value.trim(),service=$('#reqService').value.trim();
 if(!name||!/^[0-9]{10}$/.test(mobile)||!service)return toast('नाम, सही मोबाइल और सेवा भरें');
 try{const d=await api('/api/applications',{method:'POST',body:JSON.stringify({name,mobile,service,category:$('#reqCat').value,address:$('#reqAddress').value,note:$('#reqNote').value})});
 currentCustomer={name,mobile};fillCustomer(currentCustomer);
 $('#tokenName').value=name;$('#tokenMobile').value=mobile;populateTokenServices(service);$('#tokenService').value=service;
 let uploadWarning='';
 try{await uploadFiles(d.id)}catch(e){uploadWarning=' Application save हो गया है, लेकिन document upload पूरा नहीं हुआ: '+e.message;}
 toast('Application '+d.application_id+' सेव हो गया।'+(uploadWarning||' अब Payment में UTR + Screenshot submit करके Admin verification का इंतज़ार करें।'));go('payments');
 }catch(e){toast(e.message)}
});

async function uploadFiles(aid){
 const files=[...($('#fileInput')?.files||[])];if(!files.length)return;
 if(files.length>5)throw new Error('एक application में अधिकतम 5 documents upload कर सकते हैं');
 const allowed=new Set(['application/pdf','image/jpeg','image/png','image/webp']);
 let total=0;
 const payload=[];
 for(const f of files){
   if(!allowed.has(f.type))throw new Error(f.name+' का file type supported नहीं है');
   if(f.size>5*1024*1024)throw new Error(f.name+' 5 MB से बड़ा है');
   total+=f.size;if(total>10*1024*1024)throw new Error('सभी documents का कुल size 10 MB से अधिक है');
   const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result||''));r.onerror=()=>reject(new Error('File read failed: '+f.name));r.readAsDataURL(f)});
   payload.push({name:f.name,mime_type:f.type,data});
 }
 await api('/api/documents',{method:'POST',body:JSON.stringify({application_id:aid,files:payload})});
 toast(files.length+' document(s) server पर सुरक्षित upload हो गए।');
}
$('#fileInput').onchange=e=>{const list=$('#fileList');list.innerHTML='';[...e.target.files].forEach(f=>{const d=document.createElement('div');d.className='file-item';d.textContent='📎 '+f.name+' ('+(f.size/1024/1024).toFixed(1)+' MB)';list.appendChild(d)});$('#reqProgress').style.width='100%';$('#reqHint').textContent='Documents ready हैं। आवेदन submit करने पर server पर सुरक्षित upload होंगे।'}
$('#resetReq').onclick=()=>{$('#reqName').value='';$('#reqMobile').value='';$('#reqNote').value='';$('#reqAddress').value='';$('#fileList').innerHTML='';$('#reqProgress').style.width='0';$('#fileInput').value=''};
let liveEditId=null;
function resetLiveOfferForm(){liveEditId=null;['liveTitle','liveSubtitle','liveDescription','liveService','liveOriginal','livePrice','liveDiscount','liveValid','liveLastDate','liveStart','liveExpire','liveImage','liveTicker'].forEach(id=>{if($('#'+id))$('#'+id).value=''});if($('#liveType'))$('#liveType').value='OFFER';if($('#liveUpdateCategory'))$('#liveUpdateCategory').value='Online Form';if($('#livePriority'))$('#livePriority').value='0';if($('#livePublished'))$('#livePublished').value='true';$('#liveOfferEditMsg')&&($('#liveOfferEditMsg').textContent='नया content बनाएं या list से Edit करें।');toggleLiveManagerFields();}
function toggleLiveManagerFields(){const offer=$('#liveType')?.value==='OFFER';$('#offerFields')?.classList.toggle('hidden',!offer);$('#updateFields')?.classList.toggle('hidden',offer);if($('#liveFormHeading'))$('#liveFormHeading').textContent=offer?'🔥 LIVE OFFER':'📰 LIVE UPDATE';}
async function loadLiveOffersAdmin(){try{const d=await api('/api/offers?all=1');const rows=d.offers||[];$('#liveOfferAdminCount').textContent=String(rows.length);$('#liveOfferAdminList').innerHTML=rows.map(o=>`<div class="live-admin-item"><div><b>${o.type==='OFFER'?'🔥 ': '📰 '}${escapeHtml(o.title)}</b><p class="note" style="margin:5px 0">${escapeHtml(o.subtitle||o.description||'')}</p><div class="live-admin-meta"><span>${o.type==='OFFER'?'LIVE OFFER':escapeHtml(o.update_category||'LIVE UPDATE')}</span><span>${o.archived?'🗄️ Archived':(o.published?'🟢 Published':'⚪ Draft')}</span><span>Priority: ${escapeHtml(o.priority||0)}</span>${o.last_date?`<span>Last Date: ${escapeHtml(o.last_date)}</span>`:''}${o.expires_at?`<span>Expire: ${escapeHtml(o.expires_at)}</span>`:''}${o.offer_price?`<span>Offer ₹${escapeHtml(o.offer_price)}</span>`:''}${o.discount?`<span>Discount ${escapeHtml(o.discount)}%</span>`:''}</div></div><div class="live-admin-actions"><button data-edit-offer="${o.id}">✏️ Edit</button>${o.archived?`<button class="restore" data-restore-offer="${o.id}">♻️ Restore</button>`:`<button class="pub" data-pub-offer="${o.id}" data-state="${o.published?'on':'off'}">${o.published?'⏸ Unpublish':'🟢 Publish'}</button><button class="del" data-del-offer="${o.id}">🗄️ Archive</button>`}</div></div>`).join('')||'<div class="update-empty">अभी कोई LIVE SCREEN content नहीं है।</div>';$$('[data-edit-offer]').forEach(b=>b.onclick=()=>{const o=rows.find(x=>String(x.id)===b.dataset.editOffer);if(!o)return;liveEditId=o.id;[['liveType','type'],['liveTitle','title'],['liveSubtitle','subtitle'],['liveDescription','description'],['liveService','service'],['liveOriginal','original_price'],['livePrice','offer_price'],['liveDiscount','discount'],['liveValid','valid'],['liveLastDate','last_date'],['liveStart','starts_at'],['liveExpire','expires_at'],['liveImage','image'],['liveTicker','ticker'],['livePriority','priority'],['livePublished','published'],['liveUpdateCategory','update_category']].forEach(([id,k])=>{if($('#'+id))$('#'+id).value=o[k]??''});$('#liveOfferEditMsg').textContent='Editing: '+o.title;toggleLiveManagerFields();window.scrollTo({top:0,behavior:'smooth'})});$$('[data-pub-offer]').forEach(b=>b.onclick=async()=>{try{await api('/api/offers/'+b.dataset.pubOffer,{method:'POST',body:JSON.stringify({action:b.dataset.state==='on'?'unpublish':'publish'})});loadLiveOffersAdmin();toast('LIVE SCREEN status updated')}catch(e){toast(e.message)}});$$('[data-del-offer]').forEach(b=>b.onclick=async()=>{if(!(await angelConfirm('इस LIVE SCREEN item को archive करें? यह permanently delete नहीं होगा।')))return;try{await api('/api/offers/'+b.dataset.delOffer,{method:'POST',body:JSON.stringify({action:'delete'})});loadLiveOffersAdmin();toast('Archived — history सुरक्षित है')}catch(e){toast(e.message)}});$$('[data-restore-offer]').forEach(b=>b.onclick=async()=>{try{await api('/api/offers/'+b.dataset.restoreOffer,{method:'POST',body:JSON.stringify({action:'restore'})});loadLiveOffersAdmin();toast('Offer restored — अभी publish करना बाकी है')}catch(e){toast(e.message)}})}catch(e){toast(e.message)}}
$('#liveType')?.addEventListener('change',toggleLiveManagerFields);
$$('[data-live-tab]').forEach(b=>b.onclick=()=>{const t=b.dataset.liveTab;$$('[data-live-tab]').forEach(x=>x.classList.toggle('sel',x===b));if($('#liveType'))$('#liveType').value=t==='offer'?'OFFER':'UPDATE';toggleLiveManagerFields()});
$('#newLiveOffer')?.addEventListener('click',resetLiveOfferForm);$('#cancelLiveOffer')?.addEventListener('click',resetLiveOfferForm);$('#liveOfferForm')?.addEventListener('submit',async(e)=>{e.preventDefault();try{const type=$('#liveType').value;const payload={type,title:$('#liveTitle').value.trim(),subtitle:$('#liveSubtitle').value.trim(),description:$('#liveDescription').value.trim(),service:$('#liveService').value.trim(),original_price:$('#liveOriginal').value,offer_price:$('#livePrice').value,discount:$('#liveDiscount').value,save_amount:$('#liveOriginal').value&&$('#livePrice').value?Math.max(0,Number($('#liveOriginal').value)-Number($('#livePrice').value)).toFixed(2):'',valid:$('#liveValid').value,last_date:$('#liveLastDate').value,update_category:$('#liveUpdateCategory').value,image:$('#liveImage').value.trim(),ticker:$('#liveTicker').value.trim(),priority:Number($('#livePriority').value||0),starts_at:$('#liveStart').value,expires_at:$('#liveExpire').value,published:$('#livePublished').value==='true'};if(!payload.title)return toast('Title जरूरी है');if(type==='OFFER'&&payload.offer_price&&payload.original_price&&Number(payload.offer_price)>Number(payload.original_price))return toast('Offer Price, Original Price से अधिक नहीं होना चाहिए');const was=liveEditId;if(was)await api('/api/offers/'+was,{method:'POST',body:JSON.stringify(payload)});else await api('/api/offers',{method:'POST',body:JSON.stringify(payload)});toast(was?'LIVE SCREEN updated':'LIVE SCREEN content saved');resetLiveOfferForm();loadLiveOffersAdmin()}catch(e){toast(e.message)}});
async function loadNotifications(){try{const d=await api('/api/notifications');$('#notificationList').innerHTML=(d.notifications||[]).map(n=>`<div class="notification ${n.read_at?'':'unread'}"><div class="nicon">${n.type==='warning'?'⚠️':n.type==='success'?'✓':'ℹ️'}</div><div><b>${escapeHtml(n.title)}</b><small>${escapeHtml(n.message)} · ${escapeHtml(n.created_at)}</small></div><button data-n="${n.id}" style="margin-left:auto">${n.read_at?'पढ़ा हुआ':'पढ़ें'}</button></div>`).join('')||'<div class="panel">कोई notification नहीं है</div>';$$('[data-n]').forEach(b=>b.onclick=async()=>{await api('/api/notifications/read',{method:'POST',body:JSON.stringify({id:+b.dataset.n})});loadNotifications()})}catch(e){toast(e.message)}}
$('#markAll').onclick=async()=>{try{await api('/api/notifications/read',{method:'POST',body:JSON.stringify({})});loadNotifications();toast('सभी notifications पढ़े गए')}catch(e){toast(e.message)}};
async function loadSettings(){try{const d=await api('/api/settings');const s=d.settings||{};for(const [id,key] of [['setCentre','centre'],['setOperator','operator'],['setNotify','notify'],['setCounters','counters'],['setFee','fee'],['setFooter','footer'],['setUpiId','upi_id'],['setPayeeName','payee_name'],['setPaymentQrPath','payment_qr_path'],['setBankName','bank_name'],['setBankAccountName','bank_account_name'],['setBankAccountNumber','bank_account_number'],['setBankIfsc','bank_ifsc'],['setBankBranch','bank_branch']])if($('#'+id)&&s[key]!=null)$('#'+id).value=s[key]}catch(e){toast(e.message)}}
$('#settingsForm')?.addEventListener('submit',async(e)=>{e.preventDefault();try{await api('/api/settings',{method:'POST',body:JSON.stringify({centre:$('#setCentre').value,operator:$('#setOperator').value,notify:$('#setNotify').value,counters:$('#setCounters').value,fee:$('#setFee').value,footer:$('#setFooter').value,upi_id:$('#setUpiId').value.trim(),payee_name:$('#setPayeeName').value.trim(),payment_qr_path:$('#setPaymentQrPath').value.trim(),bank_name:$('#setBankName').value.trim(),bank_account_name:$('#setBankAccountName').value.trim(),bank_account_number:$('#setBankAccountNumber').value.trim(),bank_ifsc:$('#setBankIfsc').value.trim().toUpperCase(),bank_branch:$('#setBankBranch').value.trim()})});toast('Settings server पर सेव हो गईं')}catch(e){toast(e.message)}});
async function loadHomepageHeroAdminPreview(){try{const d=await api('/api/public-config');const url=String(d.homepage_hero_image||'assets/customer-home-reference-visual-crop.png');const src=url.startsWith('/api/')?(backendUrl.replace(/\/$/,'')+url):url;const box=$('#homepageHeroPreview');if(box)box.innerHTML=`<img src="${escapeHtml(src)}?v=${Date.now()}" alt="Homepage hero preview">`; }catch{}}
$('#setHomepageHeroImage')?.addEventListener('change',()=>{const f=$('#setHomepageHeroImage').files?.[0],box=$('#homepageHeroPreview');if(!f||!box)return;if(!['image/png','image/jpeg','image/webp'].includes(f.type)||f.size>5*1024*1024){box.innerHTML='<span class="muted">केवल PNG/JPG/WEBP और 5 MB तक image चुनें।</span>';return}const url=URL.createObjectURL(f);box.innerHTML=`<img src="${url}" alt="New homepage hero preview">`;});
$('#uploadHomepageHero')?.addEventListener('click',async()=>{const f=$('#setHomepageHeroImage')?.files?.[0],status=$('#homepageHeroUploadStatus'),btn=$('#uploadHomepageHero');if(!f)return toast('पहले homepage image चुनें');if(!['image/png','image/jpeg','image/webp'].includes(f.type)||f.size>5*1024*1024)return toast('केवल PNG/JPG/WEBP और 5 MB तक image allowed है');btn.disabled=true;status.textContent='Uploading…';try{const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(new Error('Image read failed'));r.readAsDataURL(f)});const d=await api('/api/admin/homepage-hero',{method:'POST',body:JSON.stringify({image_data:data,filename:f.name})});status.textContent='Homepage image update हो गया।';$('#setHomepageHeroImage').value='';await loadHomepageHeroAdminPreview();toast('Homepage image सफलतापूर्वक बदल गया।')}catch(e){status.textContent=e.message||'Upload failed';toast(status.textContent)}finally{btn.disabled=false}});

async function loadBackupStatus(){try{const d=await api('/api/admin/backup-status');const box=$('#backupStatus');if(!box)return;box.innerHTML=`<div class="notification"><div><b>Backup Schedule</b><small>${d.scheduled_enabled?'Enabled':'Disabled'} · हर ${d.interval_hours} घंटे · Retention ${d.retention}</small></div><div><small>Off-site: ${d.offsite_configured?'Configured':'Not configured'} · Last: ${escapeHtml(d.last_backup||'—')}</small></div></div>`}catch(e){toast(e.message)}}
async function loadBackups(){try{await loadBackupStatus();const d=await api('/api/admin/backups');const box=$('#backupList');if(!box)return;box.innerHTML=(d.backups||[]).map(x=>`<div class="notification"><div><b>${escapeHtml(x.name)}</b><small>${escapeHtml(new Date(x.created_at).toLocaleString('hi-IN'))} · ${escapeHtml((Number(x.size||0)/1024).toFixed(1))} KB</small></div><div><button class="btn" data-backup-download="${escapeHtml(x.name)}">Download</button><button class="btn" data-backup-verify="${escapeHtml(x.name)}">Verify</button><button class="btn danger" data-backup-restore="${escapeHtml(x.name)}">Restore</button></div></div>`).join('')||'<p class="muted">अभी कोई backup नहीं है।</p>';$$('[data-backup-download]').forEach(b=>b.onclick=()=>{const a=document.createElement('a');a.href=backendUrl.replace(/\/$/,'')+'/api/admin/backups/'+encodeURIComponent(b.dataset.backupDownload)+'?download=1';a.download=b.dataset.backupDownload;fetch(a.href,{credentials:'include'}).then(r=>{if(!r.ok)throw new Error('Backup download failed');return r.blob()}).then(blob=>{a.href=URL.createObjectURL(blob);a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}).catch(e=>toast(e.message))});$$('[data-backup-verify]').forEach(b=>b.onclick=async()=>{try{const d=await api('/api/admin/backup/verify',{method:'POST',body:JSON.stringify({name:b.dataset.backupVerify})});toast('Backup integrity PASS · '+d.payment_proofs+' proofs · '+d.documents+' documents')}catch(e){toast('Backup integrity FAIL: '+e.message)}});$$('[data-backup-restore]').forEach(b=>b.onclick=async()=>{if(!(await angelConfirm('इस backup से current database restore करना है? Restore से पहले automatic safety backup बनेगा.')))return;const current_password=await angelPrompt('Security verification: current Admin password दर्ज करें');if(!current_password)return;try{const d=await api('/api/admin/restore',{method:'POST',body:JSON.stringify({name:b.dataset.backupRestore,current_password})});toast('Restore सफल। Safety backup: '+d.pre_restore_backup);setTimeout(()=>location.reload(),700)}catch(e){toast(e.message)}})}catch(e){toast(e.message)}}
$('#createBackup')?.addEventListener('click',async()=>{try{const d=await api('/api/admin/backup',{method:'POST'});toast('Backup बन गया: '+d.backup.name+(d.backup.offsite?.uploaded?' · Off-site OK':''));loadBackups()}catch(e){toast(e.message)}});$('#refreshBackups')?.addEventListener('click',loadBackups);
$('#refreshPreflight')?.addEventListener('click',loadPreflight);$('#refreshSecurityAudit')?.addEventListener('click',loadSecurityAudit);$('#refreshMonitoring')?.addEventListener('click',loadMonitoring);$('#fromDate').onchange=()=>{loadReports();loadAdvancedReports()};$('#toDate').onchange=()=>{loadReports();loadAdvancedReports()};$('#refreshControl').onclick=loadControl;$('#downloadReport').onclick=async()=>{try{const r=await fetch(backendUrl.replace(/\/$/,'')+'/api/report.csv'+((()=>{const q=new URLSearchParams();if($('#fromDate')?.value)q.set('from',$('#fromDate').value);if($('#toDate')?.value)q.set('to',$('#toDate').value);return q.toString()?'?'+q.toString():''})()),{credentials:'include'});if(!r.ok)throw new Error('Report download failed');const blob=await r.blob(),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='angelstore-report.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast('Report download हो गई')}catch(e){toast(e.message)}};
async function loadReports(){try{const from=$('#fromDate')?.value||'';const to=$('#toDate')?.value||'';const qs=(from?'?from='+encodeURIComponent(from):'')+(to?(from?'&':'?')+'to='+encodeURIComponent(to):'');const d=await api('/api/reports'+qs);const s=d.summary||{};const cards=$$('#page-reports .cards article span');if(cards[0])cards[0].textContent=s.total||0;if(cards[1])cards[1].textContent=s.completed||0;if(cards[2])cards[2].textContent=s.pending||0;if(cards[3])cards[3].textContent=s.cancelled||0;const sum=$$('#page-reports .summary-row b');if(sum[0])sum[0].textContent=d.popular?.service||'—';if(sum[1]){sum[1].textContent=Number(d.average_wait_minutes||0)+' मिनट';}if(sum[2])sum[2].textContent=(Number(s.total||0)?Math.round(Number(s.completed||0)*100/Number(s.total||0)):0)+'%';if(sum[3])sum[3].textContent='₹ '+Number(d.revenue||0).toFixed(2);const daily=d.daily||[];const svg=$('#reportChart');if(svg){const pts=daily.slice(-7);const max=Math.max(1,...pts.map(x=>Number(x.n||0)));const points=pts.map((x,i)=>{const px=30+(i*(640/Math.max(1,pts.length-1)));const py=210-(Number(x.n||0)/max)*160;return px.toFixed(1)+','+py.toFixed(1)}).join(' ');svg.innerHTML=pts.length?`<polyline points="${points}" fill="none" stroke="currentColor" stroke-width="4"/>`+pts.map((x,i)=>{const px=30+(i*(640/Math.max(1,pts.length-1)));const py=210-(Number(x.n||0)/max)*160;return `<circle cx="${px}" cy="${py}" r="6"/>`}).join(''):'<text x="350" y="130" text-anchor="middle">कोई token data नहीं</text>';const xl=$('#reportLabels');if(xl)xl.innerHTML=pts.map(x=>`<span>${x.d}</span>`).join('');}}catch(e){toast(e.message)}}
async function loadDashboard(){try{const d=await api('/api/tokens');const all=d.tokens||[],today=new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Kolkata'}),t=all.filter(x=>String(x.date||x.created_at||'').slice(0,10)===today);const unique=new Set(t.map(x=>x.mobile).filter(Boolean)).size;if($('#statTokens'))$('#statTokens').textContent=t.length;if($('#statCustomers'))$('#statCustomers').textContent=unique;if($('#statServices'))$('#statServices').textContent=services.length;const activeForWait=t.filter(x=>!['पूर्ण','रद्द','स्किप'].includes(x.status));const waitValues=activeForWait.map(x=>Number(x.estimated_wait_minutes)).filter(Number.isFinite);const averageWait=waitValues.length?Math.round(waitValues.reduce((a,b)=>a+b,0)/waitValues.length):0;if($('#statWait'))$('#statWait').textContent=averageWait+' मिनट';renderLive(t);renderHomeAnalytics(all);if($('#adminCustomers'))$('#adminCustomers').textContent=unique;if($('#adminRequests'))$('#adminRequests').textContent=t.length;if($('#adminServices'))$('#adminServices').textContent=services.length;const completed=t.filter(x=>x.status==='पूर्ण').length;if($('#adminCompletion'))$('#adminCompletion').textContent=(t.length?Math.round(completed*100/t.length):0)+'%'}catch(e){toast(e.message)}}

async function loadServiceCharges(){
 const box=$('#serviceChargesRows'); if(!box)return;
 const saved=(await api('/api/service-charges')).charges||[];
 const map=new Map(saved.map(x=>[x.category+'||'+x.service,x]));
 const rows=[];
 const source=backendServiceCatalog.length?backendServiceCatalog:Object.entries(SERVICE_INFO).map(([category,v])=>({category,services:v.services||[]}));
 source.forEach(group=>(group.services||[]).forEach(svc=>{
   const cat=group.category, key=cat+'||'+svc.name, x=map.get(key)||{};
   const govtDefault=Number(String(svc.govt||'').match(/[₹]\s*([0-9]+(?:\.[0-9]+)?)/)?.[1]||0);
   rows.push({category:cat,service:svc.name,govt_fee:x.govt_fee??govtDefault,csc_fee:x.csc_fee??Number(svc.csc||0),other_fee:x.other_fee??0});
 }));
 box.innerHTML=rows.map((r,i)=>`<tr><td>${escapeHtml(r.category)}</td><td><b>${escapeHtml(r.service)}</b></td><td><input class="sc-govt" data-i="${i}" type="number" min="0" step="0.01" value="${r.govt_fee}"></td><td><input class="sc-csc" data-i="${i}" type="number" min="0" step="0.01" value="${r.csc_fee}"></td><td><input class="sc-other" data-i="${i}" type="number" min="0" step="0.01" value="${r.other_fee}"></td><td class="sc-total" data-i="${i}">₹${(Number(r.govt_fee)+Number(r.csc_fee)+Number(r.other_fee)).toFixed(2)}</td><td><button class="primary sc-save" data-i="${i}">Save</button></td></tr>`).join('');
 window._serviceChargeRows=rows;
 box.querySelectorAll('input').forEach(inp=>inp.oninput=()=>{const i=Number(inp.dataset.i),g=Number(box.querySelector(`.sc-govt[data-i="${i}"]`).value||0),c=Number(box.querySelector(`.sc-csc[data-i="${i}"]`).value||0),o=Number(box.querySelector(`.sc-other[data-i="${i}"]`).value||0);box.querySelector(`.sc-total[data-i="${i}"]`).textContent='₹'+(g+c+o).toFixed(2)});
 box.querySelectorAll('.sc-save').forEach(btn=>btn.onclick=async()=>{const i=Number(btn.dataset.i),r=window._serviceChargeRows[i],g=Number(box.querySelector(`.sc-govt[data-i="${i}"]`).value||0),c=Number(box.querySelector(`.sc-csc[data-i="${i}"]`).value||0),o=Number(box.querySelector(`.sc-other[data-i="${i}"]`).value||0);try{await api('/api/service-charges',{method:'POST',body:JSON.stringify({category:r.category,service:r.service,govt_fee:g,csc_fee:c,other_fee:o})});toast('Charges saved: '+r.service)}catch(e){toast(e.message)}});
}
let _sopRows=[];
async function loadSopPage(){const cat=$('#sopCategory'),svc=$('#sopService');if(!cat||!svc)return;try{const d=await api('/api/sops');_sopRows=d.sops||[];const cats=[...new Set(_sopRows.map(x=>x.category))];cat.innerHTML=cats.map(x=>`<option>${escapeHtml(x)}</option>`).join('');const refresh=()=>{const rows=_sopRows.filter(x=>x.category===cat.value);svc.innerHTML=rows.map(x=>`<option value="${escapeHtml(x.service)}">${escapeHtml(x.service.split(' — ').slice(1).join(' — '))}</option>`).join('');const r=rows[0];if(r)fillSop(r)};const fillSop=r=>{svc.value=r.service;$('#sopDocs').value=(r.documents||[]).join('\n');$('#sopSteps').value=(r.steps||[]).join('\n');$('#sopNote').value=r.note||'';$('#sopChecks').innerHTML=(r.checks||[]).map((c,i)=>`<div class="form-row" style="margin:8px 0"><input class="sop-check-label" data-i="${i}" value="${escapeHtml(c.label||'')}" placeholder="Checklist item"><label><input class="sop-check-required" data-i="${i}" type="checkbox" ${c.required!==false?'checked':''}> Required</label></div>`).join('')||'<p class="muted">No custom checklist; generic review checklist लागू होगा।</p>'};cat.onchange=refresh;svc.onchange=()=>{const r=_sopRows.find(x=>x.service===svc.value);if(r)fillSop(r)};refresh();$('#checkSopPattern').onclick=()=>{const result=$('#sopPatternResult');const labels=[...document.querySelectorAll('.sop-check-label')].map(x=>x.value.trim()).filter(Boolean);const required=[...document.querySelectorAll('.sop-check-required')].filter(x=>x.checked);const docs=$('#sopDocs').value.split('\n').map(x=>x.trim()).filter(Boolean);const steps=$('#sopSteps').value.split('\n').map(x=>x.trim()).filter(Boolean);const dup=labels.filter((x,i,a)=>a.findIndex(v=>v.toLowerCase()===x.toLowerCase())!==i);const problems=[];if(!svc.value)problems.push('Service select नहीं है');if(!docs.length)problems.push('Required Documents खाली हैं');if(!steps.length)problems.push('SOP Steps खाली हैं');if(!labels.length)problems.push('Checklist item नहीं है');if(labels.length&&!required.length)problems.push('कम-से-कम 1 Required checklist item होना चाहिए');if(dup.length)problems.push('Duplicate checklist item: '+dup.join(', '));if(problems.length){result.textContent='❌ Pattern Invalid: '+problems.join(' · ');result.style.color='#b42318'}else{result.textContent='✅ Pattern Valid — '+labels.length+' checklist item(s), '+required.length+' required. SOP Save किया जा सकता है।';result.style.color='#16834b'}};$('#sopForm')?.addEventListener('submit',async(e)=>{e.preventDefault();try{const checks=[...document.querySelectorAll('.sop-check-label')].map((el,i)=>({id:'check_'+(i+1),label:el.value.trim(),required:document.querySelector(`.sop-check-required[data-i="${i}"]`)?.checked!==false})).filter(x=>x.label);const r=await api('/api/sops',{method:'POST',body:JSON.stringify({service:svc.value,documents:$('#sopDocs').value.split('\n').map(x=>x.trim()).filter(Boolean),steps:$('#sopSteps').value.split('\n').map(x=>x.trim()).filter(Boolean),note:$('#sopNote').value.trim(),checks})});toast('SOP saved: '+r.sop.service);loadSopPage()}catch(e){toast(e.message)}});$('#refreshSop').onclick=loadSopPage}catch(e){toast(e.message)}}
async function loadAdminComplaints(){try{const d=await api('/api/admin/complaints');const rows=d.complaints||[];const el=$('#adminComplaintsRows');if(!el)return;el.innerHTML=rows.length?rows.map(x=>`<tr><td><b>${escapeHtml(x.complaint_id)}</b></td><td>${escapeHtml(x.name||'—')}<br><small>${escapeHtml(x.mobile||'')}</small></td><td>${escapeHtml(x.category)}</td><td>${escapeHtml(x.title)}<br><small>${escapeHtml(x.description)}</small></td><td>${escapeHtml(x.status)}</td><td><select data-complaint-status="${x.id}"><option value="open" ${x.status==='open'?'selected':''}>Open</option><option value="in_progress" ${x.status==='in_progress'?'selected':''}>In Progress</option><option value="resolved" ${x.status==='resolved'?'selected':''}>Resolved</option><option value="closed" ${x.status==='closed'?'selected':''}>Closed</option></select><button type="button" class="primary" data-complaint-save="${x.id}">Save</button></td></tr>`).join(''):'<tr><td colspan="6">कोई support request नहीं है।</td></tr>';el.querySelectorAll('[data-complaint-save]').forEach(b=>b.onclick=async()=>{const id=Number(b.dataset.complaintSave),sel=el.querySelector(`[data-complaint-status="${id}"]`);b.disabled=true;try{await api('/api/admin/complaints/update',{method:'POST',body:JSON.stringify({id,status:sel.value})});await loadAdminComplaints();await loadControl();toast('Complaint status updated')}catch(e){toast(e.message)}finally{b.disabled=false}})}catch(e){toast(e.message)}}
async function loadControl(){try{const [d,qc]=await Promise.all([api('/api/control-center'),api('/api/admin/quality-review')]);await loadAdminComplaints();const k=d.kpis||{};[['ccTokens',k.tokens],['ccActive',k.active_tokens],['ccPay',k.pending_payments],['ccQC',k.qc_pending],['ccUnassigned',k.unassigned_tokens],['ccStaff',k.active_staff]].forEach(([id,v])=>{if($('#'+id))$('#'+id).textContent=v??0});$('#ccAlerts').innerHTML=(d.alerts||[]).map(a=>`<div class="notification ${a.severity==='high'?'unread':''}"><div class="nicon">${a.severity==='high'?'⚠️':'ℹ️'}</div><div><b>${escapeHtml(a.label)}</b><small>${escapeHtml(a.count)} item(s)</small></div></div>`).join('')||'<p class="muted">कोई pending alert नहीं।</p>';$('#ccOps').innerHTML=`<div class="summary-row"><span>Completed</span><b>${k.completed||0}</b></div><div class="summary-row"><span>Home pending</span><b>${k.home_pending||0}</b></div><div class="summary-row"><span>Open complaints</span><b>${k.open_complaints||0}</b></div>`;const rows=(qc.items||[]).filter(x=>x.token.quality_status!=='passed');$('#adminQualityRows').innerHTML=rows.length?rows.map(x=>`<tr><td><b>${escapeHtml(x.token.token)}</b></td><td>${escapeHtml(x.token.name)}</td><td>${escapeHtml(x.token.service)}</td><td>${escapeHtml(x.token.staff_id||'—')}</td><td>${escapeHtml(x.token.quality_status||'needs_review')}</td><td><button class="primary" type="button" data-qc-review="${x.token.id}">Review</button></td></tr>`).join(''):'<tr><td colspan="6">कोई pending Quality Review नहीं है।</td></tr>';document.querySelectorAll('[data-qc-review]').forEach(b=>b.onclick=()=>adminQualityReview(Number(b.dataset.qcReview)));document.querySelector('#tokenWorkCenter')?.setAttribute('onclick',"(()=>{const id=Number(localStorage.getItem('angelCurrentTokenId')||0);if(id)openTokenWorkCenter(id);else toast('पहले current token चुनें')})()");document.querySelector('#tokenWorkDetails')?.setAttribute('onclick',"(()=>{const id=Number(localStorage.getItem('angelCurrentTokenId')||0);if(id)openTokenWorkCenter(id);else toast('पहले current token चुनें')})()");}catch(e){toast(e.message)}}
async function openTokenWorkCenter(id){
  try{
    const [w,q,d]=await Promise.all([
      api('/api/token-workflow?token_id='+encodeURIComponent(id)),
      api('/api/service-quality?token_id='+encodeURIComponent(id)),
      api('/api/workflow/documents?token_id='+encodeURIComponent(id))
    ]);
    const t=w.token||q.token||{}; const wf=w.workflow||{}; const checks=(q.quality?.checks||q.sop?.checks||[]); const docs=d.documents||[];
    const modal=document.createElement('div'); modal.className='token-work-modal'; modal.id='tokenWorkCenterModal';
    const esc=escapeHtml;
    const opt=(v)=>['pending','received','verified','not_required'].map(x=>`<option value="${x}" ${String(v||'pending')===x?'selected':''}>${x==='pending'?'बाकी है':x==='received'?'मिल गया':x==='verified'?'सत्यापित':'लागू नहीं'}</option>`).join('');
    const checkRows=checks.length?checks.map(c=>`<label class="twc-check"><input type="checkbox" data-qc-id="${esc(c.id)}" ${c.checked?'checked':''}> <span>${esc(c.label)} ${c.required?'*':''}</span></label>`).join(''):'<p class="muted">इस service के लिए quality checklist configured नहीं है।</p>';
    const docRows=docs.length?docs.map(x=>`<div class="twc-doc"><div><b>${esc(x.name)}</b><small>${esc(x.mime_type||'')} · ${esc(x.status||'uploaded')}</small></div><div class="twc-doc-actions"><button type="button" class="btn" data-twc-open="${x.id}">Open</button><button type="button" class="btn success" data-twc-verify="${x.id}" ${x.status==='verified'?'disabled':''}>Verify</button><button type="button" class="btn danger" data-twc-reject="${x.id}" ${x.status==='verified'?'disabled':''}>Reject</button></div></div>`).join(''):'<p class="muted">इस token के लिए कोई document नहीं मिला।</p>';
    modal.innerHTML=`<div class="token-work-card token-work-center-card"><div class="token-work-head"><div><span class="eyebrow">ONE SCREEN WORKFLOW</span><h3>🧭 Token ${esc(t.token||'—')} — पूरा Work Center</h3><p>${esc(t.name||'—')} · ${esc(t.service||'—')} · <b>${esc(t.status||'—')}</b> · Staff: ${esc(t.staff_id||'—')}</p></div><button type="button" id="twcClose">×</button></div>
      <div class="twc-summary"><div><small>Token</small><b>${esc(t.token||'—')}</b></div><div><small>Customer</small><b>${esc(t.name||'—')}</b></div><div><small>Staff</small><b>${esc(t.staff_id||'Unassigned')}</b></div><div><small>Quality</small><b id="twcQualityBadge">${esc(t.quality_status||'needs_review')}</b></div></div>
      <div class="twc-section"><h4>1️⃣ काम की स्थिति</h4><div class="token-work-grid"><div class="token-work-item"><label>📷 Customer Photo</label><select id="twcPhoto">${opt(wf.photo)}</select></div><div class="token-work-item"><label>✍ Signature</label><select id="twcSignature">${opt(wf.signature)}</select></div><div class="token-work-item"><label>🪪 Required Documents</label><select id="twcDocuments">${opt(wf.documents)}</select></div><div class="token-work-item"><label>📤 Documents Upload</label><select id="twcUploads">${opt(wf.uploads)}</select></div><div class="token-work-item"><label>🔎 Data Cross-check</label><select id="twcData">${opt(wf.data)}</select></div><div class="token-work-item"><label>🧾 Application Submission</label><select id="twcSubmission">${opt(wf.submission)}</select></div><div class="token-work-item"><label>Reference / Application No.</label><input id="twcRef" maxlength="120" value="${esc(wf.reference_no||'')}" placeholder="ARN / Application / Receipt No."></div><div class="token-work-item"><label>Operator Notes</label><textarea id="twcNotes" maxlength="1000" placeholder="क्या काम हुआ / क्या बाकी है...">${esc(wf.notes||'')}</textarea></div></div><div class="token-work-actions"><button type="button" class="primary" id="twcSaveWork">💾 Work Details Save</button></div></div>
      <div class="twc-section"><h4>2️⃣ Documents Verification</h4><div class="twc-doc-list">${docRows}</div></div>
      <div class="twc-section"><h4>3️⃣ Final Quality Review</h4><p class="muted">पहले Quality Gate पूरा करें। <b>Checks Save</b> केवल save करेगा; <b>Final PASS</b> अलग approval action है।</p><div class="twc-gate" id="twcGateSummary"><div class="twc-gate-row"><span>Checklist</span><b>Loading…</b></div><div class="twc-gate-row"><span>Documents</span><b>Loading…</b></div><div class="twc-gate-row"><span>Payment</span><b>Loading…</b></div></div><div class="twc-check-list" id="twcChecks">${checkRows}</div><div class="twc-actions-row"><button type="button" class="primary" id="twcSaveQuality">☑️ Checks Save</button><button type="button" class="success" id="twcPass">✅ Final PASS</button><button type="button" class="danger" id="twcReject">❌ Reject / Correction</button></div></div>
      <div class="twc-section twc-final"><h4>4️⃣ Token Final Action</h4><p class="muted">Quality PASS होने के बाद यहीं से token Complete करें।</p><div class="twc-actions-row"><button type="button" class="success" id="twcStart">▶️ Start Work</button><button type="button" class="warning" id="twcHold">⏸️ Hold</button><button type="button" class="purple" id="twcComplete">🏁 Complete Token</button></div></div>
    </div>`;
    document.body.appendChild(modal);
    const close=()=>modal.remove(); modal.querySelector('#twcClose').onclick=close;
    const call=async(path,body)=>api(path,{method:'POST',body:JSON.stringify(body)});
    const workBody=()=>({token_id:id,photo:modal.querySelector('#twcPhoto').value,signature:modal.querySelector('#twcSignature').value,documents:modal.querySelector('#twcDocuments').value,uploads:modal.querySelector('#twcUploads').value,data:modal.querySelector('#twcData').value,submission:modal.querySelector('#twcSubmission').value,reference_no:modal.querySelector('#twcRef').value.trim(),notes:modal.querySelector('#twcNotes').value.trim()});
    modal.querySelector('#twcSaveWork').onclick=async()=>{try{await call('/api/token-workflow',workBody());toast('Work details save हो गए');}catch(e){toast(e.message)}};
    const refreshQualityGate=async()=>{const r=await call('/api/service-quality',{token_id:id});const g=r.gate||{};const badge=modal.querySelector('#twcQualityBadge');if(badge)badge.textContent=g.ready?'READY FOR PASS':'GATE PENDING';const gate=modal.querySelector('#twcGateSummary');if(gate){const c=g.checklist||{},d=g.documents||{},p=g.payment||{};gate.innerHTML=`<div class=\"twc-gate-row\"><span>Checklist</span><b>${c.completed||0}/${c.required||0} ${c.ok?'✅':'❌'}</b></div><div class=\"twc-gate-row\"><span>Documents</span><b>${d.verified||0}/${d.required||0} ${d.ok?'✅':'❌'}</b></div><div class=\"twc-gate-row\"><span>Payment</span><b>${p.required?(p.verified?'Verified ✅':'Pending ❌'):'Not Required'}</b></div>`;}return r};
    modal.querySelector('#twcSaveQuality').onclick=async()=>{try{const checks=[...modal.querySelectorAll('[data-qc-id]')].map(el=>({id:el.dataset.qcId,checked:el.checked}));const r=await call('/api/service-quality',{token_id:id,checks,action:'save',notes:'Admin quality checks saved'});modal.querySelector('#twcQualityBadge').textContent=r.quality?.status||'admin_review';toast('Quality checks saved — Final PASS अलग action है');await refreshQualityGate();}catch(e){toast(e.message)}};
    modal.querySelector('#twcPass').onclick=async()=>{try{const checks=[...modal.querySelectorAll('[data-qc-id]')].map(el=>({id:el.dataset.qcId,checked:el.checked}));const r=await call('/api/service-quality',{token_id:id,checks,action:'pass',notes:'Admin final quality review'});if(r.quality?.status!=='passed')throw new Error('Quality PASS नहीं हुआ');modal.querySelector('#twcQualityBadge').textContent='passed';toast('Final Quality Review PASS हो गया');loadControl();}catch(e){toast(e.message)}};
    modal.querySelector('#twcReject').onclick=async()=>{const reason=await angelPrompt('Correction / Reject reason लिखें:','Quality check में correction जरूरी है');if(!reason)return;try{await call('/api/service-quality',{token_id:id,action:'reject',reason,notes:'Admin quality review'});toast('Quality Review rejected / correction required');close();loadControl();}catch(e){toast(e.message)}};
    modal.querySelector('#twcStart').onclick=async()=>{try{let current=await api('/api/tokens');let tok=(current.tokens||[]).find(x=>Number(x.id)===Number(id));if(!tok)throw new Error('Token नहीं मिला');if(tok.status==='लंबित'){await call('/api/tokens',{id,action:'next',service:tok.service});}await call('/api/tokens',{id,action:'processing'});toast('Work शुरू हो गया');close();loadTokens();}catch(e){toast(e.message)}};
    modal.querySelector('#twcHold').onclick=async()=>{const reason=await angelPrompt('Hold reason:','Customer/document pending');if(!reason)return;const mins=Number(await angelPrompt('Expected delay (minutes):','15')||0);if(!mins)return;try{await call('/api/tokens',{id,action:'hold',reason,owner:'customer',delay_minutes:mins});toast('Token Hold कर दिया गया');close();loadTokens();}catch(e){toast(e.message)}};
    modal.querySelector('#twcComplete').onclick=async()=>{try{await call('/api/tokens',{id,action:'complete'});toast('Token Complete हो गया');close();loadTokens();loadControl();}catch(e){toast(e.message)}};
    refreshQualityGate().catch(e=>toast(e.message));
    modal.querySelectorAll('[data-twc-open]').forEach(b=>b.onclick=async()=>{try{const r=await fetch('/api/documents/'+encodeURIComponent(b.dataset.twcOpen)+'/file',{credentials:'include'});if(!r.ok)throw new Error('Document open failed');const blob=await r.blob();const u=URL.createObjectURL(blob);window.open(u,'_blank','noopener');setTimeout(()=>URL.revokeObjectURL(u),30000)}catch(e){toast(e.message)}});
    modal.querySelectorAll('[data-twc-verify]').forEach(b=>b.onclick=async()=>{try{await call('/api/documents/'+encodeURIComponent(b.dataset.twcVerify)+'/status',{status:'verified',note:'Verified by Admin'});toast('Document verified');close();openTokenWorkCenter(id);}catch(e){toast(e.message)}});
    modal.querySelectorAll('[data-twc-reject]').forEach(b=>b.onclick=async()=>{const note=await angelPrompt('Document reject reason:','Document readable/valid नहीं है');if(!note)return;try{await call('/api/documents/'+encodeURIComponent(b.dataset.twcReject)+'/status',{status:'rejected',note});toast('Document rejected');close();openTokenWorkCenter(id);}catch(e){toast(e.message)}});
  }catch(e){toast(e.message)}
}
async function adminQualityReview(id){openTokenWorkCenter(id)}
async function loadAdvancedReports(){try{const from=$('#fromDate')?.value||'',to=$('#toDate')?.value||'',q=(from?'?from='+encodeURIComponent(from):'')+(to?(from?'&':'?')+'to='+encodeURIComponent(to):'');const [d,sa,sp]=await Promise.all([api('/api/reports'+q),api('/api/reports/service'+q),api('/api/reports/staff'+q)]);const rows=sa.services||[];let old=$('#serviceAnalyticsTable');if(!old){const panel=document.createElement('div');panel.className='panel';panel.innerHTML='<h3>Service-wise Profitability</h3><div class="table-wrap"><table><thead><tr><th>Service</th><th>Tokens</th><th>Completed</th><th>Completion</th><th>Collection</th><th>Official</th><th>Staff</th><th>Contribution</th></tr></thead><tbody id="serviceAnalyticsTable"></tbody></table></div>';$('#page-reports').appendChild(panel);old=$('#serviceAnalyticsTable')}old.innerHTML=rows.map(x=>`<tr><td>${escapeHtml(x.service)}</td><td>${x.tokens}</td><td>${x.completed}</td><td>${x.completion_rate}%</td><td>₹${Number(x.verified_collection).toFixed(2)}</td><td>₹${Number(x.official_fee).toFixed(2)}</td><td>₹${Number(x.staff_commission).toFixed(2)}</td><td><b>₹${Number(x.contribution).toFixed(2)}</b></td></tr>`).join('')||'<tr><td colspan="8">No service data</td></tr>';let st=$('#staffAnalyticsTable');if(!st){const panel=document.createElement('div');panel.className='panel';panel.innerHTML='<h3>Staff Performance</h3><div class="table-wrap"><table><thead><tr><th>Employee</th><th>Assigned</th><th>Completed</th><th>Completion</th><th>QC Pass</th><th>QC Pending</th><th>Home</th><th>Delivery</th><th>Commission</th></tr></thead><tbody id="staffAnalyticsTable"></tbody></table></div>';$('#page-reports').appendChild(panel);st=$('#staffAnalyticsTable')}st.innerHTML=(sp.staff||[]).map(x=>`<tr><td>${escapeHtml(x.employee_id)}<br>${escapeHtml(x.name)}</td><td>${x.assigned}</td><td>${x.completed}</td><td>${x.completion_rate}%</td><td>${x.quality_passed}</td><td>${x.qc_needs_review}</td><td>${x.home_visits}</td><td>${x.deliveries}</td><td>₹${Number(x.commission).toFixed(2)}</td></tr>`).join('')||'<tr><td colspan="9">No staff data</td></tr>'}catch(e){toast(e.message)}}


function monitoringRequest(path,timeoutMs=10000){
  return Promise.race([
    api(path),
    new Promise((_,reject)=>setTimeout(()=>{const e=new Error('Monitoring request timeout. Please try Check Now again.');e.code='MONITOR_TIMEOUT';reject(e)},timeoutMs))
  ])
}
function setMonitoringPanelState(selector,message,kind='warning'){
  const el=$(selector); if(!el)return;
  const cls=kind==='error'?'tag red':kind==='ok'?'tag green':'tag';
  el.setAttribute('aria-busy','false');
  el.innerHTML=`<div class="notification" role="alert" tabindex="-1"><div><b>${escapeHtml(message)}</b><small>Other monitoring sections remain available.</small></div><span class="${cls}">${kind==='error'?'ERROR':'CHECK'}</span></div>`;
}
async function loadMonitoring(){
  const btn=$('#refreshMonitoring');
  const wasFocused=document.activeElement===btn;
  if(btn){btn.disabled=true;btn.dataset.busy='1';btn.setAttribute('aria-busy','true');btn.textContent='⏳ Checking…'}
  const live=$('#monitorLiveStatus'); if(live){live.className='monitor-live-status';live.textContent='Monitoring check चल रहा है…';}
  try{
    const results=await Promise.allSettled([
      monitoringRequest('/api/admin/monitoring'),
      monitoringRequest('/api/admin/incidents'),
      monitoringRequest('/api/admin/recharge-retry-observability')
    ]);
    const [mr,ir,rr]=results;
    const m=mr.status==='fulfilled'?mr.value:null;
    const i=ir.status==='fulfilled'?ir.value:null;
    const rro=rr.status==='fulfilled'?rr.value:null;
    const failures=[];
    ['#monitorChecks','#retryObsDetails'].forEach(sel=>$(sel)?.setAttribute('aria-busy','true'));
    if(!m)failures.push(`System monitoring: ${mr.reason?.message||'Unavailable'}`);
    if(!i)failures.push(`Incident history: ${ir.reason?.message||'Unavailable'}`);
    if(!rro)failures.push(`Recharge observability: ${rr.reason?.message||'Unavailable'}`);

    if(m){
      const open=m.incidents||[];
      if($('#monitorStatus')){$('#monitorStatus').textContent=m.ok?'HEALTHY':(open.some(x=>x.severity==='critical')?'CRITICAL':'WARNING');$('#monitorStatus').className=m.ok?'tag green':'tag red'}
      if($('#monitorOpen'))$('#monitorOpen').textContent=open.length;
      if($('#monitorBackup'))$('#monitorBackup').textContent=m.monitor?.backup?.overdue?'OVERDUE':'OK';
      if($('#monitorAlert'))$('#monitorAlert').textContent=m.alert_webhook_configured?'Configured':'Not configured';
      const checks=[['Database integrity',m.monitor?.integrity?.ok,m.monitor?.integrity?.ok?'OK':'Failed'],['Storage',m.monitor?.storage?.data_file?.ok,m.monitor?.storage?.data_file?.ok?'Available':'Unavailable'],['Persistence',m.monitor?.storage?.persistence_configured,m.monitor?.storage?.persistence_configured?'Configured':'Missing'],['Backup',!m.monitor?.backup?.overdue,m.monitor?.backup?.overdue?'Overdue':'OK'],['Payment reconciliation',m.monitor?.reconciliation?.ok,m.monitor?.reconciliation?.ok?'0 issues':`${m.monitor?.reconciliation?.issue_count||0} issue(s)`],['Financial ledger',m.monitor?.financial_ledger?.ok,m.monitor?.financial_ledger?.ok?'0 issues':`${m.monitor?.financial_ledger?.issue_count||0} issue(s)`],['Token lifecycle',m.monitor?.token_lifecycle?.ok,m.monitor?.token_lifecycle?.ok?'0 issues':`${m.monitor?.token_lifecycle?.issue_count||0} issue(s)`]];
      $('#monitorChecks').innerHTML=checks.map(x=>`<div class="notification"><div><b>${x[0]}</b><small>${x[2]}</small></div><span class="tag ${x[1]?'green':'red'}">${x[1]?'PASS':'CHECK'}</span></div>`).join('');
      $('#monitorChecks')?.setAttribute('aria-busy','false');
    }else setMonitoringPanelState('#monitorChecks','System monitoring unavailable','error');

    if(rro){
      const ro=rro.observability||{};const rs=ro.status_counts||{};
      if($('#retryObsTotal'))$('#retryObsTotal').textContent=Number(ro.retries_total||0);
      if($('#retryObsGroups'))$('#retryObsGroups').textContent=Number(ro.retry_groups||0);
      if($('#retryObsPending'))$('#retryObsPending').textContent=Number(rs.Pending||0);
      if($('#retryObsSuccess'))$('#retryObsSuccess').textContent=Number(rs.Success||0);
      if($('#retryObsFailed'))$('#retryObsFailed').textContent=Number(rs.Failed||0);
      if($('#retryObsRejects'))$('#retryObsRejects').textContent=Number(ro.payment_rejected_24h||0);
      if($('#retryObsChecked'))$('#retryObsChecked').textContent=escapeHtml(rro.checked_at||ro.checked_at||'—');
      if($('#retryObsDetails')){ $('#retryObsDetails').setAttribute('aria-busy','false'); $('#retryObsDetails').innerHTML='<div class="notification"><div><b>Last 24h submissions</b><small>'+Number(ro.attempts_submitted_24h||0)+'</small></div><span class="tag">Observed</span></div><div class="notification"><div><b>Completed retries</b><small>'+Number(ro.retries_completed_24h||0)+'</small></div><span class="tag green">Success</span></div><div class="notification"><div><b>Receipt generated (24h)</b><small>'+Number(ro.retry_receipts_24h||0)+'</small></div><span class="tag green">Receipts</span></div><div class="notification"><div><b>Idempotency records</b><small>'+Number(ro.idempotency_records||0)+'</small></div><span class="tag">Tracked</span></div><div class="notification"><div><b>Open recovery incidents</b><small>'+Number(ro.open_recovery_incidents||0)+'</small></div><span class="tag '+(Number(ro.open_recovery_incidents||0)?'red':'green')+'">'+(Number(ro.open_recovery_incidents||0)?'CHECK':'OK')+'</span></div><div class="notification"><div><b>Alert webhook failures</b><small>'+Number(ro.incident_webhook_failures||0)+'</small></div><span class="tag '+(Number(ro.incident_webhook_failures||0)?'red':'green')+'">'+(Number(ro.incident_webhook_failures||0)?'CHECK':'OK')+'</span></div>'; }
    }else setMonitoringPanelState('#retryObsDetails','Recharge observability unavailable','error');

    if(i){
      const rows=i.incidents||[];
      $('#incidentRows').innerHTML=rows.map(x=>`<tr><td>${escapeHtml(x.type)}</td><td>${escapeHtml(x.severity)}</td><td>${escapeHtml(x.status)}</td><td>${escapeHtml(x.message||'')}</td><td><time datetime="${escapeHtml(x.opened_at||'')}">${escapeHtml(x.opened_at||'')}</time></td><td>${x.status==='open'?`<button type="button" class="primary resolve-incident" aria-label="Resolve incident ${escapeHtml(x.type||'')}" data-id="${x.id}">Resolve</button>`:'<span class="muted">No action</span>'}</td></tr>`).join('')||'<tr><td colspan="6">No incidents</td></tr>';
      document.querySelectorAll('.resolve-incident').forEach(b=>b.onclick=async()=>{try{await api('/api/admin/incidents/resolve',{method:'POST',body:JSON.stringify({id:Number(b.dataset.id)})});toast('Incident resolved');loadMonitoring().then(()=>$('#refreshMonitoring')?.focus())}catch(e){toast(e.message)}})
    }else $('#incidentRows').innerHTML='<tr><td colspan="6"><b>Incident history unavailable</b><br><small>Try Check Now again. Other monitoring sections remain available.</small></td></tr>';

    const live=$('#monitorLiveStatus');
    if(live){ live.className='monitor-live-status'+(failures.length?' warning':''); live.textContent=failures.length?`Monitoring partially loaded: ${failures.length} section(s) unavailable.`:'Monitoring check complete.'; }
    if(failures.length)toast(`Monitoring partially loaded: ${failures.length} section(s) unavailable`,'warning');
  }catch(e){toast(e.message)}finally{
    if(btn){btn.disabled=false;delete btn.dataset.busy;btn.setAttribute('aria-busy','false');btn.textContent='↻ Check Now'}
    ['#monitorChecks','#retryObsDetails'].forEach(sel=>$(sel)?.setAttribute('aria-busy','false'));
    if(wasFocused && btn && !btn.disabled) btn.focus();
  }
}
async function loadTokenHistoryViewer(tokenId){try{const id=Number(tokenId||0);if(!id){$('#tokenHistoryRows').innerHTML='<tr><td colspan="6">Token ID डालें।</td></tr>';return}const d=await api('/api/admin/token-history?token_id='+encodeURIComponent(id)+'&limit=100');const events=d.events||[],notes=d.notifications||[];const merged=[...events.map(x=>({at:x.at,kind:'AUDIT',action:x.action,actor:x.by||'—',state:x.status||'—',rev:x.state_revision??'—',detail:x.reason||x.request_id||'—'})),...notes.map(x=>({at:x.created_at,kind:'CUSTOMER',action:x.title,actor:'Customer',state:x.read?'Read':'Unread',rev:x.state_revision??'—',detail:x.message}))].sort((a,b)=>String(b.at||'').localeCompare(String(a.at||'')));$('#tokenHistoryRows').innerHTML=merged.map(x=>`<tr><td>${escapeHtml(x.at||'')}</td><td>${escapeHtml(x.kind)}</td><td>${escapeHtml(x.action)}</td><td>${escapeHtml(x.actor)}</td><td>${escapeHtml(String(x.state))} / r${escapeHtml(String(x.rev))}</td><td>${escapeHtml(x.detail)}</td></tr>`).join('')||'<tr><td colspan="6">No token history</td></tr>'}catch(e){if($('#tokenHistoryRows'))$('#tokenHistoryRows').innerHTML='<tr><td colspan="6">'+escapeHtml(e.message)+'</td></tr>'}}
async function loadSecurityAudit(){try{await ensureTokenHistoryViewer();const d=await api('/api/admin/security-audit?limit=100');const c=d.counts||{};const ids={secLogin:'login_history',secFailed:'failed_login',secDocs:'document_access',secDownloads:'download_log',secDeletes:'delete_log',secPayments:'payment_verification',secTokens:'token_changes',secAdmin:'admin_activity',secStaff:'staff_activity',secPermissions:'permission_changes'};Object.entries(ids).forEach(([id,key])=>{if($('#'+id))$('#'+id).textContent=Number(c[key]||0)});const all=Object.values(d.logs||{}).flat().sort((a,b)=>String(b.at||'').localeCompare(String(a.at||''))).slice(0,100);const rows=$('#securityAuditRows');if(rows)rows.innerHTML=all.map(x=>{const rec=x.token_id?('Token '+x.token_id):x.application_id?('Application '+x.application_id):x.document_id?('Document '+x.document_id):x.payment_id?('Payment '+x.payment_id):x.staff_id?('Staff '+x.staff_id):'';return `<tr><td>${escapeHtml(x.at||'')}</td><td>${escapeHtml(x.action||'')}</td><td>${escapeHtml(x.by||x.employee_id||x.user||'')}</td><td>${escapeHtml(rec)}</td><td>${escapeHtml(x.reason||x.new_role||'')}</td></tr>`}).join('')||'<tr><td colspan="5">No audit records</td></tr>'}catch(e){toast(e.message)}}
async function ensureTokenHistoryViewer(){if($('#tokenHistoryViewer'))return;const panel=document.createElement('div');panel.id='tokenHistoryViewer';panel.className='panel';panel.innerHTML='<div class="panel-head"><h3>🎫 Token Timeline & Customer Notifications</h3><span class="tag">Audit ↔ Customer</span></div><div class="settings"><label>Token ID<input id="tokenHistoryId" type="number" min=1 placeholder="Token ID"></label><button type="button" class="primary" id="loadTokenHistory">View Timeline</button></div><div class="table-wrap"><table><thead><tr><th>Time</th><th>Source</th><th>Event</th><th>Actor</th><th>State / Revision</th><th>Details</th></tr></thead><tbody id="tokenHistoryRows"><tr><td colspan="6">Token ID डालें।</td></tr></tbody></table></div>';document.querySelector('#page-security')?.appendChild(panel);$('#loadTokenHistory').onclick=()=>loadTokenHistoryViewer($('#tokenHistoryId').value)}
async function loadPreflight(){try{const d=await api('/api/admin/preflight');const checks=d.checks||[];if($('#preflightPassed'))$('#preflightPassed').textContent=d.summary?.passed??0;if($('#preflightTotal'))$('#preflightTotal').textContent=d.summary?.total??checks.length;if($('#preflightStatus')){const ok=d.ok===true;$('#preflightStatus').textContent=ok?'READY':'ACTION NEEDED';$('#preflightStatus').className=ok?'tag green':'tag red'}const box=$('#preflightList');if(box)box.innerHTML=checks.map(x=>`<div class="notification"><div><b>${x.ok?'✓':'✗'} ${escapeHtml(x.label)}</b><small>${escapeHtml(x.detail||'')}</small></div><span class="tag ${x.ok?'green':'red'}">${x.ok?'PASS':'CHECK'}</span></div>`).join('')}catch(e){toast(e.message)}}

async function loadPageData(page){try{if(page==='tokens'||page==='tokenmgmt'||page==='status')await loadTokens();if(page==='home'||page==='admin')await loadDashboard();if(page==='customers')await loadCustomers();if(page==='payments')await loadPayments();if(page==='livecontent')await loadLiveOffersAdmin();if(page==='charges')await loadServiceCharges();if(page==='sop')await loadSopPage();if(page==='settings'){await loadSettings();await loadBackups();await loadHomepageHeroAdminPreview();}if(page==='preflight')await loadPreflight();if(page==='monitoring')await loadMonitoring();if(page==='control')await loadControl();if(page==='business')await window.angelLoadBusinessManagement?.();if(page==='security')await window.angelLoadSecurityAudit?.();if(page==='workflow')await window.angelLoadWorkflowConfig?.();if(page==='custom-services')await window.angelLoadCustomServices?.();if(page==='uppcl-control')await window.angelLoadUppclControl?.();if(page==='reports'){await loadReports();await loadAdvancedReports();}}catch(e){toast(e.message)}}
function clock(){const d=new Date();if($('#liveDate'))$('#liveDate').textContent=d.toLocaleDateString('hi-IN',{day:'2-digit',month:'long',year:'numeric'});if($('#clock'))$('#clock').textContent=d.toLocaleString('hi-IN',{dateStyle:'medium',timeStyle:'short'});if($('#liveClock'))$('#liveClock').textContent=d.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'});setTimeout(clock,1000)}
$('#fullscreenBtn')?.addEventListener('click',()=>$('.live-board')?.requestFullscreen?.());
// Customer business history is rendered by customer.html from backend APIs. Admin app does not keep a second local business-state store.
async function boot(){
  const isAdmin=document.body?.dataset.panel==='admin';
  try{
    // Admin navigation must be bound before any network-dependent initialization.
    // This keeps every data-page/data-open button usable even when the backend is temporarily unavailable.
    if(isAdmin){
      role='admin';
      $('#app')?.classList.add('hidden');
      $('#adminAuth')?.classList.remove('hidden');
      applyRoleAccess();
      bindAdminNavigation();
    }
    await loadServiceCatalog();
    renderServices();
    renderPublicServices();
    bindPublicServiceCards();
    clock();
    syncCustomerServiceControls();
    if(isAdmin){
      await verifyAdminSession();
    }else{
      role='customer';
      currentUser=null;
      updateCustomerButton();
      applyRoleAccess();
      const saved=localStorage.getItem('angelCustomerLocal');
      if(saved){try{currentCustomer=JSON.parse(saved);fillCustomer(currentCustomer);updateCustomerButton();syncCustomerServiceControls()}catch{}}
    }
  }catch(e){
    console.error('boot error',e);
    if(isAdmin){
      // Keep the Admin UI interactive even if a non-critical boot step fails.
      applyRoleAccess();
      bindAdminNavigation();
      $('#adminAuth')?.classList.remove('hidden');
    }
    renderPublicServices();
    bindPublicServiceCards();
  }
}
boot();
setTimeout(()=>{populateTokenServices($('#reqService')?.value||'')},0);

