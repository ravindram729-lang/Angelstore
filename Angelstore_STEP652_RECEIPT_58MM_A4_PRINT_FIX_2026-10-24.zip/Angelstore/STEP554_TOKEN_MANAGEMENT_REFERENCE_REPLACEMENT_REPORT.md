# STEP554 — Token Management Reference Replacement

## Scope
Replaced the Admin Token Management page presentation to match the supplied bilingual Angelstore CSC reference dashboard while preserving the existing token/queue APIs and action IDs.

## UI changes
- Reference-aligned Token Management header and Queue Management badge.
- Four KPI cards: Active Tokens, Waiting, Avg Wait Time, Completed Today.
- Two-column Current Token / Completed Token History layout.
- Reference-style empty current-token state and history empty state.
- Color-coded action buttons for Call Next, Recall, Start Work, Hold, Delay, No Show, Cancel, Complete and Work Center.
- Work Details action retained and wired to the existing Work Center.
- Secondary Assign Staff / Priority / Transfer / Notify actions retained.
- Existing service-wise queue and Current Work Center retained below the reference area so functionality is not removed.
- Responsive layouts added for tablet and mobile.

## Functional preservation
- Existing IDs used by tokenAction/loadTokens/renderQueue remain intact.
- No new API endpoints or token state transitions were introduced.
- Existing Start Work button continues to change to Resume when the server reports a held token.
- Work Details uses the same existing `openTokenWorkCenter()` flow.

## Verification
- `node --check src/app.js` — PASS
- `node --check src/customer.js` — PASS
- ZIP integrity — PASS
- Existing token action handlers preserved — PASS
- No new duplicate static HTML IDs introduced — PASS
