# Phase 16 — Admin Authentication + Password Management

## Changes
- Added migration-safe `admin_credentials` collection.
- Legacy local admin password is migrated to a scrypt hash after the first successful login.
- Added `POST /api/auth/password` for authenticated admin password changes.
- New passwords require at least 12 characters; confirmation is required.
- Password changes revoke all admin sessions and require re-login.
- Added local recovery utility `RESET-ADMIN-PASSWORD.bat` for the machine owner. It requires the exact confirmation phrase and writes only a password hash.
- Admin API 401 responses now clear stale browser admin sessions and return a clear re-login message instead of repeated generic Unauthorized errors.

## Verification
- Existing business data is preserved; only `admin_credentials` and audit/session records are changed by password operations.
- Syntax checks and login/change-password/logout flows should be run before production deployment.
