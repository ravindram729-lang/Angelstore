# ANGELSTORE CSC — STEP 334 TOKEN RECALL FIX

## Root Cause
The admin token UI called the existing `/api/tokens` transition API, but the local backend transition table treated `स्किप` as a terminal state. Therefore `दोबारा बुलाएँ (Recall)` returned `इस token state से recall allowed नहीं है` after a token was skipped.

## Changes
1. `server.js`
   - Changed the local token transition map so `स्किप -> बुलाया` is allowed.
   - Existing safeguards remain in place: another active token still blocks recall, and completed/cancelled tokens remain terminal.

2. `app.js`
   - Hardened `tokenAction()` so it resolves the current token from the queue/current-token state instead of relying only on a possibly stale localStorage id.
   - `next` remains id-less; state-changing actions use the resolved token id.

## Verification
- `node --check server.js` PASS
- `node --check app.js` PASS
- Local backend API regression test PASS:
  - skipped -> recall -> called
  - called -> hold -> hold
  - hold -> recall -> called
  - called -> skip -> skipped
  - skipped -> recall -> called

No database schema change was made.
