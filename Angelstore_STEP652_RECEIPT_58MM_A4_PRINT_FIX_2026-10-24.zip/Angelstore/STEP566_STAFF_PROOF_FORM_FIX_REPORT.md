# STEP566 — Staff Completion Proof + Form Semantics Fix

## Scope
Staff Panel follow-up fixes after STEP565 P1 authorization hardening.

## Changes
- Home Service `Complete` now requires a 5–500 character completion note and accepts an optional proof reference up to 200 characters.
- Delivery `Delivered` now requires a 5–500 character delivery note and accepts an optional proof reference up to 200 characters.
- Completion actor IDs are persisted for Home Service and Delivery.
- Public staff-facing records expose completion/delivery proof metadata without exposing secrets.
- Staff Login converted to a semantic `<form>` with submit handling.
- Manual Recharge converted to a semantic `<form>` with submit handling.
- Existing action authorization and Token Queue workflow were preserved.

## Verification
- `STEP565_STAFF_P1_FIX_REGRESSION.js`: PASS
- `STEP566_STAFF_PROOF_FORM_REGRESSION.js`: PASS
- `P0-P1-REGRESSION-TEST.js`: PASS
- `STEP501_UI_BUTTON_WORKFLOW_AUDIT_TEST.js`: 16/16 PASS
- `STEP503_RECEIPT_RECORDS_UI_AUDIT_TEST.js`: 10/10 PASS
- `STEP521_RECEIPT_PDF_PRINT_TEST.js`: 10/10 PASS
- `FINAL-RELEASE-AUDIT.js`: PASS
- JS syntax: PASS for server.js, app.js, customer.js

## Not changed in this step
- HttpOnly cookie migration
- Actual photo/signature upload evidence
- OTP delivery verification
- Staff modal focus-trap/accessibility migration
- Live production deployment verification
