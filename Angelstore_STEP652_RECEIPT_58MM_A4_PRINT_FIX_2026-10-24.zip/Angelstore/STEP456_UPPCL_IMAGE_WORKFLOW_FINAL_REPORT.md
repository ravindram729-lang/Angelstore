# STEP456 — UPPCL Image-First Workflow Final Fix & Verification Report

Date: 2026-10-02

## Objective

Implement the UPPCL customer workflow in the same order shown in the supplied UI reference image, before adding unrelated enhancements:

1. उपभोक्ता विवरण भरें
2. बिल विवरण
3. UPI से भुगतान करें
4. भुगतान की जानकारी दर्ज करें

Then the separate operational status flow continues:

**Payment Submitted → Admin Verification → Bill Processing → Receipt**

No cart/order workflow was added.

## Changes made

### P0 — Core customer workflow

- Customer page now has an explicit workflow bar matching the image order:
  - `1 उपभोक्ता विवरण`
  - `2 बिल विवरण`
  - `3 UPI भुगतान`
  - `4 भुगतान जानकारी`
- Bill Details, UPI Payment and Payment Proof sections remain hidden until the preceding bill lookup succeeds.
- Bill lookup is still manual-only; there is no external UPPCL bill API dependency.
- Admin-entered bill remains the authoritative source.
- District and DISCOM selected by the customer are checked against the Admin-approved bill.
- Account-number lookup works.
- Registered-mobile lookup now works when Admin has stored a registered mobile against the manual bill.
- Payment amount displayed to the customer is read-only and derived from the Admin bill.

### P1 — Payment

- UPI ID loads from public configuration.
- QR payment remains available.
- UPI deep link includes the exact bill amount.
- Copy UPI button works.
- UTR + screenshot are required before submission.
- Screenshot preview/validation remains enabled.
- Duplicate UTR is rejected server-side.
- Duplicate active payment for the same bill is rejected server-side.
- Server rejects any submitted amount that differs from Admin `total_amount`.

### P1 — Admin workflow

- Admin manual bill supports registered mobile as an additional lookup field.
- Existing Admin verification gate remains intact.
- UPPCL manual processing remains blocked until customer payment is verified.
- Completion creates the UPPCL receipt number automatically.

### P1 — Status

Customer status remains separate from the four customer-entry steps:

`Payment Submitted → Admin Verification → Bill Processing → Receipt`

The status is driven from the actual payment record, not a decorative/static state.

## Button / form wiring

- Bill lookup is a real `<form>` submit.
- Payment proof is a real `<form>` submit.
- Bill lookup button is disabled until the selected lookup input is valid.
- Registered Mobile mode validates 10 digits.
- Account mode validates 6–30 digits.
- Payment submit remains disabled until valid UTR + valid screenshot + fetched bill exist.
- Copy UPI, UPI App, History Refresh, Payment Status and Help actions remain wired.
- Receipt actions are generated only after completion/receipt availability.

## Responsive structure

CSS rules were checked for:

- 1150px: main/right layout collapse
- 800px: single-column main flow and responsive payment/flow sections
- 520px: single-column form, bill and amount cards; 2-column quick actions; compact status flow

The intended mobile order is:

`Header → Hero → Step 1 → Step 2 → Step 3 → Step 4 → Status → History`

A full live Chromium visual test could not be executed in this execution environment because the installed Chromium policy returns `ERR_BLOCKED_BY_ADMINISTRATOR` for local HTTP navigation. Therefore no claim of a fresh browser screenshot PASS is made here. Static responsive rules and workflow DOM checks were run instead.

## Verification performed

### Source / syntax

- `node --check server.js` — PASS
- `node --check customer.js` — PASS
- `node --check app.js` — PASS
- UPPCL static workflow audit — PASS

### Existing regression suite

- `npm run check` — PASS
- `npm run p0-p1-regression` — PASS
- `npm run release-audit` — PASS

### UPPCL API workflow test

Tested against an isolated local test storage containing an Admin-approved UPPCL bill:

- Account lookup — PASS
- Registered mobile lookup — PASS
- Correct district/DISCOM match — PASS
- Wrong district — rejected
- Wrong DISCOM — rejected
- Tampered amount — rejected
- Correct amount — accepted
- Duplicate bill payment — rejected
- Payment proof access for Admin — PASS
- Admin verification — PASS after proof review
- UPPCL manual completion — PASS
- Automatic receipt number — PASS
- Customer dashboard reflected completion — PASS

Example test bill:

- Current Bill: ₹1,100
- Arrear: ₹100
- Late Fee: ₹45
- Total Payable: ₹1,245

The test confirmed that submitting ₹1,200 was rejected and ₹1,245 was accepted.

## Final workflow

```text
CUSTOMER
  ↓
1. उपभोक्ता विवरण
   District + DISCOM
   Account / Registered Mobile
  ↓
2. बिल विवरण
   Consumer + Account + Bill No.
   Bill Month + Due Date
   Current + Arrear + Late Fee
   Total Payable
  ↓
3. UPI भुगतान
   QR + UPI ID + Exact Amount
  ↓
4. भुगतान जानकारी
   UTR + Screenshot
  ↓
PAYMENT SUBMITTED
  ↓
ADMIN VERIFICATION
  ↓
UPPCL MANUAL BILL PROCESSING
  ↓
BILL COMPLETED
  ↓
AUTOMATIC RECEIPT
```

## Final status

**STEP456 UPPCL IMAGE-FIRST WORKFLOW: PASS**

The customer-facing workflow now follows the supplied reference-image order first. Additional status/administrative processing happens only after the four customer workflow stages.
