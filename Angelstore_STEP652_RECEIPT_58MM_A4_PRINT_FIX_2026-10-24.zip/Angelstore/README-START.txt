ANGELSTORE CSC — FINAL LOCAL BUILD

IMPORTANT: Do NOT double-click admin.html/customer.html as the normal way to run the portal.
Use START-ANGELSTORE.bat, START-ADMIN.bat, or START-CUSTOMER.bat.

START ALL
1. Install Node.js LTS.
2. Double-click START-ANGELSTORE.bat.
3. Wait for the backend health check to pass.
4. The browser opens http://127.0.0.1:8000/admin.html and customer.html.
5. Keep the Backend CMD window open while using the portal.

DIRECT HTML SAFETY
If admin.html/customer.html is accidentally opened via file://, the page now prefers the local
backend at http://127.0.0.1:8000 and will automatically redirect there if the backend is running.
A stale saved Render URL will NOT override the local backend on file:// pages.

FIRST STAFF SETUP
1. Admin panel me Staff section kholen.
2. Pehle staff account create karein (Employee ID/PIN).
3. Staff panel hamesha http://127.0.0.1:8000/staff.html se kholen; staff.html ko direct file:// se double-click na karein.
4. Allowed staff roles: staff, senior_staff, supervisor, manager.

LOCAL DEVELOPMENT LOGIN (NOT FOR PRODUCTION)
Default credentials are only active when NODE_ENV is NOT production.
They are intentionally weak local defaults for first-run testing.
Change them immediately via RESET-ADMIN-PASSWORD.bat / env vars before any network exposure.
  Username: (local default — set ANGELSTORE_ADMIN_USER or use RESET utility)
  Password: (local default — change with RESET-ADMIN-PASSWORD utility)

PAYMENT
Customer selects Category -> Sub-service -> payable amount.
Payment supports UPI App + supplied QR. UTR + screenshot are mandatory.
Admin must securely view the screenshot and verify the actual transaction before token generation.

SERVICE CHARGES
25 categories / 116 sub-services. Admin overrides Govt/Portal, CSC and Other charges.
Server validates the payable amount.

PRODUCTION
Set NODE_ENV=production, ANGELSTORE_ADMIN_USER, ANGELSTORE_ADMIN_PASS (>=12 chars, not a known default),
ANGELSTORE_AUTH_SECRET (>=32 chars), ANGELSTORE_CORS_ORIGIN (one explicit HTTPS origin),
and ANGELSTORE_STORAGE_DIR (absolute persistent path).
Render configuration includes a persistent disk, scheduled backups, and explicit fields for off-site backup/alert settings. Fill the required off-site destination and alert settings before production release.
Use HTTPS and persistent storage. Recharge plans are Admin-managed; recharge completion is manually
processed by Admin/staff after payment verification. UPPCL remains manual/Admin-managed.
The process will refuse to start in production if required secrets/config are missing or weak.
For isolated test runs use: npm run e2e (the runner creates and deletes its own temporary data).
