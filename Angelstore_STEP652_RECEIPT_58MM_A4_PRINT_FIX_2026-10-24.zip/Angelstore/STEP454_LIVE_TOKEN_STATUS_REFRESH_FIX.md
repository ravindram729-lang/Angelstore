# STEP454 — LIVE TOKEN STATUS REFRESH FIX

## Root Cause

`customer.js` called `refreshAll()` from login, registration, navigation, token generation, refresh controls, and a 3-second polling timer, but the `refreshAll()` implementation was missing.

This caused a browser runtime `ReferenceError: refreshAll is not defined`, so the Live Token Status, customer dashboard records, queue metrics, and related status UI could not be reliably refreshed.

## Fix Applied

Added a guarded asynchronous `refreshAll()` implementation in `customer.js` that:

- Prevents overlapping refresh requests with `refreshAllInFlight`.
- Uses `/api/customer/dashboard` for authenticated customer data, tokens, payments, records, current token, and summary data.
- Uses `/api/customer/progress` for application/payment/document/workflow progress.
- Updates Customer Account fields from the authenticated dashboard response.
- Renders token history/records through the existing `renderCustomerRecords()` renderer.
- Maps backend queue metadata (`ahead_count`, `estimated_wait_minutes`, `service_average_minutes`) into the existing Live Token Status renderer.
- Updates `renderMine()` and `renderTokenStatusDashboard()` from the same live data source.
- Refreshes UPPCL payment history when the UPPCL page is active.
- Preserves the guest restriction: guest users do not receive the authenticated live queue endpoint.
- Keeps the existing 3-second polling and manual refresh controls functional.

## Verification

### Static
- `node --check customer.js` — PASS
- `node --check server.js` — PASS
- Exactly one `refreshAll()` function definition — PASS
- Existing `refreshAll()` call sites remain wired — PASS

### Backend/API smoke test
Using an isolated local test instance:
- `/api/health` — HTTP 200
- Customer registration — HTTP 201
- `/api/customer/dashboard` — HTTP 200
- `/api/customer/progress` — HTTP 200
- `/api/customer/tokens` — HTTP 200

### Refresh orchestration mock test
- Authenticated dashboard + progress calls executed.
- Queue `ahead_count` and `estimated_wait_minutes` correctly mapped.
- Existing status renderers received the expected live token data.
- Result: PASS

## Scope

Only the missing customer refresh orchestration was fixed. No payment verification rules, token-generation rules, backend queue calculation, or cart/order architecture was changed.
