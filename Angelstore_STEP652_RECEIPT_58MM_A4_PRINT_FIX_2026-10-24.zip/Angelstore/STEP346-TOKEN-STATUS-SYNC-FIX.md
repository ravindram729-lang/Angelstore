# STEP346 — Customer Token Status Synchronization Fix

## Scope
Customer Live Token Status was showing conflicting values when the customer's own token was already `In Progress`.

## Fixes
- `In Progress` now shows `काम चल रहा है` instead of `अब आपकी बारी`.
- `Called` shows `अब आपकी बारी` and directs the customer to the counter.
- `On Hold` shows `काम रुका है` and tells the customer to check progress/timer.
- Completed / Skipped / Cancelled states now use state-specific customer messaging.
- Queue position is forced to `0` for Called/In Progress/Hold/Completed terminal states.
- Customer status card now shows friendly state labels instead of raw workflow state names.
- Customer JS cache-busting version updated to `step346-token-status-sync-20260925`.
- Existing Global Token Timer remains unchanged and continues to run from STEP345.

## Validation
- `node --check customer.js` — PASS
- `node --check server.js` — PASS
- `node --check panel-timer.js` — PASS
- Local `customer.html` HTTP load — 200 OK
- `/api/customer/live-queue` — 200 OK
