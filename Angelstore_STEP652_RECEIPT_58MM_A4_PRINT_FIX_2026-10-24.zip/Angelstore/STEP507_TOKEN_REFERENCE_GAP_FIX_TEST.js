const fs = require('fs');
const html = fs.readFileSync('customer.html','utf8');
const checks = [];
function check(name, ok, detail=''){ checks.push({name,ok:Boolean(ok),detail}); }
check('reference hero exists', html.includes('token-reference-hero') && html.includes('token-generate-banner-reference.png'));
check('7-step workflow exists', (html.match(/class="ref-step/g)||[]).length === 7);
check('payment method has four options', (html.match(/class="token-payment-method/g)||[]).length >= 4);
check('payment proof form remains', html.includes('id="customerPaymentForm"') && html.includes('id="submitPayment"'));
check('generated token controls remain', html.includes('id="generateToken"') && html.includes('id="refreshMyToken"') && html.includes('id="goLive"'));
check('current independent-column layout exists', /style id="step513-token-independent-columns"/.test(html) && html.includes('grid-template-columns:minmax(0,1.45fr) minmax(330px,.85fr)'));
check('generated token remains full-width below content', /#page-customer-token \.token-generated-wrap\{\s*grid-column:1 \/ -1;\s*grid-row:2;/.test(html));
check('mobile layout collapses to one column', /@media\(max-width:820px\)\s*\{[\s\S]*?#page-customer-token \.token-reference-grid\s*\{\s*grid-template-columns:1fr;/.test(html));
check('mobile step bar can scroll horizontally', /#page-customer-token \.token-reference-steps\s*\{\s*overflow-x:auto;/.test(html));
let pass = 0;
for (const c of checks) { console.log(`${c.ok?'PASS':'FAIL'} | ${c.name}${c.detail?` | ${c.detail}`:''}`); if(c.ok) pass++; }
console.log(`RESULT ${pass}/${checks.length} PASS`);
if (pass !== checks.length) process.exit(1);
