const fs=require('fs'),path=require('path'),os=require('os'),http=require('http'),child=require('child_process');
const ROOT=__dirname,TMP=fs.mkdtempSync(path.join(os.tmpdir(),'angelstore-step460-uppcl-state-'));
fs.rmSync(TMP,{recursive:true,force:true});fs.mkdirSync(TMP,{recursive:true});
const db={};
for(const k of ['customers','customer_sessions','admin_sessions','admin_credentials','uppcl_manual_bills','payments','applications','notifications','audit'])db[k]=[];
fs.writeFileSync(path.join(TMP,'data.json'),JSON.stringify(db,null,2));
const env={...process.env,PORT:'8030',ANGELSTORE_STORAGE_DIR:TMP,ANGELSTORE_AUTH_SECRET:'step460-state-secret-12345678901234567890',ANGELSTORE_ADMIN_USER:'testadmin',ANGELSTORE_ADMIN_PASS:'TestAdmin!12345'};
const proc=child.spawn(process.execPath,[path.join(ROOT,'server.js')],{cwd:ROOT,env,stdio:['ignore','pipe','pipe']});let out='';proc.stdout.on('data',d=>out+=d);proc.stderr.on('data',d=>out+=d);
const BASE='http://127.0.0.1:8030';
function req(method,p,body,headers={}){return new Promise((resolve,reject)=>{const u=new URL(p,BASE),b=body===undefined?null:Buffer.from(JSON.stringify(body));const r=http.request({method,hostname:u.hostname,port:u.port,path:u.pathname+u.search,headers:{...(b?{'Content-Type':'application/json','Content-Length':b.length}:{}),...headers}},res=>{let s='';res.on('data',c=>s+=c);res.on('end',()=>{let data;try{data=s?JSON.parse(s):null}catch{data=s}resolve({status:res.statusCode,data,headers:res.headers})})});r.on('error',reject);if(b)r.write(b);r.end()})}
function sessionHeaders(resp,requiredCookie){const set=resp.headers?.['set-cookie']||[];const jar=set.map(v=>v.split(';')[0]).join('; ');const csrfMatch=jar.match(/(?:^|; )angel_csrf=([^;]+)/);if(!jar.includes(requiredCookie+'='))throw Error('missing '+requiredCookie+' cookie');if(!csrfMatch)throw Error('missing CSRF cookie');return {Cookie:jar,'X-CSRF-Token':decodeURIComponent(csrfMatch[1])}}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const pngs=['iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC','iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGNg+M8AAAICAQB7CYF4AAAAAElFTkSuQmCC','iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGNgYPgPAAEDAQAIicLsAAAAAElFTkSuQmCC','iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGP4/58BAAT/Af9dfQKHAAAAAElFTkSuQmCC'];
(async()=>{try{
 for(let i=0;i<40;i++){try{let h=await req('GET','/api/health');if(h.status===200)break}catch{}await sleep(100)}
 let r=await req('POST','/api/auth/login',{username:'testadmin',password:'TestAdmin!12345'});if(r.status!==200)throw Error('admin login');const A=sessionHeaders(r,'angel_admin');
 r=await req('POST','/api/customer/register',{name:'UPPCL State Customer',mobile:'9000012300',pin:'2468'});if(r.status!==201)throw Error('customer register');const C=sessionHeaders(r,'angel_customer');
 async function bill(account){let x=await req('POST','/api/admin/uppcl/manual-bill',{account,registered_mobile:'9000012300',consumer_name:'State Customer',bill_number:'B-'+account,bill_amount:1000,arrear:100,late_fee:20,total_amount:1120,bill_month:'October 2026',due_date:'20/10/2026',district:'Prayagraj',discom:'PuVVNL'},A);if(x.status!==200)throw Error('bill '+JSON.stringify(x.data));return {id:Number(x.data.bill.id),version:Number(x.data.bill.version||1)};}
 async function payment(account,utr,index,b){let x=await req('POST','/api/customer/uppcl/payment',{account,bill_id:b.id,bill_version:b.version,amount:1120,bill_month:'October 2026',due_date:'20/10/2026',district:'Prayagraj',discom:'PuVVNL',utr,screenshot:'data:image/png;base64,'+pngs[index]},C);if(x.status!==200)throw Error('payment '+JSON.stringify(x.data));return x.data.payment.id;}
 // 1) Cannot process before verification.
 let b1=await bill('1234567001');let p1=await payment('1234567001','STATE-001',0,b1);
 r=await req('POST','/api/admin/uppcl/process',{id:p1,status:'Completed'},A);if(r.status!==409)throw Error('process-before-verify not blocked '+JSON.stringify(r.data));
 // 2) Rejected is terminal; later verify is blocked.
 let b2=await bill('1234567002');let p2=await payment('1234567002','STATE-002',1,b2);
 r=await req('POST','/api/payments/status',{id:p2,status:'Rejected',reason:'Proof mismatch'},A);if(r.status!==200||r.data.status!=='Rejected')throw Error('reject failed '+JSON.stringify(r.data));
 r=await req('POST','/api/payments/status',{id:p2,status:'Verified'},A);if(r.status!==409)throw Error('verify-after-reject not blocked '+JSON.stringify(r.data));
 // 3) Failed is terminal; later Complete is blocked.
 let b3=await bill('1234567003');let p3=await payment('1234567003','STATE-003',2,b3);
 r=await req('GET','/api/payments/proof/'+p3,undefined,A);if(r.status!==200)throw Error('proof view failed');
 r=await req('POST','/api/payments/status',{id:p3,status:'Verified'},A);if(r.status!==200)throw Error('verify failed '+JSON.stringify(r.data));
 r=await req('POST','/api/admin/uppcl/process',{id:p3,status:'Failed',note:'Provider unavailable'},A);if(r.status!==200||r.data.processing_status!=='Failed')throw Error('fail process failed '+JSON.stringify(r.data));
 r=await req('POST','/api/admin/uppcl/process',{id:p3,status:'Completed'},A);if(r.status!==409)throw Error('complete-after-fail not blocked '+JSON.stringify(r.data));
 // 4) Completed is terminal; later Failed is blocked.
 let b4=await bill('1234567004');let p4=await payment('1234567004','STATE-004',3,b4);
 r=await req('GET','/api/payments/proof/'+p4,undefined,A);if(r.status!==200)throw Error('proof view 2 failed');
 r=await req('POST','/api/payments/status',{id:p4,status:'Verified'},A);if(r.status!==200)throw Error('verify 2 failed');
 r=await req('POST','/api/admin/uppcl/process',{id:p4,status:'Completed',provider_ref:'UPPCL-STATE-004'},A);if(r.status!==200||r.data.processing_status!=='Completed'||!r.data.payment?.receipt_no)throw Error('complete failed '+JSON.stringify(r.data));
 r=await req('POST','/api/admin/uppcl/process',{id:p4,status:'Failed',note:'late failure'},A);if(r.status!==409)throw Error('fail-after-complete not blocked '+JSON.stringify(r.data));
 console.log(JSON.stringify({ok:true,checks:{process_before_verify_blocked:true,rejected_payment_terminal:true,verify_after_reject_blocked:true,failed_processing_terminal:true,complete_after_fail_blocked:true,completed_processing_terminal:true,fail_after_complete_blocked:true,receipt_generated_on_completion:true}},null,2));
}catch(e){console.error(JSON.stringify({ok:false,error:e.message,server_output:out},null,2));process.exitCode=1}finally{proc.kill('SIGTERM');setTimeout(()=>{try{fs.rmSync(TMP,{recursive:true,force:true})}catch{}},200)}})();
