# STEP490 — Admin ↔ Staff Assignment/Transfer ↔ Customer Queue Sync

## Scope
Harden the existing Token Queue workflow so Admin assignment/transfer, Staff ownership, and Customer Live Token Status remain consistent without changing the approved UI/design, cart-free workflow, or core buttons.

## Root causes addressed
1. Customer `current` token projection did not expose the assigned staff name.
2. Customer Live Queue returned only minimal token fields, so staff ownership and queue metadata were not available to the live status surface.
3. Admin assignment/transfer could overwrite an existing staff assignment without requiring the explicit Transfer action.
4. Transfer accepted a stale/mismatched `from_staff_id`, allowing a race-prone source assignment request.
5. Assignment/transfer had no customer-facing notification.

## Fixes
- `customerCurrentToken()` now resolves and exposes `staff_name`.
- `/api/customer/live-queue` now exposes:
  - `queue_position`
  - `waiting_count`
  - `ahead_count`
  - `estimated_wait_minutes`
  - `staff_id`
  - `staff_name`
  - `last_action_at`
- Admin `assign` now refuses to replace another staff assignment; Admin must use `transfer`.
- Transfer now validates `from_staff_id` against the token's current assignment.
- Same-staff duplicate assignment is rejected as a no-op conflict.
- Assignment/transfer creates a deduplicated Customer notification with the assigned staff name.
- Transfer audit records now retain previous/current staff identity and reason.

## Verification
| Check | Result |
|---|---|
| `node --check server.js` | PASS |
| `node --check app.js` | PASS |
| STEP487 queue metrics regression | PASS |
| STEP488 token control regression | PASS |
| STEP489 Staff ↔ Customer sync regression | PASS |
| STEP490 assignment/transfer targeted E2E | PASS — 11/11 |
| P0/P1 regression suite | PASS |

### STEP490 targeted E2E checks
- assignment succeeds — PASS
- customer token exposes assigned staff — PASS
- live queue exposes staff + queue metadata — PASS
- assignment notification — PASS
- duplicate same-staff assignment blocked — PASS
- stale transfer source blocked — PASS
- transfer succeeds — PASS
- customer reflects transferred staff — PASS
- live queue reflects transferred staff — PASS
- transfer notification — PASS
- admin queue remains consistent — PASS

## Browser verification limitation
No fresh click-by-click Chromium visual PASS is claimed. The environment previously blocked normal localhost browser navigation (`ERR_BLOCKED_BY_ADMINISTRATOR`). STEP490 verification therefore relies on syntax checks and isolated HTTP/API E2E tests.

## Production gate
This is a code/workflow verification PASS. Live deployment, production host configuration, credentials, and real customer/staff browser behavior remain separate production gates.

**STEP490 TARGETED VERIFICATION: PASS**
