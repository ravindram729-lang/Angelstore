const fs=require('fs'),path=require('path');
const app=fs.readFileSync(path.join(__dirname,'app.js'),'utf8');
const html=fs.readFileSync(path.join(__dirname,'admin.html'),'utf8');
const checks=[
['Check Now is a real button',/<button[^>]*type="button"[^>]*id="refreshMonitoring"|<button[^>]*id="refreshMonitoring"[^>]*type="button"/.test(html)],
['Check Now has accessible control relation',/id="refreshMonitoring"[^>]*aria-controls="monitorChecks retryObsDetails incidentRows"/.test(html)],
['Check Now exposes busy state',/id="refreshMonitoring"[^>]*aria-busy="false"/.test(html)],
['Monitoring live status is polite',/id="monitorLiveStatus"[^>]*aria-live="polite"/.test(html)],
['Monitoring results are live',/id="monitorChecks"[^>]*aria-live="polite"/.test(html)],
['Retry observability is live',/id="retryObsDetails"[^>]*aria-live="polite"/.test(html)],
['Incident rows are live',/id="incidentRows"[^>]*aria-live="polite"/.test(html)],
['Resolve controls are buttons',/class="primary resolve-incident"[^>]*data-id=/.test(app)],
['Resolve refresh restores keyboard focus',/loadMonitoring\(\)\.then\(\(\)=>\$\('#refreshMonitoring'\)\?\.focus\(\)\)/.test(app)],
['Refresh restores initiating focus',/const wasFocused=document\.activeElement===btn/.test(app)&&/if\(wasFocused && btn && !btn\.disabled\) btn\.focus\(\)/.test(app)],
['Error state can receive focus',/role="alert" tabindex="-1"/.test(app)],
['No cart/order dependency in monitoring flow',!/(cart|order)\b/i.test(app.match(/async function loadMonitoring\(\)[\s\S]{0,12000}/)?.[0]||'')]
];
let pass=0;checks.forEach(([n,ok],i)=>{console.log(`${i+1}. ${ok?'PASS':'FAIL'} — ${n}`);if(ok)pass++});
const report={step:'STEP546',total:checks.length,passed:pass,failed:checks.length-pass,ok:pass===checks.length};
fs.writeFileSync(path.join(__dirname,'STEP546_ADMIN_MONITORING_KEYBOARD_FOCUS_AUDIT_REPORT.json'),JSON.stringify(report,null,2));
if(pass!==checks.length) process.exit(1);
